function saved = vsw_save(R, outRoot)
%VSW_SAVE  Write out/{signalId}/ (04 §8.2).
%   json and txt are always written; sgy/custom/vsci/csv/mat/wav follow
%   P.output.format (or 'all'; 'all' does not include custom or vsci).  A
%   written SEG-Y is read back and checked against 04 §9.

if nargin < 2 || isempty(outRoot), outRoot = fullfile(pwd, 'out'); end
dirName = fullfile(outRoot, R.meta.signalId);
if ~exist(dirName, 'dir'), mkdir(dirName); end

fmt = lower(R.P.output.format);
known = {'segy', 'custom', 'vsci', 'mat', 'csv', 'txt', 'wav', 'all'};
if ~any(strcmp(fmt, known))
    error('vsw:save:format', ...
        'Unknown output format "%s" (expected %s).', ...
        fmt, strjoin(known, ', '));
end

base = fullfile(dirName, R.meta.signalId);
saved.dir    = dirName;
saved.format = fmt;
saved.sgy    = '';
saved.custom = '';
saved.vsci   = '';
saved.csv    = '';
saved.mat    = '';
saved.wav    = '';
saved.json   = vsw_writeJson(R, [base '.json']);
saved.txt    = vsw_writeTxt(R,  [base '.txt']);

if any(strcmp(fmt, {'segy', 'all'}))
    info = vsw_writeSegy(R, [base '.sgy']);
    saved.sgy = info.fileName;
    saved.segyInfo = info;
    saved.verify = verifySegy(saved.sgy, R);
end
if strcmp(fmt, 'custom')
    ci = vsw_writeCustom(R, [base '.custom']);
    saved.custom = ci.fileName;
    saved.customInfo = ci;
end
if strcmp(fmt, 'vsci')
    vi = vsw_writeVsci(R, [base '.vsci']);
    saved.vsci = vi.fileName;
    saved.vsciInfo = vi;
end
if any(strcmp(fmt, {'csv', 'all'}))
    saved.csv = vsw_writeCsv(R, [base '.csv']);
end
if any(strcmp(fmt, {'mat', 'all'}))
    saved.mat = vsw_writeMat(R, [base '.mat']);
end
if any(strcmp(fmt, {'wav', 'all'}))
    saved.wav = vsw_writeWav(R, [base '.wav']);
end
end

% =======================================================================
function V = verifySegy(file, R)
% Field-level acceptance list of 04 §9 (items 1-15).
S = vsw_readSegy(file);
P = R.P; D = R.D;
nt = S.nTraces;
N  = S.nSamples;
bps = S.bytesPerSample;
V = struct();

V.sizeOK = dir(file).bytes == S.firstTraceOffset + nt*(240 + N*bps);
V.dtOK   = S.sampleIntervalUs == round(D.dtS*1e6) && ...
           S.traceDtUs == S.sampleIntervalUs;
V.nSampOK = S.nSamples == D.N && S.traceNSamples == D.N;

V.sweepHdrOK = isequal([S.sweepStartHz S.sweepEndHz S.sweepLengthMs S.sweepTypeCode], ...
                       [S.traceStartHz  S.traceEndHz  S.traceLengthMs  S.traceSweepType]);
V.taperHdrOK = isequal([S.startTaperMs S.endTaperMs S.taperTypeCode], ...
                       [S.traceStartTaper S.traceEndTaper S.traceTaperType]);
V.taperBudgetOK = S.startTaperMs + S.endTaperMs <= S.sweepLengthMs;

tridSet = [6 21 19 18 20 1];
V.tridOK = ismember(S.traceIdCode, tridSet) && ...
           S.traceIdCode == P.output.traceIdCode;
fLo = min(P.sweep.f1Hz, P.sweep.f2Hz);
fHi = max(P.sweep.f1Hz, P.sweep.f2Hz);
V.sweepRangeOK = isequal([S.sweepStartHz S.sweepEndHz], ...
                         [round(fLo) round(fHi)]) && ...
                 S.sweepStartHz == round(D.fLo) && S.sweepEndHz == round(D.fHi);

V.textHeaderOK = numel(S.textHeader) == 3200 && ...
    strncmp(S.textHeader(1:80), 'C 1', 3) && ...
    strcmp(strtrim(S.textHeader(39*80+1:40*80)), 'C40 END TEXTUAL HEADER');

rev = lower(P.output.segyRevision);
switch rev
    case 'rev2.1', wantRev = [2 1];
    case 'rev1',   wantRev = [1 0];
    otherwise,     wantRev = [0 0];
end
V.revOK = S.revMajor == wantRev(1) && S.revMinor == wantRev(2);
if strcmp(rev, 'rev2.1')
    V.byteOrderOK = S.byteOrder == 16909060;
else
    V.byteOrderOK = S.byteOrder == 0;
end
line39 = strtrim(S.textHeader(38*80+1:39*80));
switch rev
    case 'rev2.1', V.c39OK = contains(line39, 'REV2.1');
    case 'rev1',   V.c39OK = contains(line39, 'REV1');
    otherwise,     V.c39OK = contains(line39, 'REV0');
end

V.binaryMiscOK = S.fixedLength == 1 && S.maxAddTraceHdr == 0 && ...
    S.surveyType == 1 && S.timeBasis == 4 && ...
    S.tracesInFile == nt && ...
    S.firstTraceOffset == 3600 + 3200*S.nExtText && ...
    all(S.binHeader(329:332) == 0);
V.nTracesOK = nt == max(1, round(P.output.numTraces));

if strcmpi(P.output.sampleFormat, 'int16')
    tol = 1.01 / 32767;
else
    tol = 1e-6;
end
idx = unique([1:min(nt, 3), nt]);
maxErr = 0;
for k = idx
    Sk = vsw_readSegy(file, k);
    if numel(Sk.samples) ~= numel(R.derived.signal)
        maxErr = Inf;
        break;
    end
    denom = max(abs(R.derived.signal));
    e = max(abs(Sk.samples - R.derived.signal)) / max(denom, eps);
    maxErr = max(maxErr, e);
end
V.sampleMaxRelErr = maxErr;
V.samplesOK = maxErr <= tol;

stanzaNeeded = P.output.writeExtendedStanza || R.G.sweepCode == 4;
if stanzaNeeded
    V.stanzaOK = S.nExtText >= 1 && ...
        contains(S.extText, ['dswv-type = ' P.sweep.type]) && ...
        contains(S.extText, 'dswv-version = ');
else
    V.stanzaOK = true;
end

V.pass = V.sizeOK && V.dtOK && V.nSampOK && V.sweepHdrOK && ...
         V.taperHdrOK && V.taperBudgetOK && V.tridOK && V.sweepRangeOK && ...
         V.textHeaderOK && V.revOK && V.byteOrderOK && V.c39OK && ...
         V.binaryMiscOK && V.nTracesOK && V.samplesOK && V.stanzaOK;
end
