function wavFile = vsw_writeWav(R, fileName)
%VSW_WRITEWAV  WAV export for listening (non-standard, 04 §8.2).
%   Sample rate is 1/dt.  WAV is limited to [-1, 1]; an over-range signal is
%   scaled down and the original peak is recorded in the caller's snapshot.

if nargin < 2
    fileName = fullfile(pwd, [R.meta.signalId '.wav']);
end
fs = 1 / R.D.dtS;
x  = R.derived.signal(:);
pk = max(abs(x));
if pk > 1
    x = x / pk * 0.999;
end
audiowrite(fileName, x, fs);
wavFile = fileName;
end
