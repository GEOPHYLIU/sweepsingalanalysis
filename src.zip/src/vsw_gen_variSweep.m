function G = vsw_gen_variSweep(P, D)
%VSW_GEN_VARISWEEP  Superposed slightly detuned linear sweeps (03 §2.1).
%   variCount chirps share the nominal band; each is shifted by a fraction of
%   variBandJitterPct.  The sum broadens the spectrum envelope and lowers the
%   correlation side lobes.  The result is not monotonic, so B5/B6 do not apply.

n    = max(1, round(P.sweep.variCount));
jit  = P.sweep.variBandJitterPct / 100;
if n == 1
    frac = 0;
else
    frac = linspace(-1, 1, n).';
end

t   = D.tAxisS;
T   = D.T;
flo = D.fLo;
fhi = D.fHi;
up  = strcmpi(D.direction, 'up');

x    = zeros(D.N, 1);
fSum = zeros(D.N, 1);
for k = 1:n
    f1 = flo * (1 + jit * frac(k));
    f2 = fhi * (1 + jit * frac(k));
    f1 = max(f1, 1e-6);
    f2 = max(f2, 1e-6);
    if up
        fk = f1 + (f2 - f1) * (t / T);
        ph = 2*pi * (f1*t + 0.5*(f2 - f1)/T * t.^2);
    else
        fk = f2 - (f2 - f1) * (t / T);
        ph = 2*pi * (f2*t - 0.5*(f2 - f1)/T * t.^2);
    end
    x    = x + sin(ph + D.phi0Rad);
    fSum = fSum + fk;
end
pk = max(abs(x));
if pk > 0, x = x / pk; end

G.kind       = 'raw';
G.pathLabel  = 'variSweep';
G.sweepCode  = 4;
G.signalRaw  = x;
G.fOfTS      = fSum / n;
ph = zeros(D.N, 1);
if D.N > 1
    ph(2:end) = cumsum(pi * D.dtS * (G.fOfTS(1:end-1) + G.fOfTS(2:end)));
end
G.phaseRad   = ph;
G.fAt0       = G.fOfTS(1);
G.fAtT       = G.fOfTS(end);
G.fOfT       = @(tt) localMeanFreq(tt, D, jit, frac);
G.monotonicApplicable = false;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G.variCount  = n;
G.variBandJitterPct = P.sweep.variBandJitterPct;
end

function f = localMeanFreq(tt, D, jit, frac)
t = min(max(tt(:), 0), D.T);
u = t / D.T;
up = strcmpi(D.direction, 'up');
f = zeros(size(u));
for k = 1:numel(frac)
    f1 = D.fLo * (1 + jit*frac(k));
    f2 = D.fHi * (1 + jit*frac(k));
    if up
        f = f + f1 + (f2 - f1) * u;
    else
        f = f + f2 - (f2 - f1) * u;
    end
end
f = f / max(numel(frac), 1);
end
