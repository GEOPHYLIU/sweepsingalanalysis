function S = vsw_readSegy(fileName, traceIndex)
%VSW_READSEGY  Minimal reader used by the write-read-back acceptance loop.
%   Parses the textual header, binary header, extended stanzas, one trace
%   header (traceIndex, default 1) and that trace's samples.  Only the
%   big-endian path is implemented.

if nargin < 2 || isempty(traceIndex), traceIndex = 1; end
traceIndex = max(1, round(traceIndex));

raw = fopenClose(fileName);
if numel(raw) < 3840
    error('vsw:segy:short', 'File too short to be SEG-Y: %s', fileName);
end
S.textHeader = char(raw(1:3200).');
S.binHeader  = raw(3201:3600);
g = @(pos, n) getBig(raw(3200 + pos:3200 + pos + n - 1));

S.sampleIntervalUs = g(17, 2);
S.nSamples         = g(21, 2);
S.sampleFormat     = g(25, 2);
S.sweepStartHz     = g(33, 2);
S.sweepEndHz       = g(35, 2);
S.sweepLengthMs    = g(37, 2);
S.sweepTypeCode    = g(39, 2);
S.sweepTraceNo     = g(41, 2);
S.startTaperMs     = g(43, 2);
S.endTaperMs       = g(45, 2);
S.taperTypeCode    = g(47, 2);
S.byteOrder        = getBig(raw(3200+97 : 3200+100));
S.revMajor         = double(raw(3200+301));
S.revMinor         = double(raw(3200+302));
S.fixedLength      = g(303, 2);
S.nExtText         = g(305, 2);
S.maxAddTraceHdr   = g(307, 2);
S.surveyType       = g(309, 2);
S.timeBasis        = g(311, 2);
S.tracesInFile     = getBig64(raw(3200+313 : 3200+320));
S.firstTraceOffset = getBig64(raw(3200+321 : 3200+328));
S.bytesPerSample   = bytesPerSample(S.sampleFormat);

S.extText = '';
pos = 3601;
for k = 1:max(S.nExtText, 0)
    if pos + 3199 > numel(raw), break; end
    S.extText = [S.extText, char(raw(pos:pos+3199).')];
    pos = pos + 3200;
end

% Variable-length files leave the binary sample count at zero: peek at the
% first trace header so the stride for later traces is still correct.
if S.nSamples <= 0
    th1 = S.firstTraceOffset + 1;
    if th1 + 239 <= numel(raw)
        S.nSamples = getBig(raw(th1+114 : th1+115));
    end
end
S.traceLengthBytes = 240 + S.nSamples * S.bytesPerSample;

if S.tracesInFile > 0
    S.nTraces = S.tracesInFile;
else
    avail = numel(raw) - S.firstTraceOffset;
    S.nTraces = max(0, floor(avail / max(S.traceLengthBytes, 1)));
end

th0 = S.firstTraceOffset + 1 + (traceIndex-1) * S.traceLengthBytes;
S.traceIndex = traceIndex;
if th0 + 239 > numel(raw)
    error('vsw:segy:trace', 'Trace %d is beyond the end of %s.', ...
        traceIndex, fileName);
end
S.traceSequence   = getBig(raw(th0 : th0+3));
S.traceIdCode     = getBig(raw(th0+29-1 : th0+30-1));
S.traceDelayMs    = getBig(raw(th0+109-1 : th0+110-1));
S.traceNSamples   = getBig(raw(th0+115-1 : th0+116-1));
S.traceDtUs       = getBig(raw(th0+117-1 : th0+118-1));
S.traceCorrelated = getBig(raw(th0+125-1 : th0+126-1));
S.traceStartHz    = getBig(raw(th0+127-1 : th0+128-1));
S.traceEndHz      = getBig(raw(th0+129-1 : th0+130-1));
S.traceLengthMs   = getBig(raw(th0+131-1 : th0+132-1));
S.traceSweepType  = getBig(raw(th0+133-1 : th0+134-1));
S.traceStartTaper = getBig(raw(th0+135-1 : th0+136-1));
S.traceEndTaper   = getBig(raw(th0+137-1 : th0+138-1));
S.traceTaperType  = getBig(raw(th0+139-1 : th0+140-1));

if (isempty(S.nSamples) || S.nSamples <= 0) && S.traceNSamples > 0
    S.nSamples = S.traceNSamples;
    S.traceLengthBytes = 240 + S.nSamples * S.bytesPerSample;
end

sp = th0 + 240;
if sp + S.bytesPerSample*S.nSamples - 1 > numel(raw)
    error('vsw:segy:shortTrace', 'Trace %d samples run past the end of %s.', ...
        traceIndex, fileName);
end
switch S.sampleFormat
    case 1
        bytes = raw(sp : sp + 4*S.nSamples - 1);
        S.samples = vsw_ibmDecode(reshape(bytes, 4, []).');
    case 5
        bytes = raw(sp : sp + 4*S.nSamples - 1);
        S.samples = double(swapbytes(typecast(bytes, 'single')));
    case 2
        bytes = raw(sp : sp + 4*S.nSamples - 1);
        S.samples = double(swapbytes(typecast(bytes, 'int32'))) / 2147483647;
    case 3
        bytes = raw(sp : sp + 2*S.nSamples - 1);
        % The writer stores the normalized signal at int16 full scale, so
        % undo that scale here.  Shape is preserved for field int16 data.
        S.samples = double(swapbytes(typecast(bytes, 'int16'))) / 32767;
    otherwise
        error('vsw:segy:format', 'Unsupported sample format code %d.', S.sampleFormat);
end
S.samples = S.samples(:);
end

function bps = bytesPerSample(code)
switch code
    case 3
        bps = 2;
    otherwise
        bps = 4;
end
end

function b = fopenClose(fileName)
fid = fopen(fileName, 'rb');
if fid < 0
    error('vsw:segy:open', 'Cannot open "%s" for reading.', fileName);
end
b = fread(fid, Inf, 'uint8=>uint8');
fclose(fid);
end

function v = getBig(bytes)
bytes = uint8(bytes(:));
n = numel(bytes);
v = 0;
for ii = 1:n
    v = v*256 + double(bytes(ii));
end
if n == 2 && v >= 2^15, v = v - 2^16; end
if n == 4 && v >= 2^31, v = v - 2^32; end
end

function v = getBig64(bytes)
bytes = uint8(bytes(:));
v = 0;
for ii = 1:numel(bytes)
    v = v*256 + double(bytes(ii));
end
end
