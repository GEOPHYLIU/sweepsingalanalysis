function G = vsw_gen_dampedRicker(P, D)
%VSW_GEN_DAMPEDRICKER  Damped Ricker target-spectrum sweep (00 §4.1).
%   Target correlation-wavelet spectrum A(f) is analytic; f(t) comes from
%   the stay-time allocation, so |S~|^2 ~ A(f) = |W~|.

f0 = P.wavelet.mainFreqHz;
B  = P.wavelet.dampingFactor;
fg = linspace(D.fLo, D.fHi, max(4001, 4*D.N + 1)).';
wt = lower(P.wavelet.waveletType);
fullSideDB = NaN;

switch wt
    case 'yu'
        p = P.wavelet.yuFreqLowerHz;
        q = P.wavelet.yuFreqUpperHz;
        A = vsw_yuSpectrum(fg, p, q);
        G.zeroCrossSpacingS = [];        % no closed-form width for the mix
        G.yuFreqLowerHz = p;
        G.yuFreqUpperHz = q;
    case 'custom'
        gamma = P.wavelet.lobeWidthRatio;
        f0e   = f0 / gamma;
        Bc    = vsw_solveDampingForLobe(P.wavelet.lobeAmpRatio);
        A     = vsw_dampedRickerSpectrum(fg, f0e, Bc);
        G.zeroCrossSpacingS = gamma * sqrt(2) / (pi * f0);
        G.waveletF0 = f0e;
        G.waveletB  = Bc;
        G.waveletGamma = gamma;
        fullSideDB = 20*log10(vsw_dampedRickerSideLobe(Bc));
    otherwise
        A = vsw_dampedRickerSpectrum(fg, f0, B);
        G.zeroCrossSpacingS = sqrt(2) / (pi * f0);   % B-independent, 00 §4.1 property 1
        fullSideDB = 20*log10(vsw_dampedRickerSideLobe(B));
end
if max(A) <= 0
    error('vsw:gen:zeroSpectrum', 'Damped Ricker / Yu spectrum is zero over the band.');
end
A = A / max(A);

G.kind      = 'spectrum';
G.pathLabel = 'targetSpectrum';
G.sweepCode = 4;
G.waveletType = P.wavelet.waveletType;
if ~isfield(G, 'waveletF0'), G.waveletF0 = f0; end
if ~isfield(G, 'waveletB'),  G.waveletB  = B;  end
G = vsw_freqFromSpectrum(P, D, fg, A, G);
M = vsw_bandlimitedMetrics(G.targetFreqAxis, G.targetAmp);
G.targetSideLobeDB = M.sideLobeDB;
G.fullWaveletSideLobeDB = fullSideDB;
end

function r = vsw_dampedRickerSideLobe(B)
% First side-lobe amplitude ratio of the damped Ricker (normalized f0 = 1).
t  = linspace(0, 4, 40001).';
w  = (1 - 2*(pi*t).^2) .* exp(-B*(pi*t).^2);
tz = sqrt(2)/(2*pi);
r  = max(abs(w(t > tz)));
end
