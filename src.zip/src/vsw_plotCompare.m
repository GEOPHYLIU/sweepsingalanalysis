function h = vsw_plotCompare(E, A, R, C)
%VSW_PLOTCOMPARE  External vs generated reference, with cross-correlation.

h = figure('Color', 'w', 'Position', [70 60 1180 860], ...
    'Name', 'external vs generated', 'NumberTitle', 'off');
tl = tiledlayout(h, 3, 1, 'TileSpacing', 'compact', 'Padding', 'compact');

% ---- waveforms --------------------------------------------------------
ax1 = nexttile;
xe = E.x / max(max(abs(E.x)), eps);
ye = R.derived.signal / max(max(abs(R.derived.signal)), eps);
plot(ax1, E.tS, xe, 'Color', [0.85 0.25 0.10], 'LineWidth', 0.9); hold(ax1, 'on');
plot(ax1, R.D.tAxisS, ye, 'k', 'LineWidth', 0.8);
grid(ax1, 'on'); xlabel(ax1, 'time (s)'); ylabel(ax1, 'normalised');
legend(ax1, {'external', 'generated reference'}, 'Location', 'best');
title(ax1, '(1) waveforms (peak-normalised)');

% ---- spectra ----------------------------------------------------------
ax2 = nexttile;
plot(ax2, A.freqAxisHz, A.ampSpectrumDB, 'Color', [0.85 0.25 0.10], ...
    'LineWidth', 1.0); hold(ax2, 'on');
AR = R.analysis;
plot(ax2, AR.freqAxisHz, AR.ampSpectrumDB, 'k', 'LineWidth', 0.9);
grid(ax2, 'on'); xlabel(ax2, 'frequency (Hz)'); ylabel(ax2, 'dB');
xlim(ax2, [0 min(E.fsHz/2, max(1, 1.6*max(A.dominantFreqHz, R.D.fHi)))]);
ylim(ax2, [-90 5]);
legend(ax2, {'external', 'generated'}, 'Location', 'best');
title(ax2, '(2) amplitude spectra');

% ---- cross-correlation ------------------------------------------------
ax3 = nexttile;
plot(ax3, C.lagS, C.corr, 'b', 'LineWidth', 1.0); hold(ax3, 'on');
yl = ylim(ax3);
plot(ax3, [1 1]*C.peakLagS, yl, 'r--', 'LineWidth', 0.9);
[~, kpk] = min(abs(C.lagS - C.peakLagS));
plot(ax3, C.peakLagS, C.corr(kpk), 'ko', ...
    'MarkerSize', 5, 'MarkerFaceColor', 'k');
grid(ax3, 'on'); xlabel(ax3, 'lag (s)'); ylabel(ax3, 'normalised correlation');
title(ax3, sprintf('(3) cross-correlation   peak %.4f at %.4g s, gain %.2f dB', ...
    C.peakCorr, C.peakLagS, C.gainDB));

title(tl, sprintf('%s vs %s   |   %s', E.name, R.meta.signalId, C.summary), ...
    'Interpreter', 'none');
end
