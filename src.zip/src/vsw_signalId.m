function id = vsw_signalId(P)
%VSW_SIGNALID  Deterministic identifier (04 §8.2): no random component.
s = P.sweep;
id = sprintf('%s_%g-%gHz_%gs_%gms', ...
    s.type, s.f1Hz, s.f2Hz, s.lengthMs/1000, s.dtMs);
if strcmpi(s.direction, 'down')
    id = [id '_down'];
end
id = regexprep(id, '[^A-Za-z0-9_.-]', '_');
end
