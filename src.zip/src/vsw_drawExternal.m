function vsw_drawExternal(axs, E, A)
%VSW_DRAWEXTERNAL  Draw imported-signal time / spectrum / spectrogram / f(t).
%
%   axs is a 1x4 array of axes handles (uiaxes or classic axes).  All arrays
%   come from vsw_analyzeExternal; nothing is recomputed here.

ax1 = axs(1); ax2 = axs(2); ax3 = axs(3); ax4 = axs(4);
for k = 1:numel(axs)
    axis(axs(k), 'on');
end

% ---- (1) time ---------------------------------------------------------
cla(ax1);
plot(ax1, E.tS, E.x, 'k', 'LineWidth', 0.8);
grid(ax1, 'on');
xlabel(ax1, 'time (s)'); ylabel(ax1, 'amplitude');
title(ax1, sprintf('(1) external time   %s', E.name), 'Interpreter', 'none');
xlim(ax1, [0 max(E.durationS, eps)]);

% ---- (2) amplitude spectrum ------------------------------------------
cla(ax2);
plot(ax2, A.freqAxisHz, A.ampSpectrumDB, 'r', 'LineWidth', 1.0);
grid(ax2, 'on');
xlabel(ax2, 'frequency (Hz)'); ylabel(ax2, 'dB');
xlim(ax2, [0 min(E.fsHz/2, max(1, 4*A.dominantFreqHz))]);
ylim(ax2, [-90 5]);
title(ax2, sprintf('(2) spectrum   fdom = %.4g Hz', A.dominantFreqHz));

% ---- (3) spectrogram --------------------------------------------------
cla(ax3);
if ~isempty(A.spec)
    imagesc(ax3, A.spec.t, A.spec.f, A.spec.db);
    axis(ax3, 'xy');
    colormap(ax3, parula(256));
    ylim(ax3, [0 min(E.fsHz/2, max(A.spec.f))]);
    xlabel(ax3, 'time (s)'); ylabel(ax3, 'frequency (Hz)');
    title(ax3, '(3) spectrogram (dB, peak = 0)');
else
    text(ax3, 0.5, 0.5, 'signal too short for a spectrogram', ...
        'Units', 'normalized', 'HorizontalAlignment', 'center');
    axis(ax3, 'off');
end
% ---- (4) instantaneous frequency -------------------------------------
cla(ax4);
plot(ax4, E.tS, A.fInstHz, 'Color', [0.85 0.25 0.10], 'LineWidth', 1.0);
grid(ax4, 'on');
xlabel(ax4, 'time (s)'); ylabel(ax4, 'f(t) (Hz)');
xlim(ax4, [0 max(E.durationS, eps)]);
ylim(ax4, [0 E.fsHz/2]);
title(ax4, sprintf('(4) instantaneous frequency   band %s Hz', ...
    bandLabel(A.bandLowHz, A.bandHighHz)));
end

function s = bandLabel(lo, hi)
if isfinite(lo) && isfinite(hi)
    s = sprintf('%.4g-%.4g', lo, hi);
else
    s = 'n/a';
end
end
