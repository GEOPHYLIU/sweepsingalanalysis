function G = vsw_freqFromSpectrum(P, D, fax, A, G)
%VSW_FREQFROMPECTRUM  Stay-time allocation: target spectrum A(f) -> f(t).
%
%   Implements 00 §3 / 01 §4.3:  t(f) = T * integral(A df) / integral(A df)
%   with an optional (A/D)^2 low-frequency drive weighting (00 §2.1 eq.4).
%   Returns f(t) by monotone inversion and its defining handle for the
%   10x-oversampled phase reference.

if nargin < 5 || isempty(G), G = struct(); end

fax = fax(:); A = A(:);
ok  = isfinite(fax) & isfinite(A);
fax = fax(ok); A = A(ok);
[fax, ia] = unique(fax, 'stable'); A = A(ia);
if numel(fax) < 3
    error('vsw:gen:spectrumTooShort', ...
        'Target spectrum needs at least three finite frequency points.');
end

% Fine grid over the valid band; A9 has already checked resolvability.
M   = max(4001, 4*D.N + 1);
fg  = linspace(D.fLo, D.fHi, M).';
Ag  = interp1(fax, A, fg, 'linear', 0);
Ag  = max(Ag, 0);

W = Ag;
if P.drive.lowFreqBoost && ~isempty(P.drive.driveCurve)
    Dg = interp1(P.drive.driveCurve(:,1), P.drive.driveCurve(:,2), fg, 'linear', 1);
    Dg = min(max(Dg, 1e-3), 1);
    W  = (Ag ./ Dg).^2;
end

cum = cumtrapz(fg, W);
if cum(end) <= 0
    error('vsw:gen:zeroSpectrum', 'Target spectrum integrates to zero over the band.');
end
tOfF = D.T * cum / cum(end);

% Monotone inversion (cum is non-decreasing; keep unique breakpoints).
[tOfF, iu] = unique(tOfF, 'stable');
fAsc = fg(iu);
if numel(tOfF) < 2
    error('vsw:gen:zeroSpectrum', 'Target spectrum has no resolvable dwell-time distribution.');
end

if strcmpi(D.direction, 'down')
    G.fOfT = @(tt) interp1(tOfF, fAsc, ...
        min(max(D.T - tt(:), 0), D.T), 'linear', 'extrap');
else
    G.fOfT = @(tt) interp1(tOfF, fAsc, ...
        min(max(tt(:), 0), D.T), 'linear', 'extrap');
end

G.fOfTS  = G.fOfT(D.tAxisS);
G.fOfTS  = min(max(G.fOfTS, D.fLo), D.fHi);
G.fAtT   = G.fOfT(D.T);
G.fAt0   = G.fOfT(0);
G.targetAmp       = Ag;
G.targetFreqAxis  = fg;
G.kind            = 'spectrum';
G.monotonicApplicable = true;
G.fOfTS = reshape(G.fOfTS, size(D.tAxisS));
end
