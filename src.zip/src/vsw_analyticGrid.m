function G = vsw_analyticGrid(D, G)
%VSW_ANALYTICGRID  Evaluate an analytic generator on the sample grid.
%
%   Generators register the ascending law fUp(u) and its integral FAup(u),
%   u = t/T in [0,1].  Direction 'down' is the exact time reversal of that
%   ascending law, so every analytic type shares one direction convention.

u = D.tAxisS / D.T;

if strcmpi(D.direction, 'down')
    G.fOfTS  = G.fUp(1 - u);
    G.phaseRad = 2*pi*D.T * (G.FAup(1) - G.FAup(1 - u));
    G.fAtT   = G.fUp(0);
    G.fAt0   = G.fUp(1);
else
    G.fOfTS  = G.fUp(u);
    G.phaseRad = 2*pi*D.T * G.FAup(u);
    G.fAtT   = G.fUp(1);
    G.fAt0   = G.fUp(0);
end

G.fOfT = @(tt) localFOfT(G, D, tt);
G.monotonicApplicable = true;
end

function f = localFOfT(G, D, tt)
u = min(max(tt(:), 0), D.T) / D.T;
if strcmpi(D.direction, 'down')
    f = G.fUp(1 - u);
else
    f = G.fUp(u);
end
end
