function S = vsw_readSac(file)
%VSW_READSAC  Read a SAC time-series file (single trace).
%
%   S = vsw_readSac(file)
%
%   The 632-byte SAC header is checked before the samples are decoded:
%   delta and npts must be plausible and the file must contain
%   npts float32 samples after the header.  Both little- and big-endian
%   headers are tried; the one with a consistent structure wins.
%
%   S fields: data, delta, npts, byteOrder, b, e, o, iftype,
%             expectedBytes, fileBytes
%
%   Only iftype = 1 (time series) is accepted.  Spectral (iftype = 2) and
%   general (iftype = 3/4) SAC files are rejected with an explicit message.

d = dir(file);
if isempty(d) || d.bytes < 636
    error('vsw:sac:short', 'File too short to be SAC: %s', file);
end

fid = fopen(file, 'rb');
if fid < 0
    error('vsw:sac:open', 'Cannot open "%s" for reading.', file);
end
raw = fread(fid, Inf, 'uint8=>uint8');
fclose(fid);
raw = raw(:).';
fileBytes = numel(raw);

if fileBytes < 632 + 4
    error('vsw:sac:short', 'File too short to hold SAC header and samples: %s', file);
end

orders = {'little', 'big'};
chosen = [];
for ii = 1:numel(orders)
    order = orders{ii};
    delta = readF32(raw, 0, order);
    npts  = readI32(raw, 280 + 9*4, order);
    iftype = readI32(raw, 280 + 13*4, order);
    if ~(isfinite(delta) && delta > 0 && delta < 1e3), continue; end
    if ~(isfinite(npts) && npts > 0 && npts < 1e8 && npts == round(npts))
        continue;
    end
    needed = 632 + npts * 4;
    if fileBytes < needed, continue; end
    if iftype ~= 1
        error('vsw:sac:iftype', ...
            ['SAC file "%s" has iftype = %d; only time-series files ' ...
             '(iftype = 1) are supported.'], file, iftype);
    end
    chosen = struct('order', order, 'delta', delta, 'npts', npts, ...
        'iftype', iftype, 'needed', needed);
    break;
end

if isempty(chosen)
    error('vsw:sac:structure', ...
        ['"%s" does not have a consistent SAC header: delta/npts are ' ...
         'implausible or the file is truncated.'], file);
end

S = struct();
S.byteOrder     = chosen.order;
S.delta         = chosen.delta;
S.npts          = chosen.npts;
S.iftype        = chosen.iftype;
S.expectedBytes = chosen.needed;
S.fileBytes     = fileBytes;
S.b             = readF32(raw, 5*4, chosen.order);    % float word 6
S.e             = readF32(raw, 6*4, chosen.order);    % float word 7
S.o             = readF32(raw, 7*4, chosen.order);    % float word 8

bytes = raw(633 : 632 + chosen.npts*4);
if strcmp(chosen.order, 'big')
    bytes = swapBytes4(bytes);
end
S.data = double(typecast(uint8(bytes), 'single'));
S.data = S.data(:);

if fileBytes > chosen.needed
    S.extraBytes = fileBytes - chosen.needed;
else
    S.extraBytes = 0;
end
end

% =======================================================================
function v = readF32(raw, off, order)
bb = uint8(raw(off+1 : off+4));
if strcmp(order, 'big'), bb = bb(end:-1:1); end
v = double(typecast(bb, 'single'));
end

function v = readI32(raw, off, order)
bb = uint8(raw(off+1 : off+4));
if strcmp(order, 'big'), bb = bb(end:-1:1); end
v = double(typecast(bb, 'int32'));
end

function b = swapBytes4(b)
b = reshape(b, 4, []);
b = b(end:-1:1, :);
b = b(:).';
end
