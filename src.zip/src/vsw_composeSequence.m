function C = vsw_composeSequence(P, opts)
%VSW_COMPOSESEQUENCE  M-segment phase-rotation sequence (Sorkin/Rietsch,
%   03 §2.2 "序列"): initial phase of segment k is 2*pi*(k-1)/M.
%
%   Returns an M-by-N matrix (one row per segment) plus the concatenated
%   vector with segment gaps.

if nargin < 2, opts = struct(); end
if ~isfield(opts, 'gapMs'), opts.gapMs = 0; end
M = max(1, round(P.sweep.sequenceLength));

rows = [];
amps = [];
for k = 1:M
    Q = P;
    Q.sweep.initialPhaseDeg = mod(P.sweep.initialPhaseDeg + 360*(k-1)/M, 360);
    R = vsw_generate(Q, struct('figure', false, 'saveDir', ''));
    rows(:, k) = R.derived.signal; %#ok<AGROW>
    if k == 1
        dt = R.D.dtS; N = R.D.N;
    end
end
C.matrix = rows;
C.phaseRotationDeg = (0:M-1) * (360/M);
C.dtS = dt;

ng = round(opts.gapMs / (dt*1e3));
gap = zeros(ng, 1);
seq = [];
for k = 1:M
    seq = [seq; rows(:,k); gap]; %#ok<AGROW>
end
C.signal = seq;
C.tAxisS = (0:numel(seq)-1).' * dt;
end
