function info = vsw_writeVsci(R, fileName, opts)
%VSW_WRITEVSCI  INOVA Vib Pro SCIO .vsci export (07 §3).
%
%   info = vsw_writeVsci(R, fileName)
%   info = vsw_writeVsci(R, fileName, opts)
%
%   Fixed 4000 samples/s (0.25 ms).  Each line is a 21-character SCIO
%   record: sample number | envelope (0..32676) | phase code.
%
%   The phase is stored so that the default reader convention
%   x = envelope * sin(phase) reconstructs the generated signal.  Set
%   opts.phaseConvention = 'cos' to store the analytic phase directly.
%   The sin/cos zero reference is not confirmed by the box manual; see
%   contract item C-13.
%
%   opts.writeExtendedStanza is not used: SCIO has no comment records.
%   This writer follows the documented layout only and does not claim
%   box compatibility.

if nargin < 3, opts = struct(); end
if nargin < 2 || isempty(fileName)
    fileName = fullfile(pwd, [R.meta.signalId '.vsci']);
end

conv = 'sin';
if isfield(opts, 'phaseConvention') && ~isempty(opts.phaseConvention)
    conv = lower(strtrim(opts.phaseConvention));
end
if ~any(strcmp(conv, {'sin', 'cos'}))
    error('vsw:vsci:phase', ...
        'opts.phaseConvention must be sin or cos (got "%s").', conv);
end

fsOut = 4000;
[y, rs] = vsw_resampleUniform(R.derived.signal, R.D.dtS, fsOut);
[env, phi] = analyticSignal(y);
pk = max(env);
if pk > 1 + 1e-9
    error('vsw:vsci:range', ...
        ['.vsci envelope is normalised to 0..1 (full scale 32676), but ' ...
         'the resampled signal envelope peaks at %.6g. Lower ' ...
         'drive.amplitudeFraction or scale the signal first.'], pk);
end

envCode = round(env * 32676);
envCode = min(max(envCode, 0), 32676);

phaseDeg = phi * 180/pi;
if strcmp(conv, 'sin')
    % analytic signal gives x = env*cos(phi); sin(phi+90) = cos(phi).
    phaseDeg = phaseDeg + 90;
end
code = round(phaseDeg * 65536 / 360);
code = mod(code + 32768, 65536) - 32768;

n = numel(y);
fid = fopen(fileName, 'wb');
if fid < 0
    error('vsw:vsci:open', 'Cannot open "%s" for writing.', fileName);
end
try
    fprintf(fid, '%7d%7d%7d\r\n', [0:n-1; envCode.'; code.']);
    fclose(fid);
catch ME
    fclose(fid);
    rethrow(ME);
end

info = struct('fileName', fileName, 'format', 'vsci', ...
    'sampleRate', fsOut, 'dtMs', 1000/fsOut, 'nSamples', n, ...
    'records', n, 'sequenceStart', 0, 'phaseConvention', conv, ...
    'envelopeFullScale', 32676, 'phaseCodeFullScale', 65536, ...
    'envelopePeak', pk, 'resample', rs, 'fileBytes', dir(fileName).bytes);
end

% =======================================================================
function [env, phi] = analyticSignal(x)
x = x(:);
n = numel(x);
X = fft(x);
h = zeros(n, 1);
if mod(n, 2) == 0
    h(1) = 1; h(n/2 + 1) = 1; h(2:n/2) = 2;
else
    h(1) = 1; h(2:(n+1)/2) = 2;
end
z = ifft(X .* h);
env = abs(z);
phi = unwrap(angle(z));
end
