function vsw_printQc(R)
%VSW_PRINTQC  Compact console table of the QC items.
fprintf('\n=== %s ===\n', R.meta.signalId);
fprintf('%-5s %-38s %-4s %12s %12s  %s\n', 'id', 'check', 'ok', 'value', 'limit', 'detail');
for ii = 1:numel(R.qc.items)
    it = R.qc.items(ii);
    if isnan(it.pass)
        ok = 'rec';
    elseif it.pass
        ok = 'PASS';
    else
        ok = 'FAIL';
    end
    if ~it.applicable, ok = 'n/a'; end
    fprintf('%-5s %-38s %-4s %12.4g %12.4g  %s\n', ...
        it.id, it.name, ok, it.value, it.threshold, it.detail);
end
fprintf('overall: %s   design: %s   generation: %s\n', ...
    tf(R.qc.pass), tf(R.qc.designPass), tf(R.qc.generationPass));
for ii = 1:numel(R.warnings)
    fprintf('WARNING: %s\n', R.warnings{ii});
end
end

function s = tf(v)
if v, s = 'PASS'; else, s = 'FAIL'; end
end
