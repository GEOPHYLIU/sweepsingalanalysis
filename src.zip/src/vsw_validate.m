function warnings = vsw_validate(P)
%VSW_VALIDATE  Pre-generation checks A1-A9 (01 §4.1), all hard except A7.
%
%   Returns a cell array of warning strings.  Every hard violation raises an
%   error with identifier vsw:validate:<code>.

C = vsw_constants();
D = vsw_prepare(P);
warnings = {};

% ---- A0: registry membership ------------------------------------------
map = vsw_registry();
if ~isKey(map, P.sweep.type)
    error('vsw:validate:A0', ...
        'Unknown sweep type "%s". Known: %s', P.sweep.type, strjoin(keys(map), ', '));
end

% ---- A1: frequency ordering versus direction ---------------------------
f1 = P.sweep.f1Hz; f2 = P.sweep.f2Hz;
if ~(isfinite(f1) && isfinite(f2)) || min(f1, f2) <= 0 || f1 == f2
    error('vsw:validate:A1', 'A1: need 0 < min(f1,f2) and f1 ~= f2.');
end
if strcmpi(P.sweep.direction, 'up')
    if ~(f1 < f2)
        error('vsw:validate:A1', 'A1: direction=up requires f1 < f2 (start/stop).');
    end
elseif strcmpi(P.sweep.direction, 'down')
    if ~(f1 > f2)
        error('vsw:validate:A1', 'A1: direction=down requires f1 > f2 (start/stop).');
    end
else
    error('vsw:validate:A1', 'A1: direction must be ''up'' or ''down''.');
end

% ---- A2: Nyquist -------------------------------------------------------
if max(f1, f2) > C.NYQUIST_FRACTION * D.fNyqHz
    error('vsw:validate:A2', ...
        'A2: max(f1,f2) = %.3f Hz exceeds 0.9*fNyq = %.3f Hz.', ...
        max(f1, f2), C.NYQUIST_FRACTION * D.fNyqHz);
end

% ---- A10: wide-band sweep (warning only) ------------------------------
if ~any(strcmpi(P.sweep.type, {'pseudoRandom', 'coded', 'variSweep'}))
    nOct = log2(max(f1, f2) / min(f1, f2));
    if nOct >= 2.5
        warnings{end+1} = sprintf( ...
            ['A10: N_oct = %.2f >= 2.5 octaves; correlation side lobes may ' ...
             'be elevated. This is a warning only.'], nOct);
    end
end

% ---- A3: integer sample count -----------------------------------------
ratio = P.sweep.lengthMs / P.sweep.dtMs;
if abs(ratio - round(ratio)) > 1e-9 || ratio < 1
    error('vsw:validate:A3', 'A3: lengthMs must be a positive integer multiple of dtMs.');
end
if ~any(abs(P.sweep.dtMs - C.ALLOWED_DT_MS) < 1e-12)
    warning('vsw:validate:dtMs', ...
        'dtMs = %g is outside the recommended set {1, 2} ms.', P.sweep.dtMs);
end

% ---- A4: taper budget --------------------------------------------------
if P.taper.startMs < 0 || P.taper.endMs < 0
    error('vsw:validate:A4', 'A4: taper lengths must be non-negative.');
end
if P.taper.startMs + P.taper.endMs > 0.5 * P.sweep.lengthMs
    error('vsw:validate:A4', ...
        'A4: startMs + endMs = %g ms exceeds half the sweep length.', ...
        P.taper.startMs + P.taper.endMs);
end

% ---- A5: damping factor ------------------------------------------------
if strcmpi(P.sweep.type, 'dampedRicker') && ...
        strcmpi(P.wavelet.waveletType, 'dampedRicker')
    if P.wavelet.dampingFactor < 1
        error('vsw:validate:A5', 'A5: dampingFactor B must be >= 1.');
    end
end

% ---- A6: target spectrum arrays ---------------------------------------
if any(strcmpi(P.sweep.type, {'targetSpectrum', 'analogSpectrum'}))
    f = P.wavelet.targetFreqAxis(:);
    A = P.wavelet.targetSpectrum(:);
    if numel(f) ~= numel(A) || numel(f) < 3
        error('vsw:validate:A6', 'A6: targetSpectrum/targetFreqAxis length mismatch or too short.');
    end
    if any(diff(f) <= 0)
        error('vsw:validate:A6', 'A6: targetFreqAxis must be strictly increasing.');
    end
    if any(A < 0)
        error('vsw:validate:A6', 'A6: targetSpectrum must be non-negative.');
    end
end

% ---- A7: main frequency inside the band (warning) ----------------------
if any(strcmpi(P.sweep.type, {'dampedRicker', 'customWavelet'})) && ...
        ~strcmpi(P.wavelet.waveletType, 'yu')
    f0 = P.wavelet.mainFreqHz;
    if f0 < D.fLo || f0 > D.fHi
        warnings{end+1} = sprintf( ...
            'A7: f0 = %.3f Hz lies outside [%g, %g] Hz; the spectrum will be clipped and may become double-lobed.', ...
            f0, D.fLo, D.fHi);
    end
    if P.wavelet.lobeWidthRatio < 1
        error('vsw:validate:A7b', 'A7b: lobeWidthRatio must be >= 1.');
    end
end

% ---- A8: drive curve coverage -----------------------------------------
if ~isempty(P.drive.driveCurve)
    dc = P.drive.driveCurve;
    if size(dc, 2) ~= 2 || size(dc, 1) < 2
        error('vsw:validate:A8', 'A8: driveCurve must be an n-by-2 [Hz, D] array.');
    end
    if dc(1,1) > D.fLo || dc(end,1) < D.fHi
        error('vsw:validate:A8', 'A8: driveCurve must cover [min(f1,f2), max(f1,f2)].');
    end
    if any(dc(:,2) <= 0) || any(dc(:,2) > 1)
        error('vsw:validate:A8', 'A8: driveCurve values must satisfy 0 < D <= 1.');
    end
end

% ---- A11: Yu wavelet band and wavelet-type enum -----------------------
wt = lower(P.wavelet.waveletType);
if ~any(strcmp(wt, {'dampedricker', 'yu', 'custom'}))
    error('vsw:validate:waveletType', ...
        'waveletType must be ''dampedRicker'', ''yu'' or ''custom''.');
end
if strcmp(wt, 'yu')
    p = P.wavelet.yuFreqLowerHz;
    q = P.wavelet.yuFreqUpperHz;
    if ~(isfinite(p) && isfinite(q) && 0 < p && p < q)
        error('vsw:validate:A11', ...
            'A11: waveletType=yu requires 0 < yuFreqLowerHz < yuFreqUpperHz.');
    end
    if q < D.fLo || p > D.fHi
        error('vsw:validate:A11', ...
            'A11: Yu band [%g, %g] Hz does not intersect the sweep band [%g, %g] Hz.', ...
            p, q, D.fLo, D.fHi);
    end
end

% ---- drive source model and control curve -----------------------------
if ~isempty(P.drive.sourceModel) && ...
        ~(ischar(P.drive.sourceModel) || isstruct(P.drive.sourceModel))
    error('vsw:validate:sourceModel', ...
        'drive.sourceModel must be a char name or a parameter struct.');
end
sc = P.drive.sourceControlCurve;
if ~isempty(sc)
    if ~isnumeric(sc) || size(sc, 2) ~= 2 || size(sc, 1) < 2
        error('vsw:validate:sourceControlCurve', ...
            'drive.sourceControlCurve must be an n-by-2 [Hz, 0..1] array (n >= 2).');
    end
    if any(~isfinite(sc(:))) || any(diff(sc(:,1)) <= 0)
        error('vsw:validate:sourceControlCurve', ...
            'drive.sourceControlCurve frequencies must be finite and strictly increasing.');
    end
    if any(sc(:,2) <= 0) || any(sc(:,2) > 1)
        error('vsw:validate:sourceControlCurve', ...
            'drive.sourceControlCurve values must satisfy 0 < D <= 1.');
    end
end

% ---- A9: target-spectrum resolvability --------------------------------
if any(strcmpi(P.sweep.type, {'targetSpectrum', 'analogSpectrum', 'dampedRicker', 'customWavelet'}))
    [fg, Ag] = localTargetSpectrum(P, D);
    edge = 0.10 * (D.fHi - D.fLo);              % ignore edge roll-off
    core = fg >= D.fLo + edge & fg <= D.fHi - edge;
    Ac = Ag(core);
    % A9 guards resolvable spectral structure (notches / deep interior
    % minima), not the unavoidable roll-off at the band edges.  With a
    % spectral bin 1/T the dwell of a feature is A_min / integral(A df).
    mins = find(Ac(2:end-1) <= Ac(1:end-2) & Ac(2:end-1) <= Ac(3:end)) + 1;
    if isempty(mins)
        tCell = Inf;
    else
        Amin  = min(Ac(mins));
        tCell = Amin / max(trapz(fg, Ag), eps);
    end
    if tCell < 2 * D.dtS
        error('vsw:validate:A9', ...
            ['A9: minimum spectral bin dwell %.3g ms < %.3g ms; ' ...
             'target spectrum dynamic range exceeds what T and dt can resolve.'], ...
            tCell*1e3, 2*D.dtS*1e3);
    end
end

% ---- type-specific parameter completeness ------------------------------
switch lower(P.sweep.type)
    case 'piecewiselinear'
        fseg = P.sweep.segmentFreqsHz(:);
        lseg = P.sweep.segmentLengthsMs(:);
        if numel(fseg) ~= numel(lseg) + 1 || numel(fseg) < 2
            error('vsw:validate:piecewiseSize', ...
                'piecewiseLinear needs segmentFreqsHz with exactly one more node than segmentLengthsMs.');
        end
        if any(fseg <= 0) || any(lseg <= 0)
            error('vsw:validate:piecewisePositive', ...
                'piecewiseLinear segment frequencies and lengths must be positive.');
        end
        if ~(all(diff(fseg) > 0) || all(diff(fseg) < 0))
            error('vsw:validate:piecewiseMonotonic', ...
                'piecewiseLinear segment frequencies must be strictly monotonic.');
        end
        if abs(sum(lseg) - P.sweep.lengthMs) > 1e-6 * P.sweep.lengthMs
            error('vsw:validate:piecewiseLength', ...
                'piecewiseLinear segment lengths sum to %.6g ms, expected %.6g ms.', ...
                sum(lseg), P.sweep.lengthMs);
        end
        rel = 1e-9 * max(abs(fseg));
        if abs(fseg(1) - f1) > rel || abs(fseg(end) - f2) > rel
            error('vsw:validate:piecewiseEndpoints', ...
                'piecewiseLinear must start at f1 = %g Hz and end at f2 = %g Hz.', f1, f2);
        end
    case 'coded'
        if P.code.chipMs <= 0
            error('vsw:validate:codedChip', 'coded: code.chipMs must be > 0.');
        end
        if P.code.gapMs < 0
            error('vsw:validate:codedGap', 'coded: code.gapMs must be >= 0.');
        end
        if P.code.carrierHz < D.fLo || P.code.carrierHz > D.fHi
            warnings{end+1} = sprintf( ...
                'coded: carrierHz = %.3f Hz is outside [%g, %g] Hz; clamped to the band.', ...
                P.code.carrierHz, D.fLo, D.fHi);
        end
    case 'varisweep'
        if P.sweep.variCount < 1 || abs(P.sweep.variCount - round(P.sweep.variCount)) > 1e-9
            error('vsw:validate:variCount', ...
                'variSweep: variCount must be a positive integer.');
        end
        if P.sweep.variBandJitterPct < 0 || P.sweep.variBandJitterPct >= 100
            error('vsw:validate:variJitter', ...
                'variSweep: variBandJitterPct must satisfy 0 <= jitter < 100.');
        end
end
end

function [fg, Ag] = localTargetSpectrum(P, D)
fg = linspace(D.fLo, D.fHi, max(4001, 4*D.N + 1)).';
switch lower(P.sweep.type)
    case 'dampedricker'
        if strcmpi(P.wavelet.waveletType, 'yu')
            Ag = vsw_yuSpectrum(fg, P.wavelet.yuFreqLowerHz, P.wavelet.yuFreqUpperHz);
        elseif strcmpi(P.wavelet.waveletType, 'custom')
            f0e = P.wavelet.mainFreqHz / P.wavelet.lobeWidthRatio;
            B   = vsw_solveDampingForLobe(P.wavelet.lobeAmpRatio);
            Ag  = vsw_dampedRickerSpectrum(fg, f0e, B);
        else
            Ag = vsw_dampedRickerSpectrum(fg, P.wavelet.mainFreqHz, P.wavelet.dampingFactor);
        end
    case 'customwavelet'
        f0e = P.wavelet.mainFreqHz / P.wavelet.lobeWidthRatio;
        B   = vsw_solveDampingForLobe(P.wavelet.lobeAmpRatio);
        Ag  = vsw_dampedRickerSpectrum(fg, f0e, B);
    otherwise
        f = P.wavelet.targetFreqAxis(:);
        A = P.wavelet.targetSpectrum(:);
        Ag = interp1(f, A, fg, 'linear', 0);
end
Ag = max(Ag(:), 0);
if max(Ag) > 0, Ag = Ag / max(Ag); end
end
