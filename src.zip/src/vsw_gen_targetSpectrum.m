function G = vsw_gen_targetSpectrum(P, D)
%VSW_GEN_TARGETSPECTRUM  Arbitrary correlation-wavelet spectrum A(f).
%   Route 1 of 01 §4.3: |S~|^2 proportional to A(f).

f = P.wavelet.targetFreqAxis(:);
A = P.wavelet.targetSpectrum(:);
if numel(f) ~= numel(A) || numel(f) < 3
    error('vsw:gen:targetSpectrumSize', ...
        'targetSpectrum and targetFreqAxis must be same length (>= 3).');
end
if any(diff(f) <= 0)
    error('vsw:gen:targetSpectrumMonotonic', 'targetFreqAxis must be strictly increasing.');
end
if any(A < 0)
    error('vsw:gen:targetSpectrumNegative', 'targetSpectrum must be non-negative.');
end

% Band-limited slice; A9 guarantees resolvability of the smallest nonzero bin.
fg = linspace(D.fLo, D.fHi, max(4001, 4*D.N + 1)).';
Ag = interp1(f, A, fg, 'linear', 0);
Ag = max(Ag, 0);

G.kind      = 'spectrum';
G.pathLabel = 'targetSpectrum';
G.sweepCode = 4;
G.zeroCrossSpacingS = [];
G.targetAmpNominal  = A;
G.targetFreqNominal = f;
G = vsw_freqFromSpectrum(P, D, fg, Ag, G);
M = vsw_bandlimitedMetrics(G.targetFreqAxis, G.targetAmp);
G.targetSideLobeDB = M.sideLobeDB;
end
