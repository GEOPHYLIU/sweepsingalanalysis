function R = vsw_generate(userP, opts)
%VSW_GENERATE  Full pipeline: P -> validate -> generate -> assemble ->
%   analysis -> QC (03 §4).  Views and writers consume R only.
%
%   R = vsw_generate(P)
%   R = vsw_generate(P, struct('figure',true,'saveDir','out','throwOnFail',false))
%
%   The analysis layer runs exactly once; R.analysis is shared by the four
%   views, the QC layer and the SEG-Y writer.

if nargin < 2, opts = struct(); end
opts = fillOpts(opts);

P = vsw_mergeParams(userP);
warnings = vsw_validate(P);
D = vsw_prepare(P);

map = vsw_registry();
gen = map(P.sweep.type);
G = gen(P, D);

S = vsw_assemble(P, D, G);
A = vsw_analyze(P, D, S, G);

if P.distortion.enable
    X = vsw_applyDistortion(P, D, S);
    A.pilotSignal       = X.pilotSignal;
    A.distortedSignal   = X.distortedSignal;
    A.corrLagS          = X.corrLagS;
    A.corrProfile       = X.corrProfile;
    A.ghostTheoryTime   = X.ghostTheoryTime;
    A.ghostMeasuredTime = X.ghostMeasuredTime;
    A.lowFreqHarmonicDB = X.lowFreqHarmonicDB;
end

Q = vsw_qc(P, D, S, A);

% ---- output self-description rules (04 §8.1) --------------------------
nonStd = G.sweepCode == 4;
if nonStd
    P.output.writeExtendedStanza = true;
end
if ~P.output.writeSweepParamsToBinary && ~P.output.writeExtendedStanza
    P.output.writeExtendedStanza = true;
    warnings{end+1} = ...
        'writeSweepParamsToBinary=false forces writeExtendedStanza=true (04 §8.1).';
end

% ---- assemble the read-only result ------------------------------------
R.P         = P;
R.D         = D;
R.G         = G;
R.signal    = S.signal;
R.analysis  = A;
R.qc        = Q;
R.warnings  = warnings;
R.meta      = P.meta;
R.meta.createdAt = datestr(now, 'yyyy-mm-dd HH:MM:SS'); %#ok<DATST,TNOW1>
R.meta.signalId  = vsw_signalId(P);

R.derived.tAxisS    = D.tAxisS;
R.derived.signal    = S.signal;
R.derived.envelope  = S.envelope;
R.derived.fOfTS     = S.fOfTS;
R.derived.fAtT      = S.fAtT;
R.derived.phaseRad  = S.phaseRad;
R.derived.targetAmp = A.targetAmp;
R.derived.fNyqHz    = D.fNyqHz;
R.derived.nSamples  = D.N;

if ~Q.generationPass
    msg = sprintf('Generation checks failed: %s', strjoin(Q.failed, ', '));
    if opts.throwOnFail
        error('vsw:qc:generationFail', '%s', msg);
    else
        warning('vsw:qc:generationFail', '%s', msg);
    end
end

if opts.figure
    vsw_plotFourViews(R, opts);
end
if ~isempty(opts.saveDir)
    R.saved = vsw_save(R, opts.saveDir);
end
end

function opts = fillOpts(opts)
def = struct('figure', false, 'saveDir', '', 'throwOnFail', false, ...
             'spectrumScale', 'db', 'freqScale', 'linear', ...
             'showFreqOnTime', false, 'acfWindowS', 0.5, 'exportBase', '');
names = fieldnames(def);
for ii = 1:numel(names)
    if ~isfield(opts, names{ii})
        opts.(names{ii}) = def.(names{ii});
    end
end
end
