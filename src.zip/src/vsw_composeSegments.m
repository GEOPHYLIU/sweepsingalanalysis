function C = vsw_composeSegments(P, segDefs, opts)
%VSW_COMPOSESEGMENTS  Piecewise sweep: concatenate independently designed
%   segments, optionally with a zero gap (03 §2.2 "分段").
%
%   segDefs is a struct array with fields f1Hz, f2Hz, lengthMs and optional
%   sweepConstant, taper; a missing gapMs inserts silence.

if nargin < 3, opts = struct(); end
if ~isfield(opts, 'gapMs'), opts.gapMs = 0; end

sig = []; t = []; segs = struct('startS', {}, 'endS', {}, 'type', {});
t0 = 0;
for k = 1:numel(segDefs)
    Q = P;
    Q.sweep.f1Hz = segDefs(k).f1Hz;
    Q.sweep.f2Hz = segDefs(k).f2Hz;
    Q.sweep.lengthMs = segDefs(k).lengthMs;
    if isfield(segDefs(k), 'sweepConstant')
        Q.sweep.sweepConstant = segDefs(k).sweepConstant;
    end
    if isfield(segDefs(k), 'type')
        Q.sweep.type = segDefs(k).type;
    end
    if isfield(segDefs(k), 'taper')
        Q.taper = segDefs(k).taper;
    end
    R = vsw_generate(Q, struct('figure', false, 'saveDir', ''));
    sig = [sig; R.derived.signal]; %#ok<AGROW>
    t   = [t;   t0 + R.derived.tAxisS]; %#ok<AGROW>
    segs(k).startS = t0;
    segs(k).endS   = t0 + R.D.T;
    segs(k).type   = Q.sweep.type;
    segs(k).qc     = R.qc.pass;
    t0 = t0 + R.D.T;
    if k < numel(segDefs) && opts.gapMs > 0
        ng = round(opts.gapMs / P.sweep.dtMs);
        sig = [sig; zeros(ng,1)]; %#ok<AGROW>
        t   = [t; t0 + (0:ng-1).'*P.sweep.dtMs*1e-3]; %#ok<AGROW>
        t0 = t0 + ng*P.sweep.dtMs*1e-3;
    end
end
C.signal = sig;
C.tAxisS = t;
C.segments = segs;
C.totalS = t0;
end
