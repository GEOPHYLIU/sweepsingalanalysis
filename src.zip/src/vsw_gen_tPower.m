function G = vsw_gen_tPower(P, D)
%VSW_GEN_TPOWER  t-Power sweep, f(t) = f1 + (f2-f1)*(t/T)^p.
%   SweepConstant carries the exponent p (> 0); p = 1 is linear.

p   = P.sweep.sweepConstant;
if p == 0, p = 1; end
flo = D.fLo; fhi = D.fHi;
G.kind      = 'analytic';
G.fUp       = @(u) flo + (fhi - flo) * u.^p;
G.FAup      = @(u) flo * u + (fhi - flo) * u.^(p + 1) / (p + 1);
G.pathLabel = 'analytic';
G.sweepCode = 2;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G = vsw_analyticGrid(D, G);
end
