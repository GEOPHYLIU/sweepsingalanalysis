function C = vsw_constants()
%VSW_CONSTANTS  Frozen conventions of the parameter layer (01 §6, C1-C5).
%
%   Every numerical convention that could be "quietly written differently"
%   lives here. Algorithm files must reference these fields, not literals.

C.CODE_VERSION            = 'vsw-matlab 0.3.0';
C.N_SAMPLES_CONVENTION    = 'N = lengthMs/dtMs, endpoint excluded, last sample at T-dt';
C.PHASE_REF               = 'sin';
C.INT_RULE                = 'trapezoid';
C.DEFAULT_DT_MS           = 1;
C.ALLOWED_DT_MS           = [1 2];
C.PHASE_TOL_ANALYTIC_RAD  = 1e-6;   % C1a analytic types
C.PHASE_TOL_NUMERIC_RAD   = 1e-3;   % C1a numerically inverted types
C.NYQUIST_FRACTION        = 0.9;    % A2
C.DEG2RAD                 = pi/180;
C.EPS                     = 1e-12;

% Optional comparison mode with the legacy 12001-point files (01 §6, off by
% default and never part of acceptance).
C.LEGACY_INCLUDE_ENDPOINT = false;
end
