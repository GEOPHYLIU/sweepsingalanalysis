function S = vsw_assemble(P, D, G)
%VSW_ASSEMBLE  Complex phase accumulation -> envelope/taper -> s(t) (03 §4).
%
%   For analytic types the phase comes from the closed-form integral FAup,
%   so C1a's 1e-6 rad target is met by construction.  Spectrum types use the
%   trapezoidal rule (C3) on the allocated instantaneous frequency.

[w, tinfo] = vsw_taperProfile(P, D);
env  = P.drive.amplitudeFraction * w;
envNo = P.drive.amplitudeFraction * ones(D.N, 1);

switch lower(G.kind)
    case 'analytic'
        f      = G.fOfTS;
        phase  = G.phaseRad;
        fAtT   = G.fAtT;
    case 'spectrum'
        f      = G.fOfTS;
        phase  = trapezoidPhase(f, D.dtS);
        fAtT   = G.fAtT;
    case 'raw'
        f      = G.fOfTS;
        phase  = G.phaseRad;
        fAtT   = G.fAtT;
    otherwise
        error('vsw:assemble:kind', 'Unknown generator kind "%s".', G.kind);
end

f     = reshape(f, [], 1);
phase = reshape(phase, [], 1) + D.phi0Rad;

if strcmpi(G.kind, 'raw')
    sg   = G.signalRaw(:) .* env;
    sgNo = G.signalRaw(:) .* envNo;
else
    sg   = env   .* sin(phase);
    sgNo = envNo .* sin(phase);
end

S.signal        = sg;
S.signalNoTaper = sgNo;
S.envelope      = env;
S.taper         = w;
S.taperDetails  = tinfo;
S.phaseRad      = phase;
S.fOfTS         = f;
S.fAtT          = fAtT;
S.fAt0          = G.fAt0;
S.kind          = G.kind;
S.monotonicApplicable = G.monotonicApplicable;
end

function phi = trapezoidPhase(f, dt)
% Trapezoidal cumulative integral (C3), phi(1) = 0.
phi = zeros(size(f));
if numel(f) > 1
    phi(2:end) = cumsum(pi * dt * (f(1:end-1) + f(2:end)));
end
end
