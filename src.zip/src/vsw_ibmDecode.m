function x = vsw_ibmDecode(b)
%VSW_IBMDECODE  IBM float32 bytes (N x 4, big-endian) -> double column.
b = uint8(b);
if size(b, 2) ~= 4
    error('vsw:ibm:size', 'IBM input must be N-by-4 bytes.');
end
b1 = double(b(:,1)); b2 = double(b(:,2));
b3 = double(b(:,3)); b4 = double(b(:,4));
sgn  = floor(b1 / 128);
e    = mod(b1, 128);
mant = b2*2^16 + b3*2^8 + b4;
x = (-1).^sgn .* (mant / 2^24) .* 16.^(e - 64);
x(mant == 0) = 0;
end
