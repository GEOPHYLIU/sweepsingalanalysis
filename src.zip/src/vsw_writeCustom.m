function info = vsw_writeCustom(R, fileName, opts)
%VSW_WRITECUSTOM  Sercel .custom ASCII sweep export (07 §2).
%
%   info = vsw_writeCustom(R, fileName)
%   info = vsw_writeCustom(R, fileName, opts)
%
%   Fixed 2000 samples/s (0.5 ms), one signed amplitude per line, normalised
%   to -1..+1.  The signal is Fourier-resampled from the generation dt to the
%   box rate.  The first line is '#IDENTIFIER  <filename>'; remaining comment
%   lines start with '#'.
%
%   opts.writeFlagColumn (default false): also write a trailing TRUE column
%   to mirror the Sercel sample files found in this repository.  The flag
%   semantics are not documented, so the default stays with the single-column
%   definition in 07 §2.
%
%   This writer targets the documented .custom layout only.  It does not
%   claim box compatibility; see 07 §5 / §7.

if nargin < 3, opts = struct(); end
if nargin < 2 || isempty(fileName)
    fileName = fullfile(pwd, [R.meta.signalId '.custom']);
end
writeFlag = isfield(opts, 'writeFlagColumn') && opts.writeFlagColumn;

fsOut = 2000;
[y, rs] = vsw_resampleUniform(R.derived.signal, R.D.dtS, fsOut);
pk = max(abs(y));
if pk > 1 + 1e-9
    error('vsw:custom:range', ...
        ['.custom is normalised to -1..+1, but the resampled signal peaks ' ...
         'at %.6g. Lower drive.amplitudeFraction or scale the signal first.'], pk);
end

[~, base, ext] = fileparts(fileName);
fid = fopen(fileName, 'wb');
if fid < 0
    error('vsw:custom:open', 'Cannot open "%s" for writing.', fileName);
end

try
    fprintf(fid, '#IDENTIFIER  %s\r\n', [base ext]);
    fprintf(fid, '#COMMENT   %s\r\n', R.meta.codeVersion);
    fprintf(fid, '#COMMENT   %s %s %g-%g Hz %g ms, dt=0.5 ms, N=%d\r\n', ...
        R.P.sweep.type, R.P.sweep.direction, R.P.sweep.f1Hz, R.P.sweep.f2Hz, ...
        R.P.sweep.lengthMs, numel(y));
    fprintf(fid, '#COMMENT   sampleRate=2000  amplitude=-1..+1  resample=%s\r\n', ...
        rs.method);
    if writeFlag
        fprintf(fid, '  %.8f   TRUE\r\n', y);
    else
        fprintf(fid, '  %.8f\r\n', y);
    end
    fclose(fid);
catch ME
    fclose(fid);
    rethrow(ME);
end

info = struct('fileName', fileName, 'format', 'custom', ...
    'sampleRate', fsOut, 'dtMs', 1000/fsOut, 'nSamples', numel(y), ...
    'peak', pk, 'flagColumn', writeFlag, 'resample', rs, ...
    'fileBytes', dir(fileName).bytes);
end
