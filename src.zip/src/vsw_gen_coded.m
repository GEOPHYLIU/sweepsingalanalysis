function G = vsw_gen_coded(P, D)
%VSW_GEN_CODED  Golay complementary BPSK sweep (03 §2.1).
%   A pair (A, B) is transmitted back to back with an optional gap, each chip
%   phase-switching a constant carrier.  Golay pairs have complementary
%   autocorrelation side lobes, so the pair sums to a single impulse.
%   Non-monotonic by construction: B5/B6 report "not applicable".

order = max(5, min(12, round(P.code.order)));
[A, B] = localGolay(order);

chipN = max(1, round(P.code.chipMs / P.sweep.dtMs));
gapN  = max(0, round(P.code.gapMs / P.sweep.dtMs));
need  = ceil(D.N / chipN) + 1;

gapChips = min(gapN, max(need - 2, 0));
avail    = max(need - gapChips, 2);
na       = max(1, ceil(avail / 2));
nb       = max(1, avail - na);

chips = zeros(need, 1);
chips(1:na) = localTile(A, na);
i0 = na + gapChips;
chips(i0+1:i0+nb) = localTile(B, nb);

expanded = reshape(repmat(chips(:).', chipN, 1), [], 1);
if numel(expanded) < D.N
    expanded(end+1:D.N, 1) = 0;
end
chips = expanded(1:D.N);               % +1 / -1 with zero gap chips

fc  = min(max(P.code.carrierHz, D.fLo), D.fHi);
phi = 2*pi*fc*D.tAxisS + D.phi0Rad;

G.kind       = 'raw';
G.pathLabel  = 'coded';
G.sweepCode  = 4;
G.signalRaw  = chips .* sin(phi);
G.phaseRad   = 2*pi*fc*D.tAxisS;
G.fOfTS      = fc * ones(D.N, 1);
G.fAtT       = fc;
G.fAt0       = fc;
G.fOfT       = @(tt) fc * ones(size(tt));
G.monotonicApplicable = false;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G.codeOrder  = order;
G.codePair   = 'golay';
G.carrierHz  = fc;
G.gapMs      = P.code.gapMs;
end

function out = localTile(v, n)
v = v(:);
rep = ceil(n / numel(v));
out = repmat(v, rep, 1);
out = out(1:n);
end

function [A, B] = localGolay(order)
% Recursive Golay pair: A' = [A B], B' = [A -B].
A = 1;
B = 1;
for k = 1:order
    Anew = [A B];
    Bnew = [A -B];
    A = Anew;
    B = Bnew;
end
end
