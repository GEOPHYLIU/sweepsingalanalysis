function A = vsw_analyze(P, D, S, G)
%VSW_ANALYZE  One-pass analysis layer (05 §1).  FFT, ACF and QC metrics are
%   computed exactly once; the views and the QC layer only read these arrays.

N   = D.N;
T   = D.T;
sig = S.signal(:);
phi = S.phaseRad(:);

% ---- 1.2 frequency domain ---------------------------------------------
Nf = floor(N/2) + 1;
freq = (0:Nf-1).' / T;

A.freqAxisHz   = freq;
A.ampSpectrum  = oneSidedAmp(sig, Nf);
A.ampSpectrumNoTaper = oneSidedAmp(S.signalNoTaper(:), Nf);
A.ampSpectrumDB = 20*log10(A.ampSpectrum / max(max(A.ampSpectrum), eps) + eps);

if isfield(G, 'targetAmp') && ~isempty(G.targetAmp)
    A.targetAmp = interp1(G.targetFreqAxis, G.targetAmp, freq, 'linear', 0);
else
    A.targetAmp = [];
end

% ---- 1.3 autocorrelation ----------------------------------------------
[A.acfLagS, A.acfWaveform] = localACF(sig, D.dtS);
A.acfNormalized = A.acfWaveform / max(abs(A.acfWaveform(N)), eps);
A.acfEnvelope   = analyticEnvelope(A.acfNormalized);
A.acfEnvelope   = A.acfEnvelope / max(max(A.acfEnvelope), eps);
A.acfDB = 20*log10(abs(A.acfNormalized) + eps);

[A.zeroCrossLagS, A.zeroCrossS, iL, iR] = mainLobeCrossings( ...
    A.acfLagS, A.acfNormalized, N);
[A.sideLobeLagS, A.sideLobeDB] = firstSideLobe( ...
    A.acfLagS, A.acfNormalized, iL, iR);
% B4 needs the *envelope* main lobe: the raw ACF crosses zero once per
% carrier half-cycle inside that lobe, so raw crossings would integrate only
% a fraction of one cycle.  The envelope is used only to locate the interval;
% the energy itself still comes from acfWaveform (05 §1.3).
[iEL, iER] = envelopeMainLobe(A.acfEnvelope, N, D.dtS);
if isfinite(iEL) && isfinite(iER)
    e = A.acfWaveform.^2;
    A.mainLobeEnergyRatio = sum(e(min(iEL,iER):max(iEL,iER))) / max(sum(e), eps);
    A.mainLobeLagS = [A.acfLagS(iEL), A.acfLagS(iER)];
else
    A.mainLobeEnergyRatio = NaN;
    A.mainLobeLagS = [NaN NaN];
end

% ---- 1.4 phase and error ----------------------------------------------
A.phaseRad = phi;
[err, tol] = vsw_phaseReference(D, G, phi);
A.phaseErrorRad = err;
A.phaseTolRad   = tol;
A.phaseErrorNumericRad = numericVsAnalytic(D, G, phi);

% ---- B10 support: edge-band energy with and without taper -------------
pct  = P.qc.edgeBandPct / 100;
band = (freq >= D.fLo) & (freq <= D.fHi);
edgeW = pct * (D.fHi - D.fLo);
edge = band & ((freq <= D.fLo + edgeW) | (freq >= D.fHi - edgeW));
Et = sum(A.ampSpectrum(edge).^2);
En = sum(A.ampSpectrumNoTaper(edge).^2);
A.edgeEnergyRatioDB = 10*log10(max(Et, eps) / max(En, eps));

% ---- bookkeeping for QC ------------------------------------------------
A.theoryZeroCrossS = G.zeroCrossSpacingS;
A.targetSideLobeDB = G.targetSideLobeDB;
A.pathLabel = G.pathLabel;
end

% =======================================================================
function amp = oneSidedAmp(s, Nf)
N = numel(s);
X = fft(s(:));
amp = abs(X(1:Nf)) / N;
if mod(N, 2) == 0
    amp(2:end-1) = 2 * amp(2:end-1);
else
    amp(2:end) = 2 * amp(2:end);
end
end

function env = analyticEnvelope(x)
% 05 §1.3: display-only Hilbert envelope, computed without the Signal
% Processing Toolbox so the standalone EXE keeps the same dependencies.
x = x(:);
N = numel(x);
X = fft(x);
h = zeros(N, 1);
if mod(N, 2) == 0
    h(1) = 1; h(N/2 + 1) = 1; h(2:N/2) = 2;
else
    h(1) = 1; h(2:(N+1)/2) = 2;
end
env = abs(ifft(X .* h));
end

function [iL, iR] = envelopeMainLobe(env, i0, dt)
% Outermost sample of the monotone envelope decay on each side of lag 0.
% If the envelope decays all the way to the record edge (near-single-tone
% sweep) the whole ACF is one lobe; if an interior local minimum is present,
% that minimum separates the main lobe from the side lobes.
env = env(:);
w = max(3, 2*round(0.005/dt) + 1);          % 10 ms smoothing window
es = movmean(env, w);
iL = walkOut(es, i0, -1);
iR = walkOut(es, i0, +1);
end

function i = walkOut(e, i0, dirn)
i = i0;
while (dirn < 0 && i > 2) || (dirn > 0 && i < numel(e) - 1)
    j = i + dirn;
    if e(j) <= e(i) * (1 + 1e-9) + 1e-12
        i = j;
    else
        break;
    end
end
end

function [lag, acf] = localACF(s, dt)
N = numel(s);
M = 2^nextpow2(2*N);
X = fft(s, M);
full = real(ifft(abs(X).^2));
acf = [full(M-N+2:M); full(1:N)];
lag = (-(N-1):(N-1)).' * dt;
end

function [zlag, spacing, iL, iR] = mainLobeCrossings(lag, y, i0)
% First sign change on each side of lag = 0, linearly interpolated.
iL = NaN; iR = NaN; zlag = [NaN NaN]; spacing = NaN;

i = i0;
while i > 1
    if y(i-1) <= 0 && y(i) > 0
        iL = i; break;
    end
    i = i - 1;
end
i = i0;
while i < numel(y)
    if y(i) >= 0 && y(i+1) < 0
        iR = i + 1; break;
    end
    i = i + 1;
end

if ~isnan(iL)
    frac = y(iL) / (y(iL) - y(iL-1));
    zlag(1) = lag(iL-1) + frac * (lag(iL) - lag(iL-1));
end
if ~isnan(iR)
    frac = y(iR-1) / (y(iR-1) - y(iR));
    zlag(2) = lag(iR-1) + frac * (lag(iR) - lag(iR-1));
end
if all(isfinite(zlag))
    spacing = zlag(2) - zlag(1);
end
end

function [lagPeak, dB] = firstSideLobe(lag, y, iL, iR)
lagPeak = NaN; dB = NaN;
if isnan(iL) || isnan(iR), return; end
absy = abs(y);
[~, k] = max(absy(min(iL,iR):max(iL,iR)));  %#ok<ASGLU>
% search right and left of the main lobe for the first local maximum
cand = [];
for dirn = [-1 1]
    if dirn > 0
        idx = iR+1 : numel(y)-1;
    else
        idx = iL-1 : -1 : 2;      % outward from the main lobe
    end
    for ii = idx
        if absy(ii) >= absy(ii-1) && absy(ii) >= absy(ii+1)
            cand(end+1) = ii; %#ok<AGROW>
            break;
        end
    end
end
if isempty(cand), return; end
[~, k] = max(absy(cand));
ii = cand(k);
lagPeak = lag(ii);
dB = 20*log10(absy(ii) + eps);
end

function [err, tol] = vsw_phaseReference(D, G, phi)
% 03-C1 / 01-C1a.  Analytic types are synthesized from the closed-form
% integral, so the analytic error is exactly zero by construction; the
% 10x-oversampled difference is kept separately as a diagnostic.  Numeric
% inversion types are compared to a 10x reference integration with the
% 1e-3 rad tolerance.
C = vsw_constants();
if strcmpi(G.kind, 'analytic')
    err = zeros(size(phi));
    tol = C.PHASE_TOL_ANALYTIC_RAD;
else
    ref = numericReference(D, G);
    err = (phi - phi(1)) - ref;
    tol = C.PHASE_TOL_NUMERIC_RAD;
end
end

function err = numericVsAnalytic(D, G, phi)
ref = numericReference(D, G);
err = (phi - phi(1)) - ref;
end

function ref = numericReference(D, G)
% 10x oversampled trapezoidal integral of the registered f(t).
tf = linspace(0, D.T, 10*D.N + 1).';
ff = G.fOfT(tf);
ff = reshape(ff, [], 1);
pf = zeros(size(tf));
if numel(tf) > 1
    pf(2:end) = cumsum(pi * (D.dtS/10) * (ff(1:end-1) + ff(2:end)));
end
pf = pf + 0;                       % reference starts at zero
ref = interp1(tf, pf, D.tAxisS, 'linear');
ref = ref - ref(1);
end
