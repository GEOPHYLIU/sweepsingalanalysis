function matFile = vsw_writeMat(R, fileName)
%VSW_WRITEMAT  MAT export carrying waveform, time axis, rate and parameters.
%   Non-standard convenience format (04 §8.2); vsw_importSignal reads x/tS/fs.

if nargin < 2
    fileName = fullfile(pwd, [R.meta.signalId '.mat']);
end
x        = R.derived.signal(:);
tS       = R.D.tAxisS(:);
dtS      = R.D.dtS;
fs       = 1 / dtS;
signalId = R.meta.signalId;
P        = R.P;
meta     = R.meta;
save(fileName, 'x', 'tS', 'dtS', 'fs', 'signalId', 'P', 'meta');
matFile = fileName;
end
