function [y, info] = vsw_resampleUniform(x, dtIn, fsOut)
%VSW_RESAMPLEUNIFORM  Resample a uniformly sampled real signal.
%
%   [y, info] = vsw_resampleUniform(x, dtIn, fsOut)
%
%   Uses base-MATLAB Fourier interpolation (interpft): zero-padding when
%   upsampling and spectral truncation when downsampling, so no Signal
%   Processing Toolbox is required.  The output length is
%   round(numel(x)*dtIn*fsOut), i.e. the same duration as the input.

x = x(:);
if isempty(x)
    error('vsw:resample:empty', 'Cannot resample an empty signal.');
end
if ~(isscalar(dtIn) && isfinite(dtIn) && dtIn > 0)
    error('vsw:resample:dt', 'dtIn must be a positive finite scalar.');
end
if ~(isscalar(fsOut) && isfinite(fsOut) && fsOut > 0)
    error('vsw:resample:fs', 'fsOut must be a positive finite scalar.');
end

fsIn = 1 / dtIn;
nIn  = numel(x);
nOut = max(1, round(nIn * dtIn * fsOut));

if nOut == nIn
    y = x;
    method = 'none';
elseif nIn == 1
    y = repmat(x, nOut, 1);
    method = 'hold';
else
    y = interpft(x, nOut);
    if fsOut < fsIn
        method = 'fourier (spectral truncation)';
    else
        method = 'fourier (zero-padding)';
    end
end

info = struct('fsIn', fsIn, 'fsOut', fsOut, 'nIn', nIn, ...
    'nOut', nOut, 'dtOut', 1/fsOut, 'method', method);
end
