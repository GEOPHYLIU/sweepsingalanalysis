function [f, FA] = vsw_dbOctLaw(u, flo, fhi, n)
%VSW_DBOCTLAW  Stable evaluation of the dB/oct law from 曹务祥 (2006) eq.(7).
%
%   f(u) = flo + (1/n) * log( (exp(n*(fhi-flo)) - 1)*u + 1 )
%   FA(u)= integral_0^u f(v) dv
%
%   For n*(fhi-flo) the exponential overflows in double precision even for
%   the published example (n = 3.3, band 6..96 Hz).  The same expression is
%   evaluated in log space, so the law is preserved bit-for-bit where it is
%   representable.  n -> 0 degenerates to a linear sweep.

u = u(:);
if abs(n) < 1e-9
    f  = flo + (fhi - flo) * u;
    FA = flo * u + 0.5 * (fhi - flo) * u.^2;
    return;
end

A = n * (fhi - flo);
if A > 0
    logb = A + log1p(-exp(-A));          % log(exp(A)-1)
else
    logb = log(expm1(A));                % expm1 safe for A <= 0
end

uSafe = max(u, realmin);
L = zeros(size(u));
pos = u > 0;
z = logb + log(uSafe(pos));
% log(1 + exp(z)) with overflow guard
L(pos) = z + log1p(exp(-z));
if A <= 0
    L(pos) = log1p(exp(z));
end
L(u == 0) = 0;

f = flo + L / n;

% FA(u) = flo*u + (1/n) * [ u*(L-1) + L/b ]
Loverb = zeros(size(u));
if A > 0
    Loverb(pos) = exp(L(pos) - logb);
else
    Loverb(pos) = exp(L(pos) - logb);
end
Loverb(u == 0) = 0;

FA = flo * u + (u .* (L - 1) + Loverb) / n;
FA(u == 0) = 0;
FA = reshape(FA, size(u));
f  = reshape(f,  size(u));
end
