function info = vsw_sniffFormat(file, ext)
%VSW_SNIFFFORMAT  Identify the real format of an external signal file.
%
%   info = vsw_sniffFormat(file)
%   info = vsw_sniffFormat(file, ext)
%
%   The decision is based on magic numbers and structural consistency, not
%   on the file extension.  This is the "真实格式" layer of the external
%   input validation chain: an accessible file is classified before any
%   numeric reader runs, so a renamed file cannot be parsed with the wrong
%   decoder.
%
%   info.format:
%     'wav' | 'mat' | 'mat73' | 'segy' | 'sac' | 'xlsx' | 'xls' |
%     'text' | 'unknown'
%   info.byteOrder : 'little' | 'big' | ''  (binary formats that declare or
%                    reveal it)
%   info.details   : format-specific fields used later for structure checks
%   info.extension : lower-case extension with the leading dot

if nargin < 2 || isempty(ext)
    [~, ~, ext] = fileparts(file);
end
ext = lower(ext);

d = dir(file);
if isempty(d) || d.bytes <= 0
    info = baseInfo(ext, 'unknown');
    return;
end
fileBytes = d.bytes;

fid = fopen(file, 'rb');
if fid < 0
    error('vsw:import:open', 'Cannot open "%s" for reading.', file);
end
head = fread(fid, min(4096, fileBytes), 'uint8=>uint8');
fclose(fid);
head = head(:).';

info = baseInfo(ext, 'unknown');
info.fileBytes = fileBytes;

% ---- RIFF/WAVE --------------------------------------------------------
if numel(head) >= 12 && strcmp(char(head(1:4)), 'RIFF') && ...
        strcmp(char(head(9:12)), 'WAVE')
    info.format = 'wav';
    info.details.riffSize = leU32(head(5:8));
    return;
end

% ---- HDF5 (MAT v7.3) --------------------------------------------------
if numel(head) >= 8 && isequal(head(1:8), ...
        uint8([137 72 68 70 13 10 26 10]))
    info.format = 'mat73';
    return;
end

% ---- MAT v5/v6 --------------------------------------------------------
if numel(head) >= 128
    txt = char(head(1:min(116, numel(head))));
    if strncmp(txt, 'MATLAB', 6)
        info.format = 'mat';
        info.details.endian = char(head(125:126));
        return;
    end
end

% ---- ZIP container (xlsx) ---------------------------------------------
if numel(head) >= 4 && head(1) == 80 && head(2) == 75 && ...
        any(head(3) == [3 5 7])
    % A ZIP is only treated as a workbook when the OOXML parts are visible
    % in the leading bytes.  Larger workbooks may hide the central
    % directory, so the extension is kept as a weak secondary hint.
    early = char(head);
    if contains(early, 'xl/') || ...
            contains(early, '[Content_Types].xml') || ...
            any(strcmp(ext, {'.xlsx', '.xlsm'}))
        info.format = 'xlsx';
        return;
    end
end

% ---- OLE2 container (legacy xls) --------------------------------------
if numel(head) >= 8 && isequal(head(1:8), ...
        uint8([208 207 17 224 161 177 26 225]))
    info.format = 'xls';
    return;
end

% ---- SAC --------------------------------------------------------------
sac = sniffSac(head, fileBytes);
if ~isempty(sac)
    info.format = 'sac';
    info.byteOrder = sac.byteOrder;
    info.details = sac;
    return;
end

% ---- SEG-Y ------------------------------------------------------------
segy = sniffSegy(head, fileBytes);
if ~isempty(segy)
    info.format = 'segy';
    info.byteOrder = 'big';
    info.details = segy;
    return;
end

% ---- box-controller sweep files --------------------------------------
% These are text formats with no binary magic.  SCIO (.vsci/.fsci) is
% identified by its fixed 21-character records; .custom also has a
% distinctive '#IDENTIFIER' first line, so a renamed file can still be
% recognised.
if isTextLike(head)
    if any(strcmp(ext, {'.vsci', '.fsci'})) && hasSciRecords(head)
        info.format = 'sci';
        info.details.subtype = ext(2:end);
        return;
    end
    if strcmp(ext, '.custom') || hasCustomIdentifier(head)
        info.format = 'custom';
        return;
    end
    info.format = 'text';
    return;
end
end

% =======================================================================
function tf = hasCustomIdentifier(head)
txt = char(head);
lines = regexp(txt, '\r\n|\n|\r', 'split');
tf = false;
for ii = 1:numel(lines)
    s = strtrim(lines{ii});
    if isempty(s), continue; end
    tf = strncmpi(s, '#IDENTIFIER', 11);
    return;
end
end

% =======================================================================
function tf = hasSciRecords(head)
txt = char(head);
lines = regexp(txt, '\r\n|\n|\r', 'split');
tf = false;
nSeen = 0;
for ii = 1:numel(lines)
    s = lines{ii};
    if isempty(strtrim(s)), continue; end
    if numel(s) == 22 && s(22) == ' ', s = s(1:21); end
    if numel(s) ~= 21, return; end
    v = str2double({strtrim(s(1:7)), strtrim(s(8:14)), strtrim(s(15:21))});
    if any(~isfinite(v)), return; end
    nSeen = nSeen + 1;
    if nSeen >= 3, break; end
end
tf = nSeen >= 1;
end

% =======================================================================
function info = baseInfo(ext, format)
info = struct('format', format, 'byteOrder', '', 'extension', ext, ...
    'fileBytes', 0, 'details', struct());
end

% =======================================================================
function ok = isTextLike(head)
ok = false;
if isempty(head), return; end
% UTF-16 text carries NUL bytes by design; the BOM is the reliable marker
% and the text reader validates the rest.
if numel(head) >= 2 && (isequal(head(1:2), uint8([255 254])) || ...
        isequal(head(1:2), uint8([254 255])))
    ok = true;
    return;
end
% NUL bytes are the strongest binary marker; UTF-16 is handled by the text
% reader only when a BOM is present, so plain NULs mean "not text here".
if any(head == 0), return; end
ctrl = head < 9 | (head > 13 & head < 32) | head == 127;
if mean(ctrl) > 0.02, return; end
ok = true;
end

% =======================================================================
function S = sniffSac(head, fileBytes)
S = [];
if numel(head) < 632, return; end
orders = {'little', 'big'};
for ii = 1:numel(orders)
    order = orders{ii};
    delta = readF32(head, 0, order);
    npts  = readI32(head, 280 + 9*4, order);
    iftype = readI32(head, 280 + 13*4, order);
    if ~(isfinite(delta) && delta > 0 && delta < 1e3), continue; end
    if ~(isfinite(npts) && npts > 0 && npts < 1e8 && npts == round(npts))
        continue;
    end
    if iftype ~= 1, continue; end
    needed = 632 + npts * 4;
    S = struct('byteOrder', order, 'delta', delta, 'npts', npts, ...
        'iftype', iftype, 'dataOffset', 632, 'expectedBytes', needed, ...
        'truncated', fileBytes < needed);
    return;
end
end

% =======================================================================
function S = sniffSegy(head, fileBytes)
S = [];
if numel(head) < 3600 || fileBytes < 3840, return; end
bh = head(3201:3600);
sampleInterval = beU16(bh(17:18));
nSamples       = beI16(bh(21:22));
sampleFormat   = beI16(bh(25:26));
bps = bytesPerSample(sampleFormat);
if isempty(bps), return; end

firstTrace = 3600;
if numel(head) >= 3601 + 240
    traceNS = beI16(head(3601+114 : 3601+115));
else
    traceNS = 0;
end
if nSamples <= 0, nSamples = traceNS; end
if nSamples <= 0 || nSamples > 1e6, return; end
if sampleInterval < 0 || sampleInterval > 1e6, return; end
needed = firstTrace + 240 + nSamples * bps;

S = struct('sampleIntervalUs', sampleInterval, 'nSamples', nSamples, ...
    'sampleFormat', sampleFormat, 'bytesPerSample', bps, ...
    'firstTraceOffset', firstTrace, 'traceNSamples', traceNS, ...
    'expectedBytes', needed, 'truncated', fileBytes < needed);
end

% =======================================================================
function bps = bytesPerSample(code)
switch code
    case {1, 2, 5, 8}
        bps = 4;
    case 3
        bps = 2;
    otherwise
        bps = [];
end
end

% =======================================================================
function v = readF32(b, off, order)
bb = uint8(b(off+1 : off+4));
if strcmp(order, 'big'), bb = bb(end:-1:1); end
v = double(typecast(bb, 'single'));
end

function v = readI32(b, off, order)
bb = uint8(b(off+1 : off+4));
if strcmp(order, 'big'), bb = bb(end:-1:1); end
v = double(typecast(bb, 'int32'));
end

function v = beU16(bb)
v = double(bb(1))*256 + double(bb(2));
end

function v = beI16(bb)
v = beU16(bb);
if v >= 2^15, v = v - 2^16; end
end

function v = leU32(bb)
v = double(bb(1)) + double(bb(2))*256 + double(bb(3))*2^16 + ...
    double(bb(4))*2^24;
end
