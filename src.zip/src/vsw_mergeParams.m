function P = vsw_mergeParams(user)
%VSW_MERGEPARAMS  Overlay a (partial) user parameter struct on the defaults.
%
%   Recursive so that P.sweep.f1Hz = 10 alone is enough; unknown fields are
%   rejected so a typo cannot silently fall back to a default.

def = vsw_defaultParams();
P   = mergeStruct(def, user);

    function out = mergeStruct(d, u)
        if isempty(u)
            out = d;
            return;
        end
        if ~isstruct(u)
            out = u;
            return;
        end
        out = d;
        names = fieldnames(u);
        for ii = 1:numel(names)
            nm = names{ii};
            if ~isfield(d, nm)
                error('vsw:param:unknownField', ...
                    'Unknown parameter field "%s". Add it to vsw_defaultParams first.', nm);
            end
            if isstruct(d.(nm)) && isstruct(u.(nm))
                out.(nm) = mergeStruct(d.(nm), u.(nm));
            else
                out.(nm) = u.(nm);
            end
        end
    end
end
