function P = vsw_defaultParams()
%VSW_DEFAULTPARAMS  Default parameter struct (01 §2, field table frozen at v1.1).
%
%   Units are carried by field names.  The algorithm layer only sees SI
%   units after vsw_prepare has run; the degree-valued fields stay here for
%   the run snapshot.

% ---- P.sweep -----------------------------------------------------------
P.sweep.type            = 'linear';
P.sweep.f1Hz            = 6;
P.sweep.f2Hz            = 96;
P.sweep.lengthMs        = 16000;
P.sweep.dtMs            = 1;
P.sweep.initialPhaseDeg = 0;
P.sweep.sweepConstant   = 0;
P.sweep.direction       = 'up';
P.sweep.sequenceLength  = 1;
P.sweep.segmentFreqsHz  = [];   % piecewiseLinear only, sweep-time order
P.sweep.segmentLengthsMs = [];  % piecewiseLinear only
P.sweep.variCount       = 5;    % variSweep only
P.sweep.variBandJitterPct = 2;  % variSweep only

% ---- P.wavelet (target-spectrum / target-wavelet routes only) ----------
P.wavelet.waveletType      = 'dampedRicker';  % 'dampedRicker' | 'yu' | 'custom'
P.wavelet.mainFreqHz       = 35;
P.wavelet.dampingFactor    = 2.8;
P.wavelet.yuFreqLowerHz    = 20;
P.wavelet.yuFreqUpperHz    = 80;
P.wavelet.lobeAmpRatio     = 0.25;
P.wavelet.lobeWidthRatio   = 1.4;
P.wavelet.targetSpectrum   = [];
P.wavelet.targetFreqAxis   = [];

% ---- P.drive -----------------------------------------------------------
P.drive.amplitudeFraction = 0.7;
P.drive.driveCurve        = [];      % [fHz, D] two columns
P.drive.lowFreqBoost      = false;
P.drive.sourceModel       = '';      % char or struct, 02 §4.5
P.drive.sourceControlCurve = [];     % [fHz, 0..1] upper drive limit

% ---- P.taper -----------------------------------------------------------
P.taper.type    = 'cosine';
P.taper.startMs = 500;
P.taper.endMs   = 500;

% ---- P.code (pseudo-random / encoded extension) ------------------------
P.code.order     = 8;      % m-sequence order, 5..12
P.code.chipMs    = 4;      % chip duration
P.code.carrierHz = 60;     % constant carrier for BPSK
P.code.seed      = 1;      % initial LFSR state offset
P.code.gapMs     = 0;      % coded only: gap between the two Golay halves

% ---- P.distortion (M5, phenomenon level, default off) ------------------
P.distortion.enable     = false;
P.distortion.order2Amp  = 0.15;
P.distortion.order3Amp  = 0.08;
P.distortion.phase2Rad  = -0.5;
P.distortion.phase3Rad  = 0.5;
P.distortion.lowFreqHz  = 2;
P.distortion.decayHz    = 20;
P.distortion.pilotMode  = 'single';   % 'single' | 'perSource'

% ---- P.output (04 §8.1, the single authoritative field table) ----------
P.output.format                  = 'segy';
P.output.segyRevision            = 'rev2.1';
P.output.sampleFormat            = 'ibmFloat32';
P.output.textHeaderEncoding      = 'ascii';
P.output.byteOrder               = 'big';
P.output.traceIdCode             = 6;
P.output.sweepTraceNumber        = 1;
P.output.numTraces               = 1;
P.output.writeSweepParamsToBinary = true;
P.output.writeExtendedStanza     = false;
P.output.fileNamePattern         = '{type}_{f1}-{f2}Hz_{len}s_{dt}ms.sgy';
P.output.t0Ms                    = 0;

% ---- P.qc --------------------------------------------------------------
P.qc.specTolDB        = 1.5;
P.qc.mainLobeTolPct   = 2;
P.qc.sideLobeMarginDB = 1;
P.qc.edgeBandPct      = 5;
P.qc.failMode         = 'error';   % 'error' | 'warn'

% ---- P.meta (traceability, filled at run time) -------------------------
P.meta.project           = '';
P.meta.operator          = '';
P.meta.note              = '';
P.meta.createdAt         = datestr(now, 'yyyy-mm-dd HH:MM:SS');
P.meta.codeVersion       = vsw_constants().CODE_VERSION;
P.meta.nSamplesConvention = vsw_constants().N_SAMPLES_CONVENTION;
P.meta.phaseRef           = vsw_constants().PHASE_REF;
P.meta.integrationRule    = vsw_constants().INT_RULE;
P.meta.defaultDtMs        = vsw_constants().DEFAULT_DT_MS;
end
