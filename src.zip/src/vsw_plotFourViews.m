function h = vsw_plotFourViews(R, opts)
%VSW_PLOTFOURVIEWS  Four linked views from the single analysis result (05 §2).
%   Time / spectrum / autocorrelation / phase.  No FFT or metric is
%   recomputed here; every array is read from R.derived or R.analysis.

if nargin < 2, opts = struct(); end
if ~isfield(opts, 'spectrumScale'), opts.spectrumScale = 'db'; end
if ~isfield(opts, 'freqScale'),     opts.freqScale = 'linear'; end
if ~isfield(opts, 'showFreqOnTime'),opts.showFreqOnTime = false; end
if ~isfield(opts, 'acfWindowS'),    opts.acfWindowS = 0.5; end

D = R.D; A = R.analysis; P = R.P;
h = figure('Color', 'w', 'Position', [80 60 1280 860], 'Name', R.meta.signalId);
tl = tiledlayout(h, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, sprintf('%s   |   %s   |   QC %s', R.meta.signalId, ...
    R.G.pathLabel, ternary(R.qc.pass, 'PASS', 'FAIL')), 'Interpreter', 'none');

% ---- (1) time ---------------------------------------------------------
ax1 = nexttile;
plot(D.tAxisS, R.derived.signal, 'k', 'LineWidth', 0.8); hold on;
plot(D.tAxisS,  R.derived.envelope, 'b--', 'LineWidth', 1.0);
plot(D.tAxisS, -R.derived.envelope, 'b--', 'LineWidth', 1.0);
yl = ylim;
plot([1 1]*D.startTaperS, yl, ':', 'Color', [0.5 0.5 0.5]);
plot([1 1]*(D.T - D.endTaperS), yl, ':', 'Color', [0.5 0.5 0.5]);
grid on; xlabel('time (s)'); ylabel('amplitude');
if opts.showFreqOnTime
    yyaxis right;
    plot(D.tAxisS, R.derived.fOfTS, 'r', 'LineWidth', 1.2);
    ylabel('f(t) (Hz)'); ylim([0, D.fHi*1.15]);
    yyaxis left;
end
title('(1) time domain');

% ---- (2) spectrum -----------------------------------------------------
ax2 = nexttile;
f = A.freqAxisHz;
if strcmpi(opts.spectrumScale, 'db')
    plot(f, A.ampSpectrumDB, 'r', 'LineWidth', 1.0); hold on;
    if ~isempty(A.targetAmp)
        tn = A.targetAmp / max(A.targetAmp);
        plot(f, 20*log10(tn + eps), 'b--', 'LineWidth', 1.0);
    end
    ylabel('dB (peak = 0)'); ylim([-80 5]);
else
    plot(f, A.ampSpectrum, 'r', 'LineWidth', 1.0); hold on;
    if ~isempty(A.targetAmp)
        plot(f, A.targetAmp / max(A.targetAmp) * max(A.ampSpectrum), ...
            'b--', 'LineWidth', 1.0);
    end
    ylabel('|S(f)|');
end
xlim([0, min(D.fHi*1.3, D.fNyqHz)]);
if strcmpi(opts.freqScale, 'log')
    set(ax2, 'XScale', 'log'); xlim([max(D.fLo*0.8, 0.5), min(D.fHi*1.3, D.fNyqHz)]);
end
grid on; xlabel('frequency (Hz)'); title('(2) amplitude spectrum');
if ~isempty(A.targetAmp), legend({'signal', 'target'}, 'Location', 'best'); end

% ---- (3) autocorrelation ---------------------------------------------
ax3 = nexttile;
lag = A.acfLagS;
sel = abs(lag) <= opts.acfWindowS;
if strcmpi(opts.spectrumScale, 'db')
    plot(lag(sel), A.acfDB(sel), 'm', 'LineWidth', 1.1); hold on;
    ylim([-60 3]);
else
    plot(lag(sel), A.acfNormalized(sel), 'm', 'LineWidth', 1.1); hold on;
end
yl = ylim;
for k = 1:2
    if isfinite(A.zeroCrossLagS(k))
        plot([1 1]*A.zeroCrossLagS(k), yl, ':', 'Color', [0.4 0.4 0.4]);
    end
end
if isfinite(A.sideLobeLagS)
    [~, ks] = min(abs(lag - A.sideLobeLagS));
    plot(lag(ks), A.acfNormalized(ks), 'ko', 'MarkerSize', 4);
end
grid on; xlabel('lag (s)'); ylabel('normalized ACF');
title(sprintf('(3) autocorrelation   zc = %.4g s, side lobe = %.1f dB, main energy = %.1f%%', ...
    A.zeroCrossS, A.sideLobeDB, 100*A.mainLobeEnergyRatio));

% ---- (4) phase --------------------------------------------------------
ax4 = nexttile;
plot(D.tAxisS, R.derived.phaseRad, 'k', 'LineWidth', 1.0); hold on;
grid on; xlabel('time (s)'); ylabel('phase (rad)');
yyaxis right;
plot(D.tAxisS, A.phaseErrorRad, 'r', 'LineWidth', 0.9);
ylabel('phase error (rad)');
ylim([-max(A.phaseTolRad*2, 1e-12), max(A.phaseTolRad*2, 1e-12)]);
yyaxis left;
title(sprintf('(4) unwrapped phase   max error %.2g rad (tol %.2g)', ...
    max(abs(A.phaseErrorRad)), A.phaseTolRad));

if isfield(opts, 'exportBase') && ~isempty(opts.exportBase)
    exportgraphics(h, [opts.exportBase '.png'], 'Resolution', 170);
    exportgraphics(h, [opts.exportBase '.pdf'], 'ContentType', 'vector');
end
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end
