function G = vsw_gen_analogSpectrum(P, D)
%VSW_GEN_ANALOGSPECTRUM  Alias of targetSpectrum (03 §2.1).
%   The analog spectrum route and the sampled target-spectrum route share one
%   implementation; the alias exists so the type enum of 03 stays complete.

G = vsw_gen_targetSpectrum(P, D);
G.pathLabel = 'analogSpectrum';
G.aliasOf   = 'targetSpectrum';
end
