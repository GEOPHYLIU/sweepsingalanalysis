function G = vsw_gen_linear(~, D)
%VSW_GEN_LINEAR  Linear up/down sweep, f(t) = f1 + (f2-f1) t/T.
%   f1Hz/f2Hz are start/stop; direction is applied by vsw_analyticGrid.

flo = D.fLo; fhi = D.fHi;
G.kind       = 'analytic';
G.fUp        = @(u) flo + (fhi - flo) * u;
G.FAup       = @(u) flo * u + 0.5 * (fhi - flo) * u.^2;
G.pathLabel  = 'analytic';
G.sweepCode  = 1;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G = vsw_analyticGrid(D, G);
end
