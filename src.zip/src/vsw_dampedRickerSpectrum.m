function [A, w] = vsw_dampedRickerSpectrum(fHz, f0Hz, B)
%VSW_DAMPEDRICKERSPECTRUM  Analytic amplitude spectrum of the damped Ricker.
%
%   R(t) = (1 - 2*(pi*f0*t)^2) * exp(-B*(pi*f0*t)^2)
%   |R~(f)| = exp(-w^2/(4*B*a)) * ((B-1) + w^2/(2*B*a)),  a = pi^2*f0^2
%
%   Derived directly from the Fourier transform of R(t); B = 1 reduces to
%   the standard Ricker spectrum (zero at f = 0).  The expression is the
%   target *correlation-wavelet* spectrum A(f) of 00 §4.1.

fHz = fHz(:);
a   = pi^2 * f0Hz^2;
w   = 2*pi*fHz;
A   = exp(-w.^2 ./ (4*B*a)) .* ((B - 1) + w.^2 ./ (2*B*a));
A(~isfinite(A)) = 0;
end
