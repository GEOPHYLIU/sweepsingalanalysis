function map = vsw_registry()
%VSW_REGISTRY  Type -> generation entry (01 §2.1, 03 §2.1).
%
%   Adding a type costs exactly one line here plus one generator returning
%   fUp/FAup (analytic), a target spectrum (spectrum), or a raw waveform.
%   The assembly and analysis layers never inspect the type name.

persistent M
if ~isempty(M), map = M; return; end

map = containers.Map('KeyType', 'char', 'ValueType', 'any');
map('linear')         = @vsw_gen_linear;
map('dbPerOct')       = @vsw_gen_dbPerOct;
map('dbPerHz')        = @vsw_gen_dbPerHz;
map('tPower')         = @vsw_gen_tPower;
map('expNeg')         = @vsw_gen_expNeg;
map('logSweep')       = @vsw_gen_logSweep;
map('dampedRicker')   = @vsw_gen_dampedRicker;
map('targetSpectrum') = @vsw_gen_targetSpectrum;
map('analogSpectrum') = @vsw_gen_analogSpectrum;
map('customWavelet')  = @vsw_gen_customWavelet;
map('piecewiseLinear') = @vsw_gen_piecewiseLinear;
map('pseudoRandom')   = @vsw_gen_pseudoRandom;
map('coded')          = @vsw_gen_coded;
map('variSweep')      = @vsw_gen_variSweep;

M = map;
end
