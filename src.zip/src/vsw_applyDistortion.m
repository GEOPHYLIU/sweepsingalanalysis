function X = vsw_applyDistortion(P, D, S)
%VSW_APPLYDISTORTION  Phenomenon-level harmonic model (03 §6 decision 2, M5).
%
%   s_d(t) = s(t) + sum_k a_k * exp(-(f-lowFreq)/decay) * sin(k*phi + psi_k)
%
%   Four knobs only: harmonic order, amplitude, phase lag, low-frequency
%   partition.  No servo-valve physics, no claim about whether order 2 is
%   enhanced or suppressed (03 §6 decision 10): the order-2 amplitude is an
%   independent parameter.
%
%   B11 convention (see README): the theoretical ghost position is obtained
%   by synthesising the ideal k-th harmonic from the *pilot's own frequency
%   law* (trapezoidal phase integration of S.fOfTS), then correlating it with
%   the pilot.  The measured position is obtained the same way from the
%   harmonic component actually added by this module.  A closed-form
%   single-point stationary-phase formula is ill-posed here because the
%   ghost of a broadband, tapered sweep is a broad correlation plateau, not a
%   sharp spike; the reconstructed-harmonic comparison still catches any
%   order/direction/phase error in the distortion layer while giving a
%   well-defined, sample-accurate position.

f   = S.fOfTS(:);
phi = S.phaseRad(:);
env = S.envelope(:);

w2 = P.distortion.order2Amp * exp(-max(f - P.distortion.lowFreqHz, 0)/P.distortion.decayHz);
w3 = P.distortion.order3Amp * exp(-max(f - P.distortion.lowFreqHz, 0)/P.distortion.decayHz);

dist = S.signal(:) ...
     + env .* w2 .* sin(2*phi + P.distortion.phase2Rad) ...
     + env .* w3 .* sin(3*phi + P.distortion.phase3Rad);

h2 = env .* w2 .* sin(2*phi + P.distortion.phase2Rad);
h3 = env .* w3 .* sin(3*phi + P.distortion.phase3Rad);

pilot = S.signal(:);       % per-source pilots are tracked by the caller's id

X.pilotSignal     = pilot;
X.distortedSignal = dist;
[X.corrLagS, X.corrProfile] = localXCorr(dist, pilot, D.dtS);

% ---- theoretical harmonic reconstructed from the pilot frequency law -----
% Independent phase integration of S.fOfTS (the actual pilot's sweep law).
% For analytic types S.phaseRad is a closed-form integral of the same law, so
% the two agree to the C1 phase precision; for spectrum types the assembly
% already uses this trapezoidal rule, so they agree exactly.
phiT = trapezoidPhase(f, D.dtS) + D.phi0Rad;
h2T  = env .* w2 .* sin(2*phiT + P.distortion.phase2Rad);
h3T  = env .* w3 .* sin(3*phiT + P.distortion.phase3Rad);
[~, c2T] = localXCorr(h2T, pilot, D.dtS);
[~, c3T] = localXCorr(h3T, pilot, D.dtS);

% ---- measured harmonic components actually added by this module ----------
[~, c2] = localXCorr(h2, pilot, D.dtS);
[~, c3] = localXCorr(h3, pilot, D.dtS);

X.ghostTheoryTime = [ ...
    peakLag(X.corrLagS, c2T), ...
    peakLag(X.corrLagS, c3T)];
X.ghostMeasuredTime = [ ...
    peakLag(X.corrLagS, c2), ...
    peakLag(X.corrLagS, c3)];

% ---- low-frequency harmonic ratio (record only, B12) ------------------
A = abs(fft(dist));
N = numel(dist);
Nf = floor(N/2)+1;
fr = (0:Nf-1).'/ (N*D.dtS);
amp = A(1:Nf);
E = @(lo,hi) sum(amp(fr >= lo & fr <= hi).^2);
X.lowFreqHarmonicDB = [ ...
    10*log10(max(E(4,16), eps)/max(E(2,8), eps)), ...
    10*log10(max(E(6,24), eps)/max(E(2,8), eps))];
end

function phi = trapezoidPhase(f, dt)
phi = zeros(size(f));
if numel(f) > 1
    phi(2:end) = cumsum(pi * dt * (f(1:end-1) + f(2:end)));
end
end

function t = peakLag(lag, c)
% Global correlation peak.  The harmonic-only correlations have no zero-lag
% main lobe, so the dominant peak is the ghost.
[~, k] = max(abs(c));
t = lag(k);
end

function [lag, c] = localXCorr(x, y, dt)
% Linear cross-correlation c(k) = sum_n x(n) y(n-k), lag k in samples.
N = numel(x);
M = 2^nextpow2(2*N);
X = fft(x, M); Y = fft(y, M);
r = real(ifft(X .* conj(Y)));
c = [r(M-N+1:M); r(2:N)];
lag = (-(N-1):(N-1)).' * dt;
end
