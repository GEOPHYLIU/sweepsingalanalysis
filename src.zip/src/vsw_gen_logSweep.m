function G = vsw_gen_logSweep(P, D)
%VSW_GEN_LOGSWEEP  Logarithmic sweep (extension type, 00 §2).
%   f(t) = f1 + (f2-f1) * log(1+k u)/log(1+k),  k = SweepConstant.
%   k -> 0 degenerates to linear.

k = P.sweep.sweepConstant;
if abs(k) < 1e-9, k = 1e-9; end
flo = D.fLo; fhi = D.fHi; d = fhi - flo; lk = log1p(k);
G.kind      = 'analytic';
G.fUp       = @(u) flo + d * log1p(k*u) / lk;
G.FAup      = @(u) flo*u + d/lk * ((1 + k*u).*log1p(k*u)/k - u);
G.pathLabel = 'analytic';
G.sweepCode = 3;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G = vsw_analyticGrid(D, G);
end
