function G = vsw_gen_dbPerOct(P, D)
%VSW_GEN_DBPEROCT  Constant dB/oct compensation sweep (00 §2, 曹务祥 eq.7).
%   SweepConstant carries the dB/oct value n.

n = P.sweep.sweepConstant;
if n == 0, n = 1e-9; end
flo = D.fLo; fhi = D.fHi;
G.kind      = 'analytic';
G.fUp       = @(u) vsw_dbOctLaw(u, flo, fhi, n);
G.FAup      = @(u) faOnly(u, flo, fhi, n);
G.pathLabel = 'analytic';
G.sweepCode = 3;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G = vsw_analyticGrid(D, G);
end

function FA = faOnly(u, flo, fhi, n)
[~, FA] = vsw_dbOctLaw(u, flo, fhi, n);
end
