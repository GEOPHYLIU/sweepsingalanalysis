function E = vsw_importSignal(file, opts)
%VSW_IMPORTSIGNAL  Load an external signal for display and comparison.
%
%   E = vsw_importSignal(file)
%   E = vsw_importSignal(file, opts)
%
%   Validation follows the external-input chain:
%     1 accessibility  path, file, read permission, non-zero size
%     2 real format    magic number / structure, not the extension
%     3 encoding       BOM or strict UTF-8/GBK; binary byte order declared
%     4 structure      header counts vs actual payload, truncation
%     5 semantics      time axis monotone, finite samples, dt > 0
%     6 read-back      declared sample count vs decoded sample count
%
%   Supported real formats:
%     WAV  (RIFF/WAVE)                audio via audioread (channel selectable)
%     MAT  (v5/v6/v7.3)               numeric vector variable, optional fs/dt
%     SEG-Y (3200/3600 header)        one trace via vsw_readSegy
%     SAC  (632-byte header)          one time-series trace
%     XLSX/XLS                        numeric sheet via readmatrix
%     numeric text                    CSV/TXT/TSV, optional time column
%     raw binary                      only with explicit sampleFormat/byteOrder
%
%   opts (all optional):
%     dtMs         fallback sample interval in ms              (default 1)
%     timeColumn   'auto' | 'yes' | 'no'                       (default 'auto')
%     timeUnit     'auto' | 's' | 'ms'                         (default 'auto')
%     channel      1-based channel / column                    (default 1)
%     trace        1-based SEG-Y trace                         (default 1)
%     detrend      'none' | 'mean' | 'linear'                  (default 'mean')
%     normalize    logical, peak-normalise to 1                (default false)
%     varName      MAT variable name, '' = auto                (default '')
%     excelSheet   sheet name/index for XLSX/XLS, '' = first   (default '')
%     sampleFormat raw binary: int16/int32/float32/float64/ibmFloat32
%     byteOrder    raw binary: 'little' | 'big' | 'auto'       (default 'auto')
%     offsetBytes  raw binary header bytes to skip             (default 0)
%     samplesPerTrace raw binary samples per channel           (default 0)
%
%   Result E:
%     file, kind, name, x, tS, dtS, fsHz, N, durationS,
%     peak, rms, crest, dcOffset, timeFromFile, warnings,
%     detectedFormat, extension, extensionMatches, encoding, byteOrder,
%     fileBytes, validation

if nargin < 2, opts = struct(); end
opts = fillOpts(opts);

% ---- 1. accessibility --------------------------------------------------
[~, base, ext] = fileparts(file);
ext = lower(ext);
if exist(file, 'dir')
    error('vsw:import:isDir', 'Path is a directory, not a file: %s', file);
end
d = dir(file);
if isempty(d)
    error('vsw:import:missing', 'File not found: %s', file);
end
if d.bytes <= 0
    error('vsw:import:emptyFile', 'File is empty: %s', file);
end
fid = fopen(file, 'rb');
if fid < 0
    error('vsw:import:permission', 'File is not readable: %s', file);
end
fclose(fid);
opts.fileBytes = d.bytes;

% ---- 2. real format ----------------------------------------------------
info = vsw_sniffFormat(file, ext);
warnings = {};
expectedGroup = extensionGroup(ext);
rawIntent = strcmp(expectedGroup, 'raw') || ...
    (~isempty(opts.sampleFormat) && strcmp(ext, '.dat'));
if strcmp(info.format, 'unknown') || ...
        (rawIntent && strcmp(info.format, 'text') && ~isempty(opts.sampleFormat))
    % Raw binary has no header to sniff.  It is accepted only when the
    % caller supplies a sample format and either uses a raw extension or
    % says so explicitly for a .dat file.
    if rawIntent && (~isempty(opts.sampleFormat) || strcmp(info.format, 'unknown'))
        info.format = 'raw';
    else
        error('vsw:import:format', ...
            ['Cannot identify the real format of "%s" (%d bytes). ' ...
             'Supported: WAV, MAT, SEG-Y, SAC, XLSX/XLS, numeric text, ' ...
             'raw binary (with sampleFormat).'], file, d.bytes);
    end
end
extensionMatches = isempty(expectedGroup) || ...
    strcmp(expectedGroup, formatGroup(info.format));
if ~extensionMatches
    warnings{end+1} = sprintf( ...
        'Extension "%s" does not match the detected %s content; the real format was used.', ...
        ext, info.format);
end

timeFromFile = false;
encoding = '';
byteOrder = info.byteOrder;
readBackOk = true;
dtFromFormat = false;
phaseConvention = '';

switch info.format
    % ---- numeric text ------------------------------------------------
    case 'text'
        [M, meta, warnings] = vsw_readTextSignal(file, warnings);
        encoding = meta.encoding;
        [x, t, dt, timeFromFile, warnings] = ...
            columnsToSignal(M, opts, warnings);
        kind = 'text';

    % ---- Excel -------------------------------------------------------
    case {'xlsx', 'xls'}
        try
            if isempty(opts.excelSheet)
                M = readmatrix(file);
            else
                M = readmatrix(file, 'Sheet', opts.excelSheet);
            end
        catch ME
            error('vsw:import:excelRead', ...
                'Cannot read the workbook "%s": %s', file, ME.message);
        end
        nRaw = size(M, 1);
        M = M(any(isfinite(M), 2), :);
        if nRaw > size(M, 1)
            warnings{end+1} = sprintf( ...
                '%d all-empty spreadsheet row(s) skipped.', ...
                nRaw - size(M, 1));
        end
        [x, t, dt, timeFromFile, warnings] = ...
            columnsToSignal(M, opts, warnings);
        kind = 'excel';

    % ---- WAV ---------------------------------------------------------
    case 'wav'
        if d.bytes < 44
            error('vsw:import:wavShort', 'File too short to be WAV: %s', file);
        end
        ai = audioinfo(file);
        if ai.SampleRate <= 0 || ai.TotalSamples <= 0
            error('vsw:import:wavHeader', ...
                'WAV header reports an invalid rate or sample count: %s', file);
        end
        [raw, fs] = audioread(file);
        if abs(fs - ai.SampleRate) > 0
            warnings{end+1} = sprintf( ...
                'WAV header says %g Hz but audioread returned %g Hz.', ...
                ai.SampleRate, fs);
        end
        if size(raw, 1) ~= ai.TotalSamples
            readBackOk = false;
            warnings{end+1} = sprintf( ...
                'WAV header declares %d frames but %d were decoded.', ...
                ai.TotalSamples, size(raw, 1));
        end
        if size(raw, 2) > 1
            ch = round(opts.channel);
            if ch < 1 || ch > size(raw, 2)
                ch = min(max(1, ch), size(raw, 2));
                warnings{end+1} = sprintf( ...
                    'Requested channel %d, WAV has %d; using channel %d.', ...
                    opts.channel, size(raw, 2), ch);
            end
            raw = raw(:, ch);
        end
        x = raw(:);
        dt = 1 / fs;
        t = (0:numel(x)-1).' * dt;
        kind = 'wav';

    % ---- MAT ---------------------------------------------------------
    case {'mat', 'mat73'}
        try
            S = load(file);
        catch ME
            error('vsw:import:matRead', ...
                'Cannot load MAT file "%s": %s', file, ME.message);
        end
        [x, t, dt, ~, warnings] = readMatSignal(S, opts, warnings);
        if isempty(t)
            t = (0:numel(x)-1).' * dt;
        else
            timeFromFile = true;
        end
        kind = 'mat';

    % ---- SEG-Y -------------------------------------------------------
    case 'segy'
        if d.bytes < 3840
            error('vsw:import:segyShort', 'File too short to be SEG-Y: %s', file);
        end
        S = vsw_readSegy(file, opts.trace);
        x = S.samples(:);
        if isfield(S, 'traceDtUs') && S.traceDtUs > 0
            dt = S.traceDtUs * 1e-6;
        elseif isfield(S, 'sampleIntervalUs') && S.sampleIntervalUs > 0
            dt = S.sampleIntervalUs * 1e-6;
        else
            dt = opts.dtMs * 1e-3;
            warnings{end+1} = 'SEG-Y sample interval missing; used fallback dt.';
        end
        t = (0:numel(x)-1).' * dt;
        kind = 'segy';
        if isfield(S, 'traceNSamples') && S.traceNSamples > 0 && ...
                S.traceNSamples ~= numel(x)
            readBackOk = false;
            warnings{end+1} = sprintf( ...
                'Trace header says %d samples, binary header says %d.', ...
                S.traceNSamples, numel(x));
        end
        if isfield(S, 'nTraces') && opts.trace > S.nTraces
            readBackOk = false;
            warnings{end+1} = sprintf( ...
                'Requested trace %d but only %d trace(s) were found.', ...
                opts.trace, S.nTraces);
        end

    % ---- SAC ---------------------------------------------------------
    case 'sac'
        S = vsw_readSac(file);
        if opts.trace > 1
            error('vsw:import:sacTrace', ...
                'SAC files contain a single trace; trace=%d is not available.', ...
                opts.trace);
        end
        x = S.data(:);
        dt = S.delta;
        t = (0:numel(x)-1).' * dt;
        byteOrder = S.byteOrder;
        kind = 'sac';
        if S.extraBytes > 0
            warnings{end+1} = sprintf( ...
                '%d trailing byte(s) after the declared SAC samples were ignored.', ...
                S.extraBytes);
        end
        if isfinite(S.b) && abs(S.b) > 0
            warnings{end+1} = sprintf( ...
                'SAC begin time b = %g s was dropped; the axis starts at 0.', S.b);
        end

    % ---- box-controller sweep formats --------------------------------
    case 'custom'
        [x, dt, B, warnings] = vsw_readBoxSweep(file, 'custom', opts, warnings);
        t = (0:numel(x)-1).' * dt;
        encoding = B.encoding;
        byteOrder = 'ascii';
        dtFromFormat = true;
        kind = 'custom';

    case 'sci'
        subtype = info.details.subtype;
        [x, dt, B, warnings] = vsw_readBoxSweep(file, subtype, opts, warnings);
        t = (0:numel(x)-1).' * dt;
        encoding = B.encoding;
        byteOrder = 'ascii';
        dtFromFormat = true;
        phaseConvention = B.phaseConvention;
        kind = subtype;

    % ---- raw binary --------------------------------------------------
    case 'raw'
        [x, dt, R, warnings] = vsw_readRawSignal(file, opts, warnings);
        t = (0:numel(x)-1).' * dt;
        byteOrder = R.byteOrder;
        kind = 'raw';

    otherwise
        error('vsw:import:format', ...
            'Format "%s" is recognised but not supported by this importer.', ...
            info.format);
end

% ---- 5. semantics ------------------------------------------------------
if isempty(x) || ~isvector(x)
    error('vsw:import:empty', 'No signal samples found in %s.', file);
end
x = x(:);
t = t(:);
if numel(t) ~= numel(x)
    t = (0:numel(x)-1).' * median(diff(t));
end
if any(~isfinite(x))
    error('vsw:import:nonFinite', ...
        'Decoded signal contains NaN/Inf samples; check the file structure.');
end
if ~(isfinite(dt) && dt > 0)
    error('vsw:import:badDt', 'Inferred sample interval is not positive: %g', dt);
end

% ---- make the time axis uniform ---------------------------------------
if timeFromFile
    dtv = diff(t);
    dt = median(dtv);
    if any(dtv <= 0) || std(dtv) > 0.02 * max(dt, eps)
        warnings{end+1} = 'Time axis was not uniform; resampled to the median dt.';
        tu = (t(1):dt:t(end)).';
        x = interp1(t, x, tu, 'linear', 0);
        t = tu;
    end
    t = t - t(1);
else
    t = (0:numel(x)-1).' * dt;
end
if any(~isfinite(x))
    error('vsw:import:resample', ...
        'Resampling produced non-finite samples; check the time axis.');
end

% ---- conditioning ------------------------------------------------------
switch lower(opts.detrend)
    case 'mean'
        x = x - mean(x);
    case 'linear'
        if numel(x) >= 3
            x = x - polyval(polyfit(t, x, 1), t);
        else
            x = x - mean(x);
        end
    otherwise
        % keep DC
end
if opts.normalize
    pk = max(abs(x));
    if pk > 0, x = x / pk; end
end

N = numel(x);
pk = max(abs(x));
rmsv = sqrt(mean(x.^2));
E = struct();
E.file         = file;
E.kind         = kind;
E.name         = base;
E.x            = x;
E.tS           = t;
E.dtS          = dt;
E.fsHz         = 1 / dt;
E.N            = N;
E.durationS    = N * dt;
E.peak         = pk;
E.rms          = rmsv;
E.crest        = pk / max(rmsv, eps);
E.dcOffset     = mean(x);
E.timeFromFile = timeFromFile;
E.channel      = opts.channel;
E.trace        = opts.trace;
E.warnings     = warnings;
E.detectedFormat   = info.format;
E.extension        = ext;
E.extensionMatches = extensionMatches;
E.encoding         = encoding;
E.byteOrder        = byteOrder;
E.fileBytes        = d.bytes;
E.dtFromFormat     = dtFromFormat;
E.phaseConvention  = phaseConvention;
E.validation       = struct( ...
    'access', true, 'format', info.format, ...
    'extensionMatch', extensionMatches, 'encoding', encoding, ...
    'byteOrder', byteOrder, 'readBack', readBackOk, ...
    'dtFromFormat', dtFromFormat);
end

% =======================================================================
function opts = fillOpts(opts)
if ~isstruct(opts)
    error('vsw:import:opts', 'opts must be a struct.');
end
def = struct('dtMs', 1, 'timeColumn', 'auto', 'timeUnit', 'auto', ...
             'channel', 1, 'trace', 1, 'detrend', 'mean', ...
             'normalize', false, 'varName', '', 'excelSheet', '', ...
             'sampleFormat', '', 'byteOrder', 'auto', 'offsetBytes', 0, ...
             'samplesPerTrace', 0, 'phaseConvention', '', 'fileBytes', 0);
names = fieldnames(def);
for ii = 1:numel(names)
    if ~isfield(opts, names{ii}) || isempty(opts.(names{ii}))
        opts.(names{ii}) = def.(names{ii});
    end
end

if ~(isscalar(opts.dtMs) && isfinite(opts.dtMs) && opts.dtMs > 0)
    error('vsw:import:optDt', 'opts.dtMs must be a positive finite scalar.');
end
if ~any(strcmpi(opts.timeColumn, {'auto', 'yes', 'no'}))
    error('vsw:import:optTimeColumn', ...
        'opts.timeColumn must be auto, yes or no.');
end
if ~any(strcmpi(opts.timeUnit, {'auto', 's', 'ms'}))
    error('vsw:import:optTimeUnit', 'opts.timeUnit must be auto, s or ms.');
end
if ~(isscalar(opts.channel) && isfinite(opts.channel) && ...
        opts.channel >= 1 && opts.channel == round(opts.channel))
    error('vsw:import:optChannel', ...
        'opts.channel must be a positive integer.');
end
if ~(isscalar(opts.trace) && isfinite(opts.trace) && ...
        opts.trace >= 1 && opts.trace == round(opts.trace))
    error('vsw:import:optTrace', 'opts.trace must be a positive integer.');
end
if ~any(strcmpi(opts.detrend, {'none', 'mean', 'linear'}))
    error('vsw:import:optDetrend', ...
        'opts.detrend must be none, mean or linear.');
end
if ~(isscalar(opts.offsetBytes) && isfinite(opts.offsetBytes) && ...
        opts.offsetBytes >= 0)
    error('vsw:import:optOffset', ...
        'opts.offsetBytes must be a non-negative scalar.');
end
if ~(isscalar(opts.samplesPerTrace) && isfinite(opts.samplesPerTrace) && ...
        opts.samplesPerTrace >= 0)
    error('vsw:import:optSpt', ...
        'opts.samplesPerTrace must be a non-negative scalar.');
end
if ~isempty(opts.phaseConvention) && ...
        ~any(strcmpi(opts.phaseConvention, {'sin', 'cos'}))
    error('vsw:import:optPhase', ...
        'opts.phaseConvention must be sin or cos (or empty for the SCIO default).');
end
opts.dtMs = double(opts.dtMs);
opts.channel = round(opts.channel);
opts.trace = round(opts.trace);
opts.offsetBytes = round(opts.offsetBytes);
opts.samplesPerTrace = round(opts.samplesPerTrace);
opts.normalize = logical(opts.normalize);
end

% =======================================================================
function grp = extensionGroup(ext)
switch ext
    case {'.csv', '.txt', '.tsv', '.asc', '.prn'}
        grp = 'text';
    case '.dat'
        grp = '';            % text or raw: sniff determines it
    case '.wav'
        grp = 'wav';
    case '.mat'
        grp = 'mat';
    case {'.sgy', '.segy'}
        grp = 'segy';
    case '.sac'
        grp = 'sac';
    case {'.xlsx', '.xls', '.xlsm'}
        grp = 'excel';
    case '.custom'
        grp = 'custom';
    case {'.vsci', '.fsci'}
        grp = 'sci';
    case {'.bin', '.raw', '.int', '.flt'}
        grp = 'raw';
    otherwise
        grp = '';
end
end

% =======================================================================
function grp = formatGroup(format)
switch format
    case {'xlsx', 'xls'}
        grp = 'excel';
    case 'mat73'
        grp = 'mat';
    otherwise
        grp = format;
end
end

% =======================================================================
function [x, t, dt, timeFromFile, warnings] = columnsToSignal(M, opts, warnings)
M = double(M);
if isempty(M)
    error('vsw:import:noNumeric', 'No numeric data rows in the file.');
end
if size(M, 2) < 1
    error('vsw:import:noColumn', 'No data columns in the file.');
end
n0 = size(M, 1);
M = M(all(isfinite(M), 2), :);
if isempty(M)
    error('vsw:import:noNumeric', 'No finite numeric rows in the file.');
end
if size(M, 1) < n0
    warnings{end+1} = sprintf( ...
        '%d row(s) with missing/non-finite values were skipped.', ...
        n0 - size(M, 1));
end

tf = false;
switch lower(opts.timeColumn)
    case 'yes', tf = true;
    case 'no',  tf = false;
    otherwise
        if size(M, 2) >= 2
            tf = looksLikeTime(M(:, 1), opts.timeUnit);
        end
end
if tf && size(M, 2) < 2
    warnings{end+1} = ...
        'timeColumn=yes but the file has a single column; used fallback dt.';
    tf = false;
end

if tf
    t = M(:, 1);
    switch lower(opts.timeUnit)
        case 'ms'
            t = t * 1e-3;
        case 'auto'
            if max(abs(t)) > 1e4, t = t * 1e-3; end
        otherwise
            % seconds
    end
    ch = min(max(1, round(opts.channel)), size(M, 2) - 1) + 1;
    if ch ~= opts.channel + 1
        warnings{end+1} = sprintf( ...
            'Requested column %d, file has %d data column(s); using column %d.', ...
            opts.channel, size(M, 2) - 1, ch - 1);
    end
    x = M(:, ch);
    dt = median(diff(t));
    timeFromFile = true;
else
    ch = min(max(1, round(opts.channel)), size(M, 2));
    if ch ~= opts.channel
        warnings{end+1} = sprintf( ...
            'Requested column %d, file has %d column(s); using column %d.', ...
            opts.channel, size(M, 2), ch);
    end
    x = M(:, ch);
    dt = opts.dtMs * 1e-3;
    t = (0:numel(x)-1).' * dt;
    timeFromFile = false;
end
if ~isfinite(dt) || dt <= 0
    dt = opts.dtMs * 1e-3;
    t = (0:numel(x)-1).' * dt;
    timeFromFile = false;
    warnings{end+1} = 'Could not infer dt from the file; used fallback dt.';
end
end

% =======================================================================
function tf = looksLikeTime(t, timeUnit)
tf = false;
if numel(t) < 3, return; end
d = diff(t);
if any(d <= 0), return; end
md = median(d);
span = t(end) - t(1);
if ~(isfinite(md) && md > 0 && span > 0 && span < 1e9), return; end
% Reject a constant or near-constant column.
if span < 1e-9 * max(abs(t(end)), 1), return; end
% A genuine time axis spans about (N-1) median steps; a monotonic signal
% column usually does not.
ratio = span / md;
if ratio < 0.5*(numel(t)-1) || ratio > 2*(numel(t)-1), return; end
switch lower(timeUnit)
    case 'ms'
        tf = md >= 1e-6 && md < 1e4;
    case 's'
        tf = md > 0 && md < 1e2;
    otherwise
        tf = md > 0 && md < 1e4;
end
end

% =======================================================================
function [x, t, dt, name, warnings] = readMatSignal(S, opts, warnings)
if nargin < 3, warnings = {}; end
name = '';
v = [];
if ~isempty(opts.varName)
    if isfield(S, opts.varName)
        v = S.(opts.varName);
        name = opts.varName;
    else
        error('vsw:import:matVar', 'Variable "%s" not found in MAT file.', opts.varName);
    end
else
    pref = {'x', 'signal', 'data', 'sweep', 'trace', 'waveform'};
    for ii = 1:numel(pref)
        if isfield(S, pref{ii}) && isnumeric(S.(pref{ii}))
            v = S.(pref{ii}); name = pref{ii}; break;
        end
    end
    if isempty(v)
        fn = fieldnames(S);
        best = -1;
        for ii = 1:numel(fn)
            c = S.(fn{ii});
            if isnumeric(c) && isvector(c) && numel(c) > best
                v = c; name = fn{ii}; best = numel(c);
            end
        end
    end
end
if isempty(v)
    error('vsw:import:matNoSignal', 'No numeric vector variable found in MAT file.');
end
if ~isreal(v)
    warnings{end+1} = 'MAT signal is complex; the real part was used.';
    v = real(v);
end
if ~isvector(v)
    ch = min(max(1, round(opts.channel)), size(v, 2));
    if ch ~= opts.channel
        warnings{end+1} = sprintf( ...
            'Requested channel %d, MAT variable has %d column(s); using column %d.', ...
            opts.channel, size(v, 2), ch);
    end
    v = v(:, ch);
end
x = v(:);

% optional explicit time axis alongside the samples
t = [];
tNames = {'tS', 't', 'timeS', 'time', 'tAxisS', 'tm', 'tMs', 'timeMs', 'time_ms'};
for ii = 1:numel(tNames)
    if isfield(S, tNames{ii}) && isnumeric(S.(tNames{ii})) && ...
            isvector(S.(tNames{ii})) && numel(S.(tNames{ii})) == numel(x)
        t = S.(tNames{ii})(:);
        if any(strcmpi(tNames{ii}, {'tm', 'tms', 'timems', 'time_ms'})) || ...
                max(abs(t)) > 1e4
            t = t * 1e-3;
        end
        break;
    end
end

% dt from common rate fields
dt = NaN;
rateNames = {'fs', 'Fs', 'sampleRate', 'samplerate'};
for ii = 1:numel(rateNames)
    if isfield(S, rateNames{ii}) && isscalar(S.(rateNames{ii})) && ...
            S.(rateNames{ii}) > 0
        dt = 1 / S.(rateNames{ii});
        break;
    end
end
if isnan(dt)
    dtNames = {'dtS', 'dt', 'dtMs'};
    for ii = 1:numel(dtNames)
        if isfield(S, dtNames{ii}) && isscalar(S.(dtNames{ii})) && ...
                S.(dtNames{ii}) > 0
            dt = S.(dtNames{ii});
            if strcmpi(dtNames{ii}, 'dtMs'), dt = dt * 1e-3; end
            break;
        end
    end
end
if isnan(dt)
    if ~isempty(t)
        dt = median(diff(t));
    else
        dt = opts.dtMs * 1e-3;
    end
end
end
