function G = vsw_gen_pseudoRandom(P, D)
%VSW_GEN_PSEUDORANDOM  BPSK m-sequence modulated constant carrier.
%   Equal-amplitude carrier with polarity switched by a maximal-length
%   sequence (00 §2).  f(t) is the constant carrier; the type is not
%   monotonic, so B5/B6 are marked not applicable instead of being faked.

order = max(5, min(12, round(P.code.order)));
seq   = mSequence(order, P.code.seed);
chipN = max(1, round(P.code.chipMs / P.sweep.dtMs));
need  = ceil(D.N / chipN);
rep   = ceil(need / numel(seq));
bits  = repmat(seq, rep, 1);
chips = reshape(repmat(bits(:).', chipN, 1), [], 1);
chips = 2*double(chips(1:D.N)) - 1;     % 0/1 -> -1/+1

fc   = min(max(P.code.carrierHz, D.fLo), D.fHi);
phi  = 2*pi*fc*D.tAxisS + D.phi0Rad;

G.kind       = 'raw';
G.pathLabel  = 'coded';
G.sweepCode  = 4;
G.signalRaw  = chips .* sin(phi);
G.phaseRad   = phi - D.phi0Rad;
G.fOfTS      = fc * ones(D.N, 1);
G.fAtT       = fc;
G.fAt0       = fc;
G.fOfT       = @(tt) fc * ones(size(tt));
G.monotonicApplicable = false;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G.codeOrder  = order;
G.carrierHz  = fc;
end

function s = mSequence(order, seed)
% Maximal-length LFSR; primitive feedback taps per order (classic table).
taps = struct('o', {5,6,7,8,9,10,11,12}, ...
              't', {[5 3],[6 5],[7 6],[8 6 5 4],[9 5],[10 7],[11 9],[12 6 4 1]});
k = find([taps.o] == order, 1);
tt = taps(k).t;
reg = ones(1, order);
if seed > 1
    b = dec2bin(seed, order) == '1';
    reg = double(b);
    if all(reg == 0), reg(1) = 1; end
end
len = 2^order - 1;
s = zeros(1, len);
for ii = 1:len
    s(ii) = reg(end);
    fb = mod(sum(reg(tt)), 2);
    reg = [fb reg(1:end-1)];
end
end
