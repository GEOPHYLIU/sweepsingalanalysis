function [w, details] = vsw_taperProfile(P, D)
%VSW_TAPERPROFILE  Start/end taper in [0,1] (00 §5, 01 §2.4).
%   'cosine' is implemented as cos^2, matching SEG-Y rev2.1 taper code 2.

N  = D.N;
ns = min(N, round(P.taper.startMs / P.sweep.dtMs));
ne = min(N, round(P.taper.endMs   / P.sweep.dtMs));
w  = ones(N, 1);

if ns > 0
    u = (0:ns-1).' / ns;
    w(1:ns) = shape(P.taper.type, u);
end
if ne > 0
    u = (0:ne-1).' / ne;
    w(N-ne+1:N) = flipud(shape(P.taper.type, u));
end
w = min(max(w, 0), 1);

details.startSamples    = ns;
details.endSamples      = ne;
details.startS          = ns * D.dtS;
details.endS            = ne * D.dtS;
details.taperTypeCode   = taperCode(P.taper.type);
end

function s = shape(type, u)
switch lower(type)
    case 'none',     s = ones(size(u));
    case 'linear',   s = u;
    case 'sine',     s = sin(0.5*pi*u);
    case 'cosine',   s = sin(0.5*pi*u).^2;          % cos^2 taper
    case 'gauss38',  s = exp(-0.5*(3.8*(1 - u)).^2);
    case 'gauss20',  s = exp(-0.5*(2.0*(1 - u)).^2);
    case 'blackman', s = 0.42 - 0.5*cos(pi*u) + 0.08*cos(2*pi*u);
    otherwise
        error('vsw:taper:type', 'Unknown taper type "%s".', type);
end
s = min(max(s, 0), 1);
end

function code = taperCode(type)
switch lower(type)
    case 'none',     code = 0;
    case 'linear',   code = 1;
    case 'cosine',   code = 2;   % cosine squared per rev2.1
    otherwise,       code = 3;   % other
end
end
