function [B, achieved] = vsw_solveDampingForLobe(ratio)
%VSW_SOLVEDAMPINGFORLOBE  Damping B >= 1 giving a requested first side-lobe ratio.
%
%   Side-lobe ratio of the damped Ricker depends only on B.  The map is
%   monotone decreasing; bisection on B in [1, 40] is deterministic and
%   needs no toolbox.  A target above the Ricker value (~0.446) is clipped
%   at B = 1 and reported honestly.

lo = 1; hi = 40;
achieved = @(b) sideLobeRatio(b);

if ratio >= achieved(lo)
    B = lo;
    achieved = achieved(B);
    return;
end
if ratio <= achieved(hi)
    B = hi;
    achieved = achieved(B);
    return;
end

for it = 1:80
    mid = 0.5*(lo + hi);
    if achieved(mid) > ratio
        lo = mid;
    else
        hi = mid;
    end
end
B = 0.5*(lo + hi);
achieved = achieved(B);
end

function r = sideLobeRatio(B)
% Evaluate on a normalized grid (f0 = 1) and take the first extremum after
% the first zero crossing.
t  = linspace(0, 4, 40001).';
w  = (1 - 2*(pi*t).^2) .* exp(-B*(pi*t).^2);
tz = sqrt(2)/(2*pi);
idx = find(t > tz);
seg = w(idx);
[pk, ~] = max(abs(seg));
r = pk;
end
