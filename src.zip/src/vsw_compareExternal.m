function C = vsw_compareExternal(E, R, opts)
%VSW_COMPAREEXTERNAL  Compare an imported signal with a generated sweep.
%
%   C = vsw_compareExternal(E, R, opts)
%
%   E     result of vsw_importSignal
%   R     result of vsw_generate (uses R.derived.signal / R.D.dtS), or a
%         numeric reference vector when opts.refDtS is supplied.
%
%   Both signals are interpolated onto the coarser of the two sample
%   intervals, mean-removed and normalised, then cross-correlated.  The
%   reported lag is the shift of the external signal relative to the
%   reference; positive means the external event is later.

if nargin < 3, opts = struct(); end

if isstruct(R) && isfield(R, 'D')
    ref  = R.derived.signal(:);
    dtR  = R.D.dtS;
else
    ref  = R(:);
    if ~isfield(opts, 'refDtS')
        error('vsw:compare:dt', 'opts.refDtS is required for a numeric reference.');
    end
    dtR = opts.refDtS;
end

x  = E.x(:);
tE = (0:numel(x)-1).' * E.dtS;
tR = (0:numel(ref)-1).' * dtR;
dt = max(E.dtS, dtR);
T  = min(tE(end), tR(end));
t  = (0:dt:T).';
xq = interp1(tE, x,   t, 'linear', 0);
yq = interp1(tR, ref, t, 'linear', 0);

xq = xq - mean(xq);
yq = yq - mean(yq);
nx = sqrt(sum(xq.^2));
ny = sqrt(sum(yq.^2));

[lag, c] = localXCorrNorm(xq, yq, dt, nx, ny);
[peak, k] = max(abs(c));

C = struct();
C.lagS          = lag;
C.corr          = c;
C.peakLagS      = lag(k);
C.peakCorr      = peak;
C.rmsExternal   = sqrt(mean(E.x.^2));
C.rmsReference  = sqrt(mean(ref.^2));
C.gainDB        = 20*log10(max(C.rmsExternal, eps) / max(C.rmsReference, eps));
C.dtS           = dt;
C.N             = numel(t);
C.summary       = sprintf('peak |rho| = %.4f at lag %.4g s, gain %.2f dB', ...
    peak, lag(k), C.gainDB);
end

% =======================================================================
function [lag, c] = localXCorrNorm(x, y, dt, nx, ny)
N = numel(x);
M = 2^nextpow2(2*N);
X = fft(x, M);
Y = fft(y, M);
r = real(ifft(X .* conj(Y)));
c = [r(M-N+2:M); r(1:N)];
lag = (-(N-1):(N-1)).' * dt;
c = c / max(nx*ny, eps);
end
