function h = vsw_plotExternal(E, A)
%VSW_PLOTEXTERNAL  Standalone four-view figure for an imported signal.

h = figure('Color', 'w', 'Position', [90 70 1260 820], ...
    'Name', ['external: ' E.name], 'NumberTitle', 'off');
tl = tiledlayout(h, 2, 2, 'TileSpacing', 'compact', 'Padding', 'compact');
axs = [nexttile, nexttile, nexttile, nexttile];
vsw_drawExternal(axs, E, A);
title(tl, sprintf('%s   |   N = %d, dt = %.4g ms, T = %.4g s', ...
    E.name, E.N, E.dtS*1e3, E.durationS), 'Interpreter', 'none');
end
