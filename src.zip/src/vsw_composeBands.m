function C = vsw_composeBands(P, bandEdgesHz, opts)
%VSW_COMPOSEBANDS  Multi-band superposition (03 §2.2 "叠合").
%   Each band is designed on its own sub-band with the same total length,
%   then the normalized sub-signals are summed.  The result is normalized
%   to the original amplitudeFraction.

if nargin < 3, opts = struct(); end
if ~isfield(opts, 'normalizeEach'), opts.normalizeEach = true; end
if numel(bandEdgesHz) < 2
    error('vsw:compose:bands', 'bandEdgesHz needs at least two edges.');
end

sig = [];
for k = 1:numel(bandEdgesHz)-1
    Q = P;
    Q.sweep.f1Hz = bandEdgesHz(k);
    Q.sweep.f2Hz = bandEdgesHz(k+1);
    Q.sweep.direction = 'up';
    R = vsw_generate(Q, struct('figure', false, 'saveDir', ''));
    s = R.derived.signal;
    if opts.normalizeEach
        s = s / max(max(abs(s)), eps);
    end
    sig(:, k) = s; %#ok<AGROW>
    if k == 1
        t = R.derived.tAxisS;
    end
end
C.bandSignals = sig;
C.signal = sum(sig, 2);
pk = max(abs(C.signal));
if pk > 0
    C.signal = C.signal / pk * P.drive.amplitudeFraction;
end
C.tAxisS = t;
C.bandEdgesHz = bandEdgesHz;
end
