function G = vsw_gen_dbPerHz(P, D)
%VSW_GEN_DBPERHZ  dB/Hz compensation sweep (00 §2, 曹务祥 eq.8).
%   f(t) = [f1^n + (t/T)(f2^n - f1^n)]^(1/n), n = SweepConstant.

n   = P.sweep.sweepConstant;
flo = D.fLo; fhi = D.fHi;

if abs(n) < 1e-9
    % n -> 0 limit: geometric (log-linear) interpolation.
    lf = log(flo); lh = log(fhi); dl = lh - lf;
    G.fUp  = @(u) exp(lf + u * dl);
    G.FAup = @(u) exp(lf) * expm1(u * dl) / dl;
else
    c  = fhi^n - flo^n;
    G.fUp  = @(u) (flo^n + u * c).^(1/n);
    G.FAup = @(u) faOnly(u, flo, fhi, n, c);
end
G.kind      = 'analytic';
G.pathLabel = 'analytic';
G.sweepCode = 3;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G = vsw_analyticGrid(D, G);
end

function FA = faOnly(u, flo, fhi, n, c)
if abs(1 + 1/n) < 1e-12
    FA = log((flo^n + u*c) / flo^n) / c;
else
    p  = 1 + 1/n;
    FA = ((flo^n + u*c).^p - (flo^n)^p) / (c * p);
end
end
