function b = vsw_ibmEncode(x)
%VSW_IBMENCODE  IEEE double -> IBM System/360 float32 bytes (big-endian).
%   value = (-1)^s * 0.fraction * 16^(exponent-64), fraction in [1/16, 1).
%   Zero is all-zero bytes and never goes through the formula (04 §8.1a).

x = double(x(:));
N = numel(x);
b = zeros(N, 4, 'uint8');
nz = x ~= 0;
if ~any(nz), return; end

y = abs(x(nz));
e = 64 * ones(size(y));
sgn = x(nz) < 0;

% Normalise: 1/16 <= y < 1.
while true
    small = y < 1/16;
    big   = y >= 1;
    if ~any(small) && ~any(big), break; end
    if any(small)
        y(small) = y(small) * 16;
        e(small) = e(small) - 1;
    end
    if any(big)
        y(big) = y(big) / 16;
        e(big) = e(big) + 1;
    end
end

mant = round(y * 2^24);
roll = mant >= 2^24;
if any(roll)
    mant(roll) = mant(roll) / 16;
    e(roll)    = e(roll) + 1;
end

under = e < 0;
if any(under)
    mant(under) = 0;
    e(under)    = 0;
end
over = e > 127;
if any(over)
    e(over)    = 127;
    mant(over) = 2^24 - 1;
end

b1 = uint8(min(max(e + 128*double(sgn), 0), 255));
b2 = uint8(floor(mant / 2^16));
b3 = uint8(mod(floor(mant / 2^8), 256));
b4 = uint8(mod(mant, 256));

b(nz, 1) = b1;
b(nz, 2) = b2;
b(nz, 3) = b3;
b(nz, 4) = b4;
end
