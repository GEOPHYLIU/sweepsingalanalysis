function csvFile = vsw_writeCsv(R, fileName)
%VSW_WRITECSV  Human-readable two-column CSV export (non-standard, 04 §8.2).
%   Header row makes the file readable and is skipped by readmatrix, so the
%   result can be fed back into vsw_importSignal.

if nargin < 2
    fileName = fullfile(pwd, [R.meta.signalId '.csv']);
end
fid = fopen(fileName, 'w');
if fid < 0, error('vsw:csv:open', 'Cannot open "%s".', fileName); end
cleaner = onCleanup(@() fclose(fid));
fprintf(fid, 'time_s,amplitude\n');
fprintf(fid, '%.9f,%.12g\n', [R.derived.tAxisS(:), R.derived.signal(:)].');
clear cleaner;
csvFile = fileName;
end
