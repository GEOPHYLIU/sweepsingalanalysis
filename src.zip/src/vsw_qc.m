function Q = vsw_qc(P, D, S, A)
%VSW_QC  Post-generation checks B1-B12 and precision item 03-C1.

items = struct('id', {}, 'name', {}, 'applicable', {}, 'pass', {}, ...
               'value', {}, 'threshold', {}, 'unit', {}, 'detail', {});

% ---- B1 spectrum vs target -------------------------------------------
if ~isempty(A.targetAmp) && any(strcmpi(P.sweep.type, ...
        {'targetSpectrum', 'analogSpectrum', 'dampedRicker', 'customWavelet'}))
    edge = P.qc.edgeBandPct/100 * (D.fHi - D.fLo);
    band = A.freqAxisHz >= D.fLo + edge & A.freqAxisHz <= D.fHi - edge;
    W  = A.ampSpectrumNoTaper.^2;   % compare the designed spectrum, not the
    Tt = A.targetAmp;               % taper roll-off (B10 records that loss)
    ok = band & Tt > 1e-6*max(Tt);
    if nnz(ok) > 5
        Wn = W / max(W(ok));
        Tn = Tt / max(Tt(ok));
        errDB = 20*log10((Wn(ok) + eps) ./ (Tn(ok) + eps));
        p90 = sortedPercentile(abs(errDB), 0.90);
        pass = p90 <= P.qc.specTolDB;
        items(end+1) = mk('B1', 'spectrum vs target', true, pass, ...
            p90, P.qc.specTolDB, 'dB', sprintf('90th pct |err|, %d bins', nnz(ok)));
    else
        items(end+1) = mk('B1', 'spectrum vs target', false, NaN, NaN, ...
            P.qc.specTolDB, 'dB', 'not enough bins in the comparison band');
    end
else
    items(end+1) = mk('B1', 'spectrum vs target', false, NaN, NaN, ...
        P.qc.specTolDB, 'dB', 'not a target-spectrum type');
end

% ---- B2 main-lobe zero-crossing spacing ------------------------------
if isscalar(A.theoryZeroCrossS) && isfinite(A.theoryZeroCrossS) && isfinite(A.zeroCrossS)
    rel = abs(A.zeroCrossS - A.theoryZeroCrossS) / A.theoryZeroCrossS * 100;
    items(end+1) = mk('B2', 'main-lobe zero-crossing spacing', true, ...
        rel <= P.qc.mainLobeTolPct, rel, P.qc.mainLobeTolPct, '%', ...
        sprintf('measured %.6g s, theory %.6g s', A.zeroCrossS, A.theoryZeroCrossS));
else
    items(end+1) = mk('B2', 'main-lobe zero-crossing spacing', false, NaN, ...
        NaN, P.qc.mainLobeTolPct, '%', 'no analytic theory for this type');
end

% ---- B3 side lobe -----------------------------------------------------
if isfinite(A.sideLobeDB) && isscalar(A.targetSideLobeDB) && isfinite(A.targetSideLobeDB)
    lim = A.targetSideLobeDB + P.qc.sideLobeMarginDB;
    items(end+1) = mk('B3', 'first side-lobe level', true, ...
        A.sideLobeDB <= lim, A.sideLobeDB, lim, 'dB', ...
        sprintf('target %.2f dB + margin %.2f dB', A.targetSideLobeDB, P.qc.sideLobeMarginDB));
elseif isfinite(A.sideLobeDB)
    items(end+1) = mk('B3', 'first side-lobe level', true, true, ...
        A.sideLobeDB, NaN, 'dB', 'recorded (no target side-lobe for this type)');
else
    items(end+1) = mk('B3', 'first side-lobe level', false, NaN, NaN, NaN, 'dB', 'not measurable');
end

% ---- B4 main-lobe energy ratio --------------------------------------
% Multi-pulse / random sequences have several designed correlation lobes,
% so "main-lobe energy / total energy" is not a meaningful design target.
multiPulse = any(strcmpi(P.sweep.type, ...
    {'pseudoRandom', 'coded', 'variSweep'}));
if multiPulse
    items(end+1) = mk('B4', 'main-lobe energy ratio', false, ...
        A.mainLobeEnergyRatio, A.mainLobeEnergyRatio, 0.70, '-', ...
        'not applicable (multi-pulse / random correlation)');
elseif isfinite(A.mainLobeEnergyRatio)
    items(end+1) = mk('B4', 'main-lobe energy ratio', true, ...
        A.mainLobeEnergyRatio >= 0.70, A.mainLobeEnergyRatio, 0.70, '-', ...
        'envelope main lobe; first-release floor 70%%, to be calibrated');
else
    items(end+1) = mk('B4', 'main-lobe energy ratio', false, NaN, NaN, 0.70, '-', 'not measurable');
end

% ---- B5 monotonicity -------------------------------------------------
if S.monotonicApplicable
    df = diff(S.fOfTS);
    if strcmpi(D.direction, 'up')
        pass = all(df >= -1e-6) && all(isfinite(S.fOfTS));
    else
        pass = all(df <= 1e-6) && all(isfinite(S.fOfTS));
    end
    items(end+1) = mk('B5', 'instantaneous-frequency monotonicity', true, ...
        pass, min(df), 0, 'Hz/sample', sprintf('direction = %s', D.direction));
else
    items(end+1) = mk('B5', 'instantaneous-frequency monotonicity', false, NaN, ...
        NaN, 0, 'Hz/sample', 'not applicable (non-monotonic coded type)');
end

% ---- B6 endpoint alignment -------------------------------------------
if S.monotonicApplicable
    if strcmpi(D.direction, 'up')
        e0 = abs(S.fOfTS(1) - D.fLo) / D.fLo;
        eT = abs(S.fAtT   - D.fHi) / D.fHi;
    else
        e0 = abs(S.fOfTS(1) - D.fHi) / D.fHi;
        eT = abs(S.fAtT   - D.fLo) / D.fLo;
    end
    e = max(e0, eT);
    items(end+1) = mk('B6', 'frequency endpoint alignment', true, ...
        e <= 1e-3, e*100, 0.1, '%', ...
        sprintf('f(0)=%.4f Hz, f(T)=%.4f Hz', S.fOfTS(1), S.fAtT));
else
    items(end+1) = mk('B6', 'frequency endpoint alignment', false, NaN, ...
        NaN, 0.1, '%', 'not applicable (non-monotonic coded type)');
end

% ---- B7 phase continuity ---------------------------------------------
dphi = diff(S.phaseRad);
pass7 = all(isfinite(S.phaseRad)) && all(dphi >= -1e-9) && max(abs(dphi)) <= pi;
items(end+1) = mk('B7', 'phase continuity', true, pass7, max(abs(dphi)), pi, 'rad/sample', ...
    'no unwrap jump, non-negative phase increment');

% ---- B8 end jumps -----------------------------------------------------
pk = max(abs(S.signal));
if pk > 0 && (P.taper.startMs > 0 || P.taper.endMs > 0)
    e8 = max(abs(S.signal(1)), abs(S.signal(end))) / pk;
    items(end+1) = mk('B8', 'end-point jump', true, e8 <= 0.01, e8*100, 1, '%', ...
        'with taper enabled');
else
    items(end+1) = mk('B8', 'end-point jump', false, NaN, NaN, 1, '%', 'no taper or zero signal');
end

% ---- B9 peak vs drive constraint -------------------------------------
pkEnv = max(abs(S.envelope));
items(end+1) = mk('B9', 'peak vs drive constraint', true, ...
    pkEnv <= P.drive.amplitudeFraction + 1e-12, pkEnv, ...
    P.drive.amplitudeFraction, '-', 'max|envelope| <= amplitudeFraction');

% ---- B10 taper energy loss (record only) -----------------------------
items(end+1) = mk('B10', 'taper edge-band energy loss', true, NaN, ...
    A.edgeEnergyRatioDB, NaN, 'dB', 'record value (tapered vs untapered)');

% ---- B11 ghost position (distortion module) --------------------------
if isfield(A, 'ghostTheoryTime') && ~isempty(A.ghostTheoryTime)
    errs = abs(A.ghostMeasuredTime - A.ghostTheoryTime);
    pass11 = all(errs <= D.dtS + 1e-12);
    items(end+1) = mk('B11', 'harmonic ghost position', true, pass11, ...
        max(errs)/D.dtS, 1, 'samples', ...
        sprintf('2nd/3rd harmonic ghost errors: %.3g / %.3g samples', ...
        errs(1)/D.dtS, errs(2)/D.dtS));
    if isfield(A, 'lowFreqHarmonicDB')
        items(end+1) = mk('B12', 'low-frequency harmonic ratio', true, NaN, ...
            max(A.lowFreqHarmonicDB), NaN, 'dB', ...
            sprintf('2nd %.2f dB, 3rd %.2f dB (2-8 Hz, record only)', ...
            A.lowFreqHarmonicDB(1), A.lowFreqHarmonicDB(2)));
    end
end

% ---- 03-C1 phase precision -------------------------------------------
eC = max(abs(A.phaseErrorRad));
items(end+1) = mk('C1', 'phase precision (03-C1 / 01-C1a)', true, ...
    eC <= A.phaseTolRad, eC, A.phaseTolRad, 'rad', ...
    sprintf('%s route', A.pathLabel));

% ---- aggregate --------------------------------------------------------
Q.items = items;
Q.values = struct();
for ii = 1:numel(items)
    Q.values.(items(ii).id) = items(ii).value;
end
hard = [items.applicable] & ([items.pass] == 0);
design = {items.id};
designFail = hard & ismember(design, {'B1','B2','B3','B4'});
genFail    = hard & ~ismember(design, {'B1','B2','B3','B4'});
Q.pass = ~any(hard);
Q.designPass = ~any(designFail);
Q.generationPass = ~any(genFail);
Q.failed = {items(hard).id};
end

% =======================================================================
function s = mk(id, name, applicable, pass, value, threshold, unit, detail)
s = struct('id', id, 'name', name, 'applicable', applicable, ...
           'pass', pass, 'value', value, 'threshold', threshold, ...
           'unit', unit, 'detail', detail);
end

function v = sortedPercentile(x, p)
x = sort(x(:));
if isempty(x), v = NaN; return; end
k = max(1, min(numel(x), ceil(p*numel(x))));
v = x(k);
end
