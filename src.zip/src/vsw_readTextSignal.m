function [M, meta, warnings] = vsw_readTextSignal(file, warnings, opts)
%VSW_READTEXTSIGNAL  Strict numeric-text reader for external signals.
%
%   [M, meta] = vsw_readTextSignal(file, warnings)
%   [M, meta] = vsw_readTextSignal(file, warnings, opts)
%
%   opts.dropLogicalTail (default false): drop a trailing TRUE/FALSE column.
%   Real Sercel .custom files carry a second logical column after the
%   amplitude; the flag is metadata and is not part of the waveform.
%
%   Validation order: byte size -> encoding (BOM or strict UTF-8/GBK) ->
%   line structure (finite, equal-length numeric rows) -> numeric matrix M.
%   Header lines that contain no numeric token are skipped; a ragged data
%   row is an error rather than a silent truncation.
%
%   meta.encoding : 'UTF-8' | 'UTF-8-BOM' | 'UTF-16LE' | 'UTF-16BE' | 'GBK'
%   meta.delimiter: ',' | ';' | '\t' | 'whitespace'
%   meta.rows     : number of parsed data rows
%   meta.skipped  : number of skipped header/comment/blank lines

if nargin < 2, warnings = {}; end
if nargin < 3, opts = struct(); end
dropLogicalTail = isfield(opts, 'dropLogicalTail') && opts.dropLogicalTail;
nLogical = 0;

d = dir(file);
if isempty(d) || d.bytes <= 0
    error('vsw:import:emptyFile', 'File is empty: %s', file);
end
if d.bytes > 256 * 1024 * 1024
    error('vsw:import:tooLarge', ...
        'Text signal is larger than 256 MB; convert it to a binary format first.');
end

fid = fopen(file, 'rb');
if fid < 0
    error('vsw:import:open', 'Cannot open "%s" for reading.', file);
end
raw = fread(fid, Inf, 'uint8=>uint8');
fclose(fid);
raw = raw(:).';

[str, encoding] = decodeBytes(raw, file);
if strcmp(encoding, 'GBK')
    warnings{end+1} = ...
        'Text is not valid UTF-8; decoded as GBK (the encoding is reported, not silently replaced).';
end

lines = regexp(str, '\r\n|\n|\r', 'split');
rows = cell(numel(lines), 1);
nRows = 0;
nSkipped = 0;
nCol = 0;
expected = 0;
delim = '';
dataStarted = false;

for ii = 1:numel(lines)
    s = strtrim(lines{ii});
    if isempty(s)
        nSkipped = nSkipped + 1;
        continue;
    end
    if s(1) == '#' || s(1) == '%' || ...
            (numel(s) >= 2 && s(1) == '/' && s(2) == '/')
        nSkipped = nSkipped + 1;
        continue;
    end

    tok = regexp(s, '[^\s,;]+', 'match');
    if isempty(tok)
        nSkipped = nSkipped + 1;
        continue;
    end
    if isempty(delim) && ~dataStarted
        delim = detectDelimiter(s);
    end

    if dropLogicalTail && numel(tok) > 1 && isLogicalToken(tok{end})
        tok(end) = [];
        nLogical = nLogical + 1;
    end

    vals = parseTokens(tok);
    bad = isnan(vals) & ~isNaToken(tok);
    if any(bad)
        if ~dataStarted
            % A textual header such as "time,amplitude" is skipped.
            nSkipped = nSkipped + 1;
            continue;
        end
        error('vsw:import:textToken', ...
            'Line %d of "%s" contains a non-numeric token ("%s").', ...
            ii, file, tok{find(bad, 1)});
    end

    nRows = nRows + 1;
    rows{nRows} = vals;
    if nCol == 0
        nCol = numel(vals);
        expected = numel(vals);
    elseif numel(vals) ~= expected
        error('vsw:import:textColumns', ...
            'Line %d of "%s" has %d columns; earlier rows have %d.', ...
            ii, file, numel(vals), expected);
    end
    dataStarted = true;
end

if nRows == 0 || nCol == 0
    error('vsw:import:noNumeric', 'No numeric rows in %s.', file);
end

M = zeros(nRows, nCol);
for ii = 1:nRows
    M(ii, :) = rows{ii};
end

meta = struct('encoding', encoding, 'delimiter', delim, ...
    'rows', nRows, 'columns', nCol, 'skipped', nSkipped, ...
    'logicalFlags', nLogical);
if nSkipped > 0
    warnings{end+1} = sprintf( ...
        '%d non-numeric/blank line(s) skipped while reading text.', nSkipped);
end
end

% =======================================================================
function [str, encoding] = decodeBytes(raw, file)
bom8  = uint8([239 187 191]);
bomLE = uint8([255 254]);
bomBE = uint8([254 255]);

if numel(raw) >= 3 && isequal(raw(1:3), bom8)
    body = raw(4:end);
    if ~isValidUtf8(body)
        error('vsw:import:badUtf8', ...
            'File "%s" declares UTF-8 but contains invalid byte sequences.', file);
    end
    str = native2unicode(body, 'UTF-8');
    encoding = 'UTF-8-BOM';
elseif numel(raw) >= 2 && isequal(raw(1:2), bomLE)
    str = decodeUtf16(raw(3:end), 'little', file);
    encoding = 'UTF-16LE';
elseif numel(raw) >= 2 && isequal(raw(1:2), bomBE)
    str = decodeUtf16(raw(3:end), 'big', file);
    encoding = 'UTF-16BE';
elseif isValidUtf8(raw)
    str = native2unicode(raw, 'UTF-8');
    encoding = 'UTF-8';
elseif isValidGbk(raw)
    try
        str = native2unicode(raw, 'GBK');
    catch ME
        error('vsw:import:encoding', ...
            'File "%s" is neither valid UTF-8 nor decodable GBK (%s).', ...
            file, ME.message);
    end
    encoding = 'GBK';
else
    error('vsw:import:encoding', ...
        ['File "%s" is not valid UTF-8 or GBK text; ' ...
         'refusing to guess the code page.'], file);
end
end

% =======================================================================
function str = decodeUtf16(bytes, order, file)
if mod(numel(bytes), 2) ~= 0
    error('vsw:import:utf16', ...
        'UTF-16 file "%s" has an odd number of bytes.', file);
end
u = typecast(uint8(bytes), 'uint16');
if strcmp(order, 'big'), u = swapbytes(u); end
str = char(u);
end

% =======================================================================
function ok = isValidUtf8(b)
ok = true;
i = 1;
n = numel(b);
while i <= n
    c = b(i);
    if c < 128
        i = i + 1;
        continue;
    end
    if c >= 194 && c <= 223
        k = 1;
    elseif c >= 224 && c <= 239
        k = 2;
    elseif c >= 240 && c <= 244
        k = 3;
    else
        ok = false;
        return;
    end
    if i + k > n
        ok = false;
        return;
    end
    for j = 1:k
        if b(i+j) < 128 || b(i+j) > 191
            ok = false;
            return;
        end
    end
    i = i + k + 1;
end
end

% =======================================================================
function ok = isValidGbk(b)
ok = true;
i = 1;
n = numel(b);
while i <= n
    c = b(i);
    if c < 128
        i = i + 1;
        continue;
    end
    if c < 129 || c > 254 || i == n
        ok = false;
        return;
    end
    t = b(i+1);
    if ~((t >= 64 && t <= 126) || (t >= 128 && t <= 254))
        ok = false;
        return;
    end
    i = i + 2;
end
end

% =======================================================================
function d = detectDelimiter(s)
if any(s == ',')
    d = ',';
elseif any(s == ';')
    d = ';';
elseif any(s == sprintf('\t'))
    d = '\t';
else
    d = 'whitespace';
end
end

% =======================================================================
function vals = parseTokens(tok)
vals = zeros(1, numel(tok));
for ii = 1:numel(tok)
    t = tok{ii};
    if strcmpi(t, 'na') || strcmpi(t, 'n/a') || strcmp(t, '-')
        vals(ii) = NaN;
    else
        vals(ii) = str2double(t);
    end
end
end

function tf = isNaToken(tok)
tf = false(size(tok));
for ii = 1:numel(tok)
    tf(ii) = strcmpi(tok{ii}, 'nan') || strcmpi(tok{ii}, 'na') || ...
        strcmpi(tok{ii}, 'n/a') || strcmp(tok{ii}, '-');
end
end

function tf = isLogicalToken(t)
tf = strcmpi(t, 'true') || strcmpi(t, 'false');
end
