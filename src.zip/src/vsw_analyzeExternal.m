function A = vsw_analyzeExternal(E, opts)
%VSW_ANALYZEEXTERNAL  One-pass display analysis for an imported signal.
%
%   A = vsw_analyzeExternal(E, opts)
%
%   Computes everything the external views need once: one-sided amplitude
%   spectrum, analytic phase and instantaneous frequency, ACF, a short-time
%   spectrogram and scalar descriptors.  Nothing here is recomputed by the
%   plotting layer.

if nargin < 2, opts = struct(); end
if ~isfield(opts, 'spectrogram'), opts.spectrogram = true; end

x  = E.x(:);
N  = numel(x);
dt = E.dtS;
T  = N * dt;

% ---- amplitude spectrum ----------------------------------------------
Nf = floor(N/2) + 1;
freq = (0:Nf-1).' / T;
amp = oneSidedAmp(x, Nf);
ampDB = 20*log10(amp / max(max(amp), eps) + eps);

A.freqAxisHz  = freq;
A.ampSpectrum = amp;
A.ampSpectrumDB = ampDB;

% ---- analytic phase and instantaneous frequency ----------------------
z = analyticSignal(x);
A.phaseRad = unwrap(angle(z));
A.fInstHz  = gradient(A.phaseRad, dt) / (2*pi);

% ---- autocorrelation -------------------------------------------------
[A.acfLagS, acf] = localACF(x, dt);
A.acfNormalized = acf / max(abs(acf(N)), eps);
A.acfDB = 20*log10(abs(A.acfNormalized) + eps);
[~, kp] = max(abs(A.acfNormalized(N+1:end)));
A.acfPeakLagS = A.acfLagS(N + kp);

% ---- scalar descriptors ----------------------------------------------
if numel(amp) > 1
    [~, kd] = max(amp(2:end));
    A.dominantFreqHz = freq(kd + 1);
else
    A.dominantFreqHz = freq(1);
end
A.spectralCentroidHz = sum(freq .* amp) / max(sum(amp), eps);

mask = ampDB >= -20;             % -20 dB occupied band
mask(1) = false;
if any(mask)
    ff = freq(mask);
    A.bandLowHz  = ff(1);
    A.bandHighHz = ff(end);
else
    A.bandLowHz = NaN; A.bandHighHz = NaN;
end

if N > 1
    A.zeroCrossRateHz = sum(x(1:end-1) .* x(2:end) < 0) / (2*T);
else
    A.zeroCrossRateHz = NaN;
end

% ---- spectrogram -----------------------------------------------------
if opts.spectrogram && N >= 16
    A.spec = localSpectrogram(x, dt);
else
    A.spec = [];
end

A.pathLabel = 'external signal';
end

% =======================================================================
function amp = oneSidedAmp(s, Nf)
N = numel(s);
X = fft(s(:));
amp = abs(X(1:Nf)) / N;
if mod(N, 2) == 0
    amp(2:end-1) = 2 * amp(2:end-1);
else
    amp(2:end) = 2 * amp(2:end);
end
end

function z = analyticSignal(x)
N = numel(x);
X = fft(x(:));
h = zeros(N, 1);
if mod(N, 2) == 0
    h(1) = 1; h(N/2 + 1) = 1; h(2:N/2) = 2;
else
    h(1) = 1; h(2:(N+1)/2) = 2;
end
z = ifft(X .* h);
end

function [lag, acf] = localACF(x, dt)
N = numel(x);
M = 2^nextpow2(2*N);
X = fft(x(:), M);
r = real(ifft(abs(X).^2));
acf = [r(M-N+2:M); r(1:N)];
lag = (-(N-1):(N-1)).' * dt;
end

function sp = localSpectrogram(x, dt)
N = numel(x);
nwin = 2^floor(log2(max(16, min(512, floor(N/4)))));
nwin = min(nwin, N);
nfft = 2^nextpow2(nwin);
hop  = max(1, round(nwin/2));
nFrames = floor((N - nwin)/hop) + 1;
nFrames = max(nFrames, 1);
maxFrames = 1500;
if nFrames > maxFrames
    hop = max(1, ceil((N - nwin) / (maxFrames - 1)));
    nFrames = floor((N - nwin)/hop) + 1;
end
w = 0.5 - 0.5*cos(2*pi*(0:nwin-1).'/max(nwin-1, 1));
S = zeros(nfft/2 + 1, nFrames);
for k = 1:nFrames
    idx = (k-1)*hop + (1:nwin);
    idx = idx(idx <= N);
    seg = zeros(nwin, 1);
    seg(1:numel(idx)) = x(idx);
    X = abs(fft(seg .* w, nfft));
    S(:, k) = X(1:nfft/2 + 1) / max(sum(w), eps);
end
sp.t = ((0:nFrames-1)*hop + nwin/2).' * dt;
sp.f = (0:nfft/2).' / (nfft*dt);
sp.db = 20*log10(S / max(S(:)) + eps);
end
