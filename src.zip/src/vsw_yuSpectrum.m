function A = vsw_yuSpectrum(fHz, pHz, qHz)
%VSW_YUSPECTRUM  Amplitude spectrum of the Yu wavelet (00 §4.2).
%
%   The Yu wavelet averages standard Ricker wavelets whose dominant
%   frequency sweeps [p, q]:
%       Y(t) = 1/(q-p) * integral_p^q (1 - 2*(pi*f*t)^2)
%                              * exp(-(pi*f*t)^2) df
%   In the frequency domain the same average applies to the standard Ricker
%   amplitude spectrum |R~(f; f0)| with B = 1:
%       A(f) = 1/(q-p) * integral_p^q |R~(f; f0)| df0
%   The integral is evaluated with the trapezoidal rule on a dense f0 grid;
%   fHz is the frequency axis of the caller (band-limited slice).

f = fHz(:);
w = 2*pi*f;
nq = 129;
f0 = linspace(pHz, qHz, nq);
a  = (pi * f0).^2;
Aq = exp(-w.^2 ./ (4*a)) .* (w.^2 ./ (2*a));
A  = trapz(f0, Aq, 2) / max(qHz - pHz, eps);
A(~isfinite(A)) = 0;
A = max(A, 0);
end
