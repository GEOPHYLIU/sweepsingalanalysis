function [x, dt, S, warnings] = vsw_readBoxSweep(file, format, opts, warnings)
%VSW_READBOXSWEEP  Read a vibrator-controller (box) sweep file.
%
%   [x, dt, S, warnings] = vsw_readBoxSweep(file, format, opts, warnings)
%
%   Read-only support for the three formats registered in
%   07_箱体专用扫描文件格式研究.md:
%
%     'custom'  Sercel VE432/VE464 ASCII, one signed amplitude per line,
%               fixed 2000 samples/s (0.5 ms), -1..+1, '#' comments.
%     'vsci'    INOVA Vib Pro SCIO fixed-width records, 4000 samples/s.
%     'fsci'    INOVA Force Two SCIO fixed-width records, 2048 samples/s.
%
%   SCIO record (21 characters, three right-aligned 7-character fields):
%     sample number (int32) | envelope (0..32676) | phase code
%   Phase code maps -32768..32767 to -180..+179.9945 deg by
%   angle = code * 360 / 65536.  The waveform is envelope * sin(angle)
%   by default; set opts.phaseConvention = 'cos' if the box uses cosine.
%
%   This reader does not export box files.  Writing .custom/.vsci/.fsci
%   remains out of scope per 07 section 7.

if nargin < 3, opts = struct(); end
if nargin < 4, warnings = {}; end

switch lower(format)
    case 'custom'
        [x, dt, S, warnings] = readCustom(file, warnings);
    case {'vsci', 'fsci'}
        [x, dt, S, warnings] = readSci(file, lower(format), opts, warnings);
    otherwise
        error('vsw:box:format', 'Unknown box sweep format "%s".', format);
end

x = x(:);
S.nSamples = numel(x);
S.durationS = numel(x) * dt;
if isempty(x)
    error('vsw:box:empty', 'No samples decoded from %s.', file);
end
if any(~isfinite(x))
    error('vsw:box:nonFinite', 'Decoded box sweep contains NaN/Inf: %s', file);
end
end

% =======================================================================
function [x, dt, S, warnings] = readCustom(file, warnings)
% The generic strict text reader already handles '#' comments and checks
% the encoding; the box format adds the single-column and range rules.
% Real Sercel files carry a trailing TRUE/FALSE flag column; drop it.
[M, meta, warnings] = vsw_readTextSignal(file, warnings, ...
    struct('dropLogicalTail', true));
if size(M, 2) ~= 1
    error('vsw:box:customColumns', ...
        ['.custom is a single-column file, but "%s" has %d numeric ' ...
         'columns.'], file, size(M, 2));
end
x = M(:, 1);
if meta.logicalFlags > 0
    warnings{end+1} = sprintf( ...
        ['%d .custom sample(s) carry a TRUE/FALSE flag column; the flag ' ...
         'is metadata and was ignored for the waveform.'], meta.logicalFlags);
end
if any(~isfinite(x))
    error('vsw:box:customFinite', ...
        '.custom contains NaN/Inf samples: %s', file);
end
out = abs(x) > 1 + 1e-6;
if any(out)
    warnings{end+1} = sprintf( ...
        ['%d .custom sample(s) fall outside -1..+1; the file is not ' ...
         'normalised as the box format requires.'], sum(out));
end
dt = 0.5e-3;
S = struct('format', 'custom', 'sampleRate', 2000, 'dtMs', 0.5, ...
    'encoding', meta.encoding, 'columns', 1, 'commentsSkipped', meta.skipped, ...
    'logicalFlags', meta.logicalFlags);
end

% =======================================================================
function [x, dt, S, warnings] = readSci(file, subtype, opts, warnings)
d = dir(file);
if isempty(d) || d.bytes <= 0
    error('vsw:box:emptyFile', 'File is empty: %s', file);
end
fid = fopen(file, 'rb');
if fid < 0
    error('vsw:box:open', 'Cannot open "%s" for reading.', file);
end
raw = fread(fid, Inf, 'uint8=>uint8');
fclose(fid);
raw = raw(:).';

if any(raw > 127)
    error('vsw:box:sciAscii', ...
        'SCI/O record file "%s" contains non-ASCII bytes.', file);
end
str = char(raw);
lines = regexp(str, '\r\n|\n|\r', 'split');
while ~isempty(lines) && isempty(strtrim(lines{end}))
    lines(end) = [];
end
if isempty(lines)
    error('vsw:box:sciEmpty', 'No SCIO records in %s.', file);
end

n = numel(lines);
seq = zeros(n, 1);
envCode = zeros(n, 1);
phaseCode = zeros(n, 1);
for ii = 1:n
    line = lines{ii};
    if isempty(strtrim(line))
        error('vsw:box:sciBlank', ...
            'Blank SCIO record at line %d of "%s".', ii, file);
    end
    if numel(line) == 22 && line(22) == ' '
        line = line(1:21);
    end
    if numel(line) ~= 21
        error('vsw:box:sciWidth', ...
            ['Line %d of "%s" has %d characters; a SCIO record must ' ...
             'have exactly 21 (3 x 7).'], ii, file, numel(line));
    end
    seq(ii)       = parseField(line(1:7), ii, file, 'sample number');
    envCode(ii)   = parseField(line(8:14), ii, file, 'envelope');
    phaseCode(ii) = parseField(line(15:21), ii, file, 'phase');
end

if any(seq ~= round(seq))
    error('vsw:box:sciSeq', 'SCIO sample numbers must be integers: %s', file);
end
if n > 1 && any(diff(seq) ~= 1)
    bad = find(diff(seq) ~= 1, 1);
    error('vsw:box:sciSeq', ...
        'SCIO sample numbers jump at record %d (%d -> %d) in "%s".', ...
        bad, seq(bad), seq(bad+1), file);
end
if seq(1) ~= 0 && seq(1) ~= 1
    warnings{end+1} = sprintf( ...
        'SCIO sample numbering starts at %d (expected 0 or 1).', seq(1));
end

if any(envCode < 0)
    error('vsw:box:sciEnvelope', ...
        'SCIO envelope is negative at record %d in "%s".', ...
        find(envCode < 0, 1), file);
end
if any(envCode > 32676)
    warnings{end+1} = sprintf( ...
        '%d SCIO envelope code(s) exceed 32676; values were kept as read.', ...
        sum(envCode > 32676));
end
if any(phaseCode < -32768 | phaseCode > 32767)
    error('vsw:box:sciPhase', ...
        'SCIO phase code is outside -32768..32767 in "%s".', file);
end
if any(phaseCode > 32677)
    warnings{end+1} = sprintf( ...
        '%d SCIO phase code(s) exceed 32677 (179.9945 deg).', ...
        sum(phaseCode > 32677));
end

conv = lower(strtrim(opts.phaseConvention));
if isempty(conv)
    conv = 'sin';
    warnings{end+1} = ...
        ['SCIO phase convention is not declared in the file; assumed ' ...
         'sin(phase). Set opts.phaseConvention = ''cos'' if the box ' ...
         'uses cosine.'];
elseif ~any(strcmp(conv, {'sin', 'cos'}))
    error('vsw:box:phaseConvention', ...
        'opts.phaseConvention must be sin or cos (got "%s").', opts.phaseConvention);
end

env = envCode / 32676;
phaseDeg = phaseCode * (360 / 65536);
switch conv
    case 'sin'
        x = env .* sind(phaseDeg);
    case 'cos'
        x = env .* cosd(phaseDeg);
end

if strcmp(subtype, 'vsci')
    fs = 4000;
else
    fs = 2048;
end
dt = 1 / fs;
S = struct('format', subtype, 'sampleRate', fs, 'dtMs', 1000/fs, ...
    'encoding', 'ASCII', 'records', n, 'sequenceStart', seq(1), ...
    'phaseConvention', conv, 'envelopeFullScale', 32676, ...
    'phaseCodeFullScale', 65536, 'waveformRule', [conv '(phase)']);
end

% =======================================================================
function v = parseField(txt, lineNo, file, name)
v = str2double(strtrim(txt));
if ~isfinite(v)
    error('vsw:box:sciField', ...
        'Line %d of "%s": %s field is not numeric ("%s").', ...
        lineNo, file, name, txt);
end
end
