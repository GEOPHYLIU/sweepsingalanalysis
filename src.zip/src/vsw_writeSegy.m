function info = vsw_writeSegy(R, fileName)
%VSW_WRITESEGY  SEG-Y rev2.1 sweep writer (04 §3, §8).
%   IBM float32 (format code 1), big-endian, ASCII textual header by default,
%   sweep parameters mirrored in the binary header and the trace header.
%   numTraces copies of the same waveform are written (01 §2.5).

P  = R.P; D = R.D; G = R.G; out = P.output;
if nargin < 2 || isempty(fileName)
    fileName = fullfile(pwd, [R.meta.signalId '.sgy']);
end
if ~strcmpi(out.byteOrder, 'big')
    error('vsw:segy:byteOrder', ...
        ['04 §1 requires big-endian SEG-Y; byteOrder="%s" is not ' ...
         'supported. Set P.output.byteOrder = ''big''.'], out.byteOrder);
end
nTraces = max(1, round(out.numTraces));
allowedTrid = [6 21 19 18 20 1];
if ~any(out.traceIdCode == allowedTrid)
    error('vsw:segy:traceId', ...
        '04 §9-7: traceIdCode must be one of %s (got %d).', ...
        mat2str(allowedTrid), out.traceIdCode);
end

N = D.N;
x = R.derived.signal(:);

% ---- optional extended textual stanza --------------------------------
stanza = '';
nExt = 0;
if out.writeExtendedStanza
    stanza = makeStanza(R);
    nExt   = ceil(numel(stanza) / 3200);
    stanza = [stanza, repmat(' ', 1, nExt*3200 - numel(stanza))];
end
firstTrace = 3600 + 3200*nExt;

% ---- textual header ---------------------------------------------------
txt = makeTextHeader(R);
txtBytes = encodeText(txt, out.textHeaderEncoding);

% ---- binary header ----------------------------------------------------
b = zeros(400, 1, 'uint8');
b = putI16(b, 13, nTraces);                        % 3213 traces per ensemble
b = putI16(b, 15, 0);                              % 3215 auxiliary traces
b = putI16(b, 17, round(D.dtS*1e6));               % 3217 sample interval us
b = putI16(b, 19, round(D.dtS*1e6));               % 3219 original interval
b = putI16(b, 21, N);                              % 3221 samples per trace
b = putI16(b, 25, sampleFormatCode(out.sampleFormat));   % 3225 format
b = putI16(b, 27, 1);                              % 3227 fold
b = putI16(b, 29, 1);                              % 3229 trace sorting
b = putI16(b, 31, 1);                              % 3231 vertical sum
b = putI16(b, 33, round(D.fLo));                   % 3233 sweep start (lower)
b = putI16(b, 35, round(D.fHi));                   % 3235 sweep end (upper)
b = putI16(b, 37, round(P.sweep.lengthMs));        % 3237 sweep length ms
b = putI16(b, 39, G.sweepCode);                    % 3239 sweep type code
b = putI16(b, 41, out.sweepTraceNumber);           % 3241 sweep trace number
b = putI16(b, 43, round(P.taper.startMs));         % 3243 start taper
b = putI16(b, 45, round(P.taper.endMs));           % 3245 end taper
b = putI16(b, 47, taperTypeCode(P.taper.type));    % 3247 taper type
b = putI16(b, 49, 1);                              % 3249 not correlated
b = putI16(b, 55, 1);                              % 3255 metres
b = putI16(b, 57, 1);                              % 3257 impulse polarity
b = putI16(b, 59, 1);                              % 3259 vibratory polarity code
b = putI32(b, 97, revByteOrder(out.segyRevision)); % 3297 byte order marker
if strcmpi(out.segyRevision, 'rev2.1')
    b(301) = uint8(2); b(302) = uint8(1);          % 3501/3502 = 02/01
elseif strcmpi(out.segyRevision, 'rev1')
    b(301) = uint8(1); b(302) = uint8(0);
else
    b(301) = uint8(0); b(302) = uint8(0);
end
b = putI16(b, 303, 1);                             % 3503 fixed-length
b = putI16(b, 305, nExt);                          % 3505 extended records
b = putI16(b, 307, 0);                             % 3507 max add. trace hdr
b = putI16(b, 309, 1);                             % 3509 survey type land
b = putI16(b, 311, 4);                             % 3511 time basis UTC
b = putI64(b, 313, nTraces);                       % 3513 traces in file
b = putI64(b, 321, firstTrace);                    % 3521 first trace offset

% ---- trace header (template; sequence number filled per trace) --------
th = zeros(240, 1, 'uint8');
th = putI16(th, 29, out.traceIdCode);              % 29 trace id = 6 Sweep
th = putI16(th, 109, round(out.t0Ms));             % 109 delay ms
th = putI16(th, 115, N);                           % 115 samples
th = putI16(th, 117, round(D.dtS*1e6));            % 117 dt us
th = putI16(th, 125, 1);                           % 125 not correlated
th = putI16(th, 127, round(D.fLo));                % 127 start freq
th = putI16(th, 129, round(D.fHi));                % 129 end freq
th = putI16(th, 131, round(P.sweep.lengthMs));     % 131 length
th = putI16(th, 133, G.sweepCode);                 % 133 sweep type
th = putI16(th, 135, round(P.taper.startMs));      % 135 start taper
th = putI16(th, 137, round(P.taper.endMs));        % 137 end taper
th = putI16(th, 139, taperTypeCode(P.taper.type)); % 139 taper type
dv = datevec(now);
doy = datenum(dv(1), dv(2), dv(3)) - datenum(dv(1), 1, 1) + 1;
th = putI16(th, 157, dv(1));
th = putI16(th, 159, doy);
th = putI16(th, 161, dv(4));
th = putI16(th, 163, dv(5));
th = putI16(th, 165, floor(dv(6)));
th = putI16(th, 167, 0);
th = putI16(th, 217, 1);                           % 217 source type V1

% ---- samples ----------------------------------------------------------
switch lower(out.sampleFormat)
    case 'ibmfloat32'
        sb = vsw_ibmEncode(x);
    case 'ieeefloat32'
        sb = reshape(typecast(swapbytes(single(x)), 'uint8'), 4, []).';
    case 'int32'
        xi = int32(max(min(x, 1), -1) * 2147483647);
        sb = reshape(typecast(swapbytes(xi), 'uint8'), 4, []).';
    case 'int16'
        xi = int16(max(min(x, 1), -1) * 32767);
        sb = reshape(typecast(swapbytes(xi), 'uint8'), 2, []).';
    otherwise
        error('vsw:segy:sampleFormat', 'Unknown sample format "%s".', out.sampleFormat);
end
sampleBytes = reshape(sb.', 1, []);

% ---- write ------------------------------------------------------------
fid = fopen(fileName, 'wb');
if fid < 0
    error('vsw:segy:open', 'Cannot open "%s" for writing.', fileName);
end
cleaner = onCleanup(@() fclose(fid));
fwrite(fid, txtBytes, 'uint8');
fwrite(fid, b, 'uint8');
if nExt > 0
    fwrite(fid, uint8(stanza), 'uint8');
end
for k = 1:nTraces
    thk = putI32(th, 1, k);          % 1-4 trace sequence within file
    thk = putI32(thk, 5, k);         % 5-8 trace number within file
    fwrite(fid, thk, 'uint8');
    fwrite(fid, sampleBytes, 'uint8');
end
clear cleaner;

bps = numel(sampleBytes) / max(N, 1);
info.fileName  = fileName;
info.fileSize  = dir(fileName).bytes;
info.nSamples  = N;
info.nExt      = nExt;
info.numTraces = nTraces;
info.firstTrace = firstTrace;
info.expectedSize = firstTrace + nTraces * (240 + N*bps);
end

% =======================================================================
function v = revByteOrder(rev)
% 04 §10: rev2.1 writes 0x01020304; rev1/rev0 leave 3297-3300 zero.
if strcmpi(rev, 'rev2.1')
    v = 16909060;
else
    v = 0;
end
end

% =======================================================================
function s = putI16(buf, pos, v)
v = double(v);
v = mod(round(v), 65536);
buf(pos)   = uint8(floor(v/256));
buf(pos+1) = uint8(mod(v, 256));
s = buf;
end

function s = putI32(buf, pos, v)
v = double(v);
if v < 0, v = v + 2^32; end
v = mod(round(v), 2^32);
buf(pos)   = uint8(floor(v/2^24));
buf(pos+1) = uint8(mod(floor(v/2^16), 256));
buf(pos+2) = uint8(mod(floor(v/2^8), 256));
buf(pos+3) = uint8(mod(v, 256));
s = buf;
end

function s = putI64(buf, pos, v)
v = uint64(v);
for k = 8:-1:1
    buf(pos + (8-k)) = uint8(bitand(bitshift(v, -8*(k-1)), uint64(255)));
end
s = buf;
end

function code = sampleFormatCode(name)
switch lower(name)
    case 'ibmfloat32',  code = 1;
    case 'int32',       code = 2;
    case 'int16',       code = 3;
    case 'ieeefloat32', code = 5;
    otherwise,          code = 1;
end
end

function code = taperTypeCode(name)
switch lower(name)
    case 'none',   code = 0;
    case 'linear', code = 1;
    case 'cosine', code = 2;   % cosine squared (rev2.1)
    otherwise,     code = 3;
end
end

function txt = makeTextHeader(R)
P = R.P; D = R.D;
lines = repmat({''}, 40, 1);
lines{1}  = sprintf('C 1 %s', R.meta.codeVersion);
lines{2}  = sprintf('C 2 PROJECT %s', P.meta.project);
lines{3}  = sprintf('C 3 OPERATOR %s', P.meta.operator);
lines{4}  = sprintf('C 4 SYNTHETIC SWEEP SIGNAL - NOT FIELD DATA');
lines{13} = sprintf('C13 SWEEP: START %g HZ END %g HZ LENGTH %g MS CHANNEL NO %d TYPE %s', ...
    D.fLo, D.fHi, P.sweep.lengthMs, P.output.sweepTraceNumber, upper(P.sweep.type));
lines{14} = sprintf('C14 TAPER: START LENGTH %g MS END LENGTH %g MS TYPE %s', ...
    P.taper.startMs, P.taper.endMs, upper(P.taper.type));
lines{15} = sprintf('C15 DIRECTION %s   INITIAL PHASE %g DEG   DT %g MS', ...
    upper(P.sweep.direction), P.sweep.initialPhaseDeg, P.sweep.dtMs);
lines{16} = sprintf('C16 N = %d SAMPLES (ENDPOINT EXCLUDED; T-DT LAST SAMPLE)', D.N);
lines{17} = 'C17 POLARITY CODE 1 = SYNTHETIC CONVENTION, NOT A MEASURED VALUE';
if P.output.writeExtendedStanza
    lines{18} = 'C18 NON-STANDARD SWEEP TYPE: SEE EXTENDED TEXTUAL STANZA';
end
if strcmpi(P.output.segyRevision, 'rev1')
    lines{39} = 'C39 SEG-Y REV1 (LEGACY READER MODE)';
    lines{40} = 'C40 END TEXTUAL HEADER';
    lines{38} = 'C38 NOTE: TRACE HEADER SWEEP FIELDS AT REV2.1 BYTES 127-140';
elseif strcmpi(P.output.segyRevision, 'rev0')
    lines{39} = 'C39 SEG-Y REV0 (LEGACY READER MODE)';
    lines{40} = 'C40 END TEXTUAL HEADER';
    lines{38} = 'C38 NOTE: TRACE HEADER SWEEP FIELDS AT REV2.1 BYTES 127-140';
else
    lines{39} = 'C39 SEG-Y REV2.1';
    lines{40} = 'C40 END TEXTUAL HEADER';
end
txt = '';
for ii = 1:40
    ln = lines{ii};
    if numel(ln) > 80, ln = ln(1:80); end
    txt = [txt, ln, repmat(' ', 1, 80-numel(ln))]; %#ok<AGROW>
end
end

function s = makeStanza(R)
P = R.P;
s = sprintf(['((SEG: User Defined Stanza ver 1.0))\n' ...
    'dswv-type = %s\n' ...
    'dswv-path = %s\n' ...
    'dswv-param = f1=%g, f2=%g, lengthMs=%g, dtMs=%g, initialPhaseDeg=%g\n' ...
    'dswv-param2 = direction=%s, sweepConstant=%g, taperType=%s, startMs=%g, endMs=%g\n' ...
    'dswv-param3 = amplitudeFraction=%g, mainFreqHz=%g, dampingFactor=%g\n' ...
    'dswv-file = %s\n' ...
    'dswv-version = %s\n' ...
    '))\n'], ...
    P.sweep.type, R.G.pathLabel, ...
    P.sweep.f1Hz, P.sweep.f2Hz, P.sweep.lengthMs, P.sweep.dtMs, P.sweep.initialPhaseDeg, ...
    P.sweep.direction, P.sweep.sweepConstant, P.taper.type, P.taper.startMs, P.taper.endMs, ...
    P.drive.amplitudeFraction, P.wavelet.mainFreqHz, P.wavelet.dampingFactor, ...
    R.meta.signalId, R.meta.codeVersion);
s = strrep(s, sprintf('\r'), '');
end

function b = encodeText(txt, enc)
switch lower(enc)
    case 'ascii'
        b = uint8(txt);
    case 'ebcdic'
        try
            b = unicode2native(txt, 'IBM037');
        catch
            error('vsw:segy:ebcdic', ...
                'EBCDIC encoding unavailable on this platform; use ascii.');
        end
    otherwise
        error('vsw:segy:textEncoding', 'Unknown text encoding "%s".', enc);
end
end
