function G = vsw_gen_piecewiseLinear(P, D)
%VSW_GEN_PIECEWELLINEAR  Piecewise-linear frequency law (03 §2.1).
%   segmentFreqsHz / segmentLengthsMs describe the law in sweep-time order;
%   the ascending law required by vsw_analyticGrid is obtained by reversal
%   when the segments descend.  Phase is the exact piecewise integral, so the
%   type stays analytic and keeps the closed-form phase reference.

segF = P.sweep.segmentFreqsHz(:);
segL = P.sweep.segmentLengthsMs(:);
if numel(segF) ~= numel(segL) + 1 || numel(segF) < 2
    error('vsw:gen:piecewiseSize', ...
        'segmentFreqsHz must have exactly one more node than segmentLengthsMs.');
end
if any(segL <= 0) || any(segF <= 0)
    error('vsw:gen:piecewisePositive', ...
        'Segment frequencies and lengths must be positive.');
end
if ~(all(diff(segF) > 0) || all(diff(segF) < 0))
    error('vsw:gen:piecewiseMonotonic', ...
        'segmentFreqsHz must be strictly monotonic.');
end

if segF(end) < segF(1)
    segF = flipud(segF);
    segL = flipud(segL);
end

totalL = sum(segL);
ub = [0; cumsum(segL)] / totalL;
fb = segF;
segInt = 0.5 * (fb(1:end-1) + fb(2:end)) .* diff(ub(:));
cum = [0; cumsum(segInt)];

G.kind       = 'analytic';
G.pathLabel  = 'piecewiseLinear';
G.sweepCode  = 4;                     % SEG-Y sweep type 4 = other
G.fUp        = @(u) localF(u, ub, fb);
G.FAup       = @(u) localFA(u, ub, fb, cum);
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G.segmentFreqsHz    = segF;
G.segmentLengthsMs  = segL;
G = vsw_analyticGrid(D, G);
end

function f = localF(u, ub, fb)
u = min(max(u(:), 0), 1);
f = interp1(ub, fb, u, 'linear');
end

function fa = localFA(u, ub, fb, cum)
u = min(max(u(:), 0), 1);
k = sum(bsxfun(@ge, u, ub.'), 2);       % segment index, u=1 clamps below
k = min(max(k, 1), numel(fb) - 1);
du = u - ub(k);
slope = (fb(k+1) - fb(k)) ./ (ub(k+1) - ub(k));
fa = cum(k) + fb(k) .* du + 0.5 * slope .* du.^2;
end
