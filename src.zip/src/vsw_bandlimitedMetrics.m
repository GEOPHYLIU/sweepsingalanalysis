function M = vsw_bandlimitedMetrics(fg, A)
%VSW_BANDLIMITEDMETRICS  Zero-crossing spacing and first side-lobe level of
%   the band-limited target spectrum A(f).  When the target is truncated at
%   f1/f2 (as any real vibrator forces), the achieved wavelet is no longer
%   the untruncated analytic wavelet; B2/B3 must compare against what the
%   band can actually support.
%
%   Inverse FFT of the even-extended spectrum on a uniform fg grid.

fg = fg(:); A = A(:); A = max(A, 0);
if numel(fg) < 5 || max(A) <= 0
    M.zeroCrossSpacingS = NaN; M.sideLobeDB = NaN; return;
end
df = (fg(end) - fg(1)) / (numel(fg) - 1);
% pad to a 0..Fmax grid so the lag axis is well defined
Fmax = 500;
Mg = max(20001, round(Fmax/df) + 1);
fg2 = (0:Mg-1).' * df;
A2 = interp1(fg, A, fg2, 'linear', 0);
A2 = A2 / max(A2);
Asc = [A2; A2(end-1:-1:2)];
w = real(ifft(Asc));
w = w / w(1);
dt = 1 / (2*(Mg-1)*df);
lag = (0:Mg-1).' * dt;

z = find(w(1:end-1) .* w(2:end) < 0, 1);
if isempty(z)
    M.zeroCrossSpacingS = NaN; M.sideLobeDB = NaN; return;
end
M.zeroCrossSpacingS = 2 * lag(z);

% first side-lobe extremum after the first zero
seg = w(z+1 : min(z + round(0.2/dt), numel(w)));
if numel(seg) < 3
    M.sideLobeDB = NaN; return;
end
[pk, ~] = max(abs(seg));
M.sideLobeDB = 20*log10(pk + eps);
end
