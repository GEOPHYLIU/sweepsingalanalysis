function txtFile = vsw_writeTxt(R, fileName)
%VSW_WRITETXT  Human-readable two-column time/amplitude export.
if nargin < 2
    fileName = fullfile(pwd, [R.meta.signalId '.txt']);
end
fid = fopen(fileName, 'w');
if fid < 0, error('vsw:txt:open', 'Cannot open "%s".', fileName); end
fprintf(fid, '# %s  %s  %s\n', R.meta.signalId, R.P.sweep.type, R.meta.codeVersion);
fprintf(fid, '# f1=%g Hz  f2=%g Hz  length=%g ms  dt=%g ms  direction=%s\n', ...
    R.P.sweep.f1Hz, R.P.sweep.f2Hz, R.P.sweep.lengthMs, R.P.sweep.dtMs, R.P.sweep.direction);
fprintf(fid, '# N=%d (endpoint excluded)  phaseRef=%s  integration=%s\n', ...
    R.D.N, R.P.meta.phaseRef, R.P.meta.integrationRule);
fprintf(fid, '# time_s amplitude\n');
for ii = 1:R.D.N
    fprintf(fid, '%.9f %.12g\n', R.derived.tAxisS(ii), R.derived.signal(ii));
end
fclose(fid);
txtFile = fileName;
end
