function D = vsw_prepare(P)
%VSW_PREPARE  Build the SI-unit grid and all scalar derived quantities.
%
%   Implements 01 §3 (derived) and constant C1 (endpoint excluded).
%   Everything downstream uses D.dtS / D.T / D.tAxisS only.

C = vsw_constants();

D.type      = P.sweep.type;
D.dtMs      = P.sweep.dtMs;
D.dtS       = P.sweep.dtMs * 1e-3;
D.T         = P.sweep.lengthMs * 1e-3;
D.N         = round(P.sweep.lengthMs / P.sweep.dtMs);
D.tAxisS    = (0:D.N-1).' * D.dtS;
D.fNyqHz    = 1 / (2 * D.dtS);
D.fLo       = min(P.sweep.f1Hz, P.sweep.f2Hz);
D.fHi       = max(P.sweep.f1Hz, P.sweep.f2Hz);
D.direction = P.sweep.direction;
D.phi0Rad   = P.sweep.initialPhaseDeg * C.DEG2RAD;
D.startTaperS = P.taper.startMs * 1e-3;
D.endTaperS   = P.taper.endMs   * 1e-3;
end
