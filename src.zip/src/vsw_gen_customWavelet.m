function G = vsw_gen_customWavelet(P, D)
%VSW_GEN_CUSTOMWAVELET  Customer-shaped zero-phase wavelet -> sweep (00 §4).
%   The wavelet is a time-scaled damped Ricker
%       w(t) = (1-2*(pi*f0e*t)^2) * exp(-B*(pi*f0e*t)^2),  f0e = f0/gamma
%   gamma = lobeWidthRatio fixes the main-lobe zero-crossing spacing
%       gamma*sqrt(2)/(pi*f0),
%   and B >= 1 is solved so the first side lobe hits lobeAmpRatio.  Route 2
%   of 01 §4.3 then uses A(f) = |W~(f)| (so |S~| = sqrt(|W~|)).

f0    = P.wavelet.mainFreqHz;
gamma = P.wavelet.lobeWidthRatio;
r     = P.wavelet.lobeAmpRatio;
f0e   = f0 / gamma;

[B, achieved] = vsw_solveDampingForLobe(r);
if achieved > r * 1.02
    warning('vsw:gen:lobeUnreachable', ...
        ['Requested side-lobe ratio %.3f is above the Ricker limit; ' ...
         'clamped to B = 1 (achieved %.3f).'], r, achieved);
end

fg = linspace(D.fLo, D.fHi, max(4001, 4*D.N + 1)).';
A  = vsw_dampedRickerSpectrum(fg, f0e, B);
if max(A) <= 0
    error('vsw:gen:zeroSpectrum', 'Custom wavelet spectrum is zero over the band.');
end
A = A / max(A);

G.kind      = 'spectrum';
G.pathLabel = 'customWavelet';
G.sweepCode = 4;
G.zeroCrossSpacingS = gamma * sqrt(2) / (pi * f0);
G.waveletF0 = f0e;
G.waveletB  = B;
G.waveletGamma = gamma;
G = vsw_freqFromSpectrum(P, D, fg, A, G);
M = vsw_bandlimitedMetrics(G.targetFreqAxis, G.targetAmp);
G.targetSideLobeDB = M.sideLobeDB;
G.fullWaveletSideLobeDB = 20*log10(achieved);
G.bandLimitedZeroCrossS = M.zeroCrossSpacingS;
end
