function G = vsw_gen_expNeg(P, D)
%VSW_GEN_EXPNEG  Negative-exponential sweep (extension type, 00 §2).
%   f(t) = f1 + (f2-f1) * (1-exp(-k u))/(1-exp(-k)),  k = SweepConstant.
%   k -> 0 degenerates to linear.  This is the operational definition used
%   by the platform for the "负指数" family; the literature only fixes the
%   boundary conditions and the total compensation in dB.

k = P.sweep.sweepConstant;
if abs(k) < 1e-9, k = 1e-9; end
flo = D.fLo; fhi = D.fHi; d = fhi - flo;
den = -expm1(-k);
G.kind      = 'analytic';
G.fUp       = @(u) flo + d * (-expm1(-k*u)) / den;
G.FAup      = @(u) flo*u + d/den * (u - (-expm1(-k*u))/k);
G.pathLabel = 'analytic';
G.sweepCode = 3;
G.zeroCrossSpacingS = [];
G.targetSideLobeDB  = [];
G = vsw_analyticGrid(D, G);
end
