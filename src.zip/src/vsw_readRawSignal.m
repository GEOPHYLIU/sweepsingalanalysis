function [x, dt, S, warnings] = vsw_readRawSignal(file, opts, warnings)
%VSW_READRAWSIGNAL  Read a headerless binary signal with explicit metadata.
%
%   [x, dt, S] = vsw_readRawSignal(file, opts, warnings)
%
%   A raw binary file carries no self-describing header, so the caller must
%   state how it is encoded.  This is deliberate: the importer never guesses
%   a float format or byte order, because the same four bytes decode to very
%   different numbers under IEEE/IBM or little/big endian.
%
%   Required opts:
%     sampleFormat  'int16' | 'int32' | 'float32' | 'float64' | 'ibmFloat32'
%   Optional opts:
%     byteOrder      'little' (default) | 'big' | 'auto' (= little + warning)
%     offsetBytes    header bytes to skip                           (default 0)
%     samplesPerTrace samples per channel for interleaved traces     (default 0)
%     channel        1-based channel when samplesPerTrace > 0         (default 1)
%     dtMs           sample interval in ms                            (default 1)

if nargin < 3, warnings = {}; end
fmt = lower(strtrim(opts.sampleFormat));
valid = {'int16', 'int32', 'float32', 'float64', 'ibmfloat32'};
if isempty(fmt) || ~any(strcmp(fmt, valid))
    error('vsw:import:rawFormat', ...
        ['Raw binary needs opts.sampleFormat = one of ' ...
         'int16 / int32 / float32 / float64 / ibmFloat32.']);
end
switch fmt
    case 'int16',     nBytes = 2;
    case 'int32',     nBytes = 4;
    case 'float32',   nBytes = 4;
    case 'float64',   nBytes = 8;
    case 'ibmfloat32', nBytes = 4;
end

order = lower(strtrim(opts.byteOrder));
if isempty(order) || strcmp(order, 'auto')
    order = 'little';
    warnings{end+1} = ...
        'Raw binary has no byte-order field; using little-endian.';
end
if ~any(strcmp(order, {'little', 'big'}))
    error('vsw:import:rawOrder', ...
        'opts.byteOrder must be little, big or auto (got "%s").', opts.byteOrder);
end

fileBytes = opts.fileBytes;
if ~(isfinite(fileBytes) && fileBytes > 0)
    d = dir(file);
    fileBytes = d.bytes;
end
offset = max(0, round(opts.offsetBytes));
if offset >= fileBytes
    error('vsw:import:rawOffset', ...
        'offsetBytes (%d) is not smaller than the file size (%d).', ...
        offset, fileBytes);
end

fid = fopen(file, 'rb');
if fid < 0
    error('vsw:import:open', 'Cannot open "%s" for reading.', file);
end
if offset > 0 && fseek(fid, offset, 'bof') ~= 0
    fclose(fid);
    error('vsw:import:rawSeek', 'Cannot skip %d bytes in "%s".', offset, file);
end
raw = fread(fid, Inf, 'uint8=>uint8');
fclose(fid);
raw = raw(:);

payload = numel(raw);
if mod(payload, nBytes) ~= 0
    error('vsw:import:rawTruncated', ...
        ['Raw payload is %d bytes, not a multiple of %d bytes per ' ...
         'sample; the file is truncated or the format is wrong.'], ...
        payload, nBytes);
end

switch fmt
    case 'int16'
        if strcmp(order, 'big'), raw = swapBytes(raw, 2); end
        x = double(typecast(raw, 'int16'));
    case 'int32'
        if strcmp(order, 'big'), raw = swapBytes(raw, 4); end
        x = double(typecast(raw, 'int32'));
    case 'float32'
        if strcmp(order, 'big'), raw = swapBytes(raw, 4); end
        x = double(typecast(raw, 'single'));
    case 'float64'
        if strcmp(order, 'big'), raw = swapBytes(raw, 8); end
        x = double(typecast(raw, 'double'));
    case 'ibmfloat32'
        if strcmp(order, 'little'), raw = swapBytes(raw, 4); end
        b = reshape(raw, 4, []).';
        x = vsw_ibmDecode(b);
end
x = x(:);

spt = round(opts.samplesPerTrace);
if spt > 0
    if mod(numel(x), spt) ~= 0
        error('vsw:import:rawChannels', ...
            ['Sample count %d is not divisible by samplesPerTrace %d; ' ...
             'check the trace length and offsetBytes.'], numel(x), spt);
    end
    nTr = numel(x) / spt;
    M = reshape(x, spt, nTr);
    ch = round(opts.channel);
    if ch < 1 || ch > nTr
        warnings{end+1} = sprintf( ...
            'Requested channel %d, file has %d; using channel 1.', ch, nTr);
        ch = 1;
    end
    x = M(:, ch);
    S.channels = nTr;
    S.samplesPerTrace = spt;
else
    S.channels = 1;
    S.samplesPerTrace = numel(x);
end

dt = opts.dtMs * 1e-3;
warnings{end+1} = ...
    'Raw binary has no time header; the fallback dt was used.';

S.sampleFormat = fmt;
S.byteOrder = order;
S.offsetBytes = offset;
S.payloadBytes = payload;
S.expectedBytes = offset + payload;
end

% =======================================================================
function b = swapBytes(b, n)
b = reshape(b, n, []);
b = b(n:-1:1, :);
b = b(:);
end
